import { c as defineEventHandler, D as setHeader, r as readJson, q as query, p as parseStore } from '../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const BASE = "https://lakara.id";
function url(loc, priority = "0.8", changefreq = "monthly", lastmod) {
  return `
  <url>
    <loc>${BASE}${loc}</loc>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
    ${lastmod ? `<lastmod>${lastmod}</lastmod>` : ""}
  </url>`;
}
const sitemap_xml = defineEventHandler(async (event) => {
  setHeader(event, "Content-Type", "application/xml");
  const staticPages = [
    { loc: "/", priority: "1.0", changefreq: "weekly" },
    { loc: "/services", priority: "0.9", changefreq: "monthly" },
    { loc: "/pricing", priority: "0.9", changefreq: "monthly" },
    { loc: "/portfolio", priority: "0.8", changefreq: "weekly" },
    { loc: "/artikel", priority: "0.8", changefreq: "daily" },
    { loc: "/about", priority: "0.7", changefreq: "monthly" },
    { loc: "/contact", priority: "0.7", changefreq: "monthly" },
    { loc: "/kalkulator", priority: "0.6", changefreq: "monthly" }
  ];
  const portfolio = readJson("portfolio.json").filter((i) => i.published !== false);
  const portfolioUrls = portfolio.map((i) => {
    var _a;
    const raw = ((_a = i.updated_at) == null ? void 0 : _a.split("T")[0]) || i.date || "";
    const date = raw.length === 7 ? raw + "-01" : raw;
    return url(`/portfolio/${i.slug}`, "0.7", "monthly", date);
  });
  const artikel = readJson("artikel.json").filter((i) => i.published !== false);
  const artikelUrls = artikel.map(
    (i) => {
      var _a;
      return url(`/artikel/${i.slug}`, "0.7", "weekly", ((_a = i.updated_at) == null ? void 0 : _a.split("T")[0]) || "");
    }
  );
  let storeUrls = [];
  let productUrls = [];
  try {
    const rows = await query("SELECT slug, products, created_at FROM stores WHERE active = 1");
    const stores = rows.map(parseStore);
    storeUrls = stores.map((s) => url(`/${s.slug}`, "0.6", "weekly"));
    productUrls = stores.flatMap(
      (s) => (s.products || []).filter((p) => p.published !== false).map((p) => url(`/${s.slug}/${p.slug}`, "0.7", "weekly"))
    );
  } catch (e) {
    console.error("[sitemap] DB error:", e);
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${staticPages.map((p) => url(p.loc, p.priority, p.changefreq, today)).join("")}
${portfolioUrls.join("")}
${artikelUrls.join("")}
${storeUrls.join("")}
${productUrls.join("")}
</urlset>`;
  return xml;
});

export { sitemap_xml as default };
//# sourceMappingURL=sitemap.xml.mjs.map
