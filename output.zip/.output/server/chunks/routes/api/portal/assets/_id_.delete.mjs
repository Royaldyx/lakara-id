import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership, j as execute, C as getDataDir } from '../../../../_/nitro.mjs';
import { unlink } from 'fs/promises';
import { join } from 'path';
import 'crypto';
import 'fs';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__delete = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const asset = await queryOne("SELECT * FROM portal_assets WHERE id = ?", [id]);
  if (!asset) throw createError({ statusCode: 404, statusMessage: "Asset tidak ditemukan." });
  assertClientOwnership(user, asset.client_id);
  await execute("DELETE FROM portal_assets WHERE id = ?", [id]);
  const m = (asset.file_path || "").match(/\/api\/file\/([A-Za-z0-9_.\-]+)/);
  if (m) {
    try {
      await unlink(join(getDataDir(), "uploads", m[1]));
    } catch {
    }
  }
  return { ok: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
