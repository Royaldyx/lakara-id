import { c as defineEventHandler, L as requirePortalUser, i as queryOne, f as createError } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const num = (v) => Number(v || 0);
const dashboard_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  if (user.role === "admin" || user.role === "super_admin") {
    const [clients, activeSubs, waiting2, openTickets, unpaid2] = await Promise.all([
      queryOne("SELECT COUNT(*) AS n FROM portal_clients"),
      queryOne("SELECT COUNT(*) AS n FROM portal_subscriptions WHERE status = 'active'"),
      queryOne("SELECT COUNT(*) AS n FROM portal_contents WHERE status = 'waiting_approval'"),
      queryOne("SELECT COUNT(*) AS n FROM portal_tickets WHERE status != 'closed'"),
      queryOne("SELECT COUNT(*) AS n FROM portal_invoices WHERE status IN ('unpaid','overdue')")
    ]);
    return {
      ok: true,
      role: user.role,
      stats: {
        total_clients: num(clients == null ? void 0 : clients.n),
        active_subs: num(activeSubs == null ? void 0 : activeSubs.n),
        waiting_approval: num(waiting2 == null ? void 0 : waiting2.n),
        open_tickets: num(openTickets == null ? void 0 : openTickets.n),
        unpaid_invoices: num(unpaid2 == null ? void 0 : unpaid2.n)
      }
    };
  }
  const cid = user.client_id;
  if (!cid) throw createError({ statusCode: 400, statusMessage: "Akun client belum terhubung ke perusahaan." });
  const [sub, totalMonth, completed, waiting, unpaid, metric] = await Promise.all([
    queryOne(
      `SELECT s.status, p.name AS package_name, p.content_quota, p.revision_limit
       FROM portal_subscriptions s JOIN portal_packages p ON p.id = s.package_id
       WHERE s.client_id = ? AND s.status = 'active' ORDER BY s.created_at DESC LIMIT 1`,
      [cid]
    ),
    queryOne(
      `SELECT COUNT(*) AS n FROM portal_contents
       WHERE client_id = ? AND YEAR(created_at) = YEAR(CURDATE()) AND MONTH(created_at) = MONTH(CURDATE())`,
      [cid]
    ),
    queryOne(
      "SELECT COUNT(*) AS n FROM portal_contents WHERE client_id = ? AND status IN ('approved','scheduled','published')",
      [cid]
    ),
    queryOne(
      "SELECT COUNT(*) AS n FROM portal_contents WHERE client_id = ? AND status = 'waiting_approval'",
      [cid]
    ),
    queryOne(
      "SELECT COUNT(*) AS n FROM portal_invoices WHERE client_id = ? AND status IN ('unpaid','overdue')",
      [cid]
    ),
    queryOne(
      `SELECT followers, reach, impressions, engagement_rate FROM portal_social_metrics
       WHERE client_id = ? ORDER BY metric_date DESC LIMIT 1`,
      [cid]
    )
  ]);
  return {
    ok: true,
    role: "client",
    package: sub ? {
      name: sub.package_name,
      status: sub.status,
      content_quota: num(sub.content_quota),
      revision_limit: num(sub.revision_limit)
    } : null,
    stats: {
      content_this_month: num(totalMonth == null ? void 0 : totalMonth.n),
      content_completed: num(completed == null ? void 0 : completed.n),
      waiting_approval: num(waiting == null ? void 0 : waiting.n),
      unpaid_invoices: num(unpaid == null ? void 0 : unpaid.n)
    },
    social: metric ? {
      followers: num(metric.followers),
      reach: num(metric.reach),
      impressions: num(metric.impressions),
      engagement_rate: Number(metric.engagement_rate || 0)
    } : null
  };
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
