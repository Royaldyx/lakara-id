import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership, q as query } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const ticket = await queryOne(
    `SELECT t.*, c.company_name FROM portal_tickets t
     JOIN portal_clients c ON c.id = t.client_id WHERE t.id = ?`,
    [id]
  );
  if (!ticket) throw createError({ statusCode: 404, statusMessage: "Tiket tidak ditemukan." });
  assertClientOwnership(user, ticket.client_id);
  const messages = await query(
    `SELECT m.id, m.user_id, m.message, m.attachment, m.created_at,
            u.name AS sender_name, u.role AS sender_role
     FROM portal_ticket_messages m
     LEFT JOIN portal_users u ON u.id = m.user_id
     WHERE m.ticket_id = ? ORDER BY m.created_at ASC`,
    [id]
  );
  return { ok: true, ticket, messages };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
