import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, g as readBody, f as createError, i as queryOne, Q as assertClientOwnership, j as execute, N as genId, W as notify, Y as getAdminUserIds, X as getClientUserIds } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const reply_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  const message = (b.message || "").toString().trim();
  if (!message) throw createError({ statusCode: 400, statusMessage: "Pesan kosong." });
  const ticket = await queryOne("SELECT * FROM portal_tickets WHERE id = ?", [id]);
  if (!ticket) throw createError({ statusCode: 404, statusMessage: "Tiket tidak ditemukan." });
  assertClientOwnership(user, ticket.client_id);
  await execute(
    "INSERT INTO portal_ticket_messages (id, ticket_id, user_id, message, attachment) VALUES (?, ?, ?, ?, ?)",
    [genId("msg"), id, user.id, message, b.attachment || null]
  );
  const newStatus = user.role === "client" ? "in_progress" : "waiting_client";
  await execute("UPDATE portal_tickets SET status = ?, updated_at = NOW() WHERE id = ?", [newStatus, id]);
  if (user.role === "client") {
    await notify(await getAdminUserIds(), "ticket_reply", `Balasan tiket: ${ticket.subject}`, message, `/client/tickets/${id}`);
  } else {
    await notify(await getClientUserIds(ticket.client_id), "ticket_reply", `Tim Lakara membalas tiketmu`, message, `/client/tickets/${id}`);
  }
  return { ok: true };
});

export { reply_post as default };
//# sourceMappingURL=reply.post.mjs.map
