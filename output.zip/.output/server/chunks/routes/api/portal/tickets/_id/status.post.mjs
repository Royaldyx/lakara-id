import { c as defineEventHandler, O as requireAdmin, I as getRouterParam, g as readBody, f as createError, i as queryOne, j as execute, W as notify, X as getClientUserIds, P as logActivity } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const STATUSES = ["open", "in_progress", "waiting_client", "closed"];
const status_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  if (!STATUSES.includes(b.status))
    throw createError({ statusCode: 400, statusMessage: "Status tidak valid." });
  const ticket = await queryOne("SELECT * FROM portal_tickets WHERE id = ?", [id]);
  if (!ticket) throw createError({ statusCode: 404, statusMessage: "Tiket tidak ditemukan." });
  await execute("UPDATE portal_tickets SET status = ?, updated_at = NOW() WHERE id = ?", [b.status, id]);
  await notify(await getClientUserIds(ticket.client_id), "status_change", `Status tiket: ${b.status}`, ticket.subject, `/client/tickets/${id}`);
  await logActivity(event, admin, "ticket_status", "ticket", id, { status: b.status });
  return { ok: true };
});

export { status_post as default };
//# sourceMappingURL=status.post.mjs.map
