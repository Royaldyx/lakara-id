import { c as defineEventHandler, O as requireAdmin, g as readBody, f as createError, N as genId, j as execute, W as notify, X as getClientUserIds, P as logActivity } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const b = await readBody(event);
  const clientId = (b.client_id || "").toString();
  const title = (b.title || "").toString().trim();
  if (!clientId || !title) throw createError({ statusCode: 400, statusMessage: "Klien & judul wajib." });
  const kpi = Array.isArray(b.kpi) ? b.kpi : [];
  const id = genId("rpt");
  await execute(
    `INSERT INTO portal_reports (id, client_id, title, period_start, period_end, summary, kpi, insight, recommendation, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      clientId,
      title,
      b.period_start || null,
      b.period_end || null,
      b.summary || null,
      JSON.stringify(kpi),
      b.insight || null,
      b.recommendation || null,
      admin.id
    ]
  );
  await notify(await getClientUserIds(clientId), "status_change", `Laporan baru: ${title}`, "Laporan performa terbaru sudah tersedia.", `/client/reports/${id}`);
  await logActivity(event, admin, "create_report", "client", clientId);
  return { ok: true, id };
});

export { index_post as default };
//# sourceMappingURL=index.post15.mjs.map
