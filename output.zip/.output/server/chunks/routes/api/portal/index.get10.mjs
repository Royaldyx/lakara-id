import { c as defineEventHandler, L as requirePortalUser, x as getQuery, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const q = getQuery(event);
  const status = (q.status || "").toString();
  if (user.role === "client") {
    const rows2 = await query(
      `SELECT id, invoice_number, amount, status, issued_date, due_date, paid_at, created_at
       FROM portal_invoices WHERE client_id = ? ${status ? "AND status = ?" : ""}
       ORDER BY created_at DESC`,
      status ? [user.client_id, status] : [user.client_id]
    );
    return { ok: true, data: rows2 };
  }
  const cid = (q.client_id || "").toString();
  const where = [];
  const params = [];
  if (status) {
    where.push("i.status = ?");
    params.push(status);
  }
  if (cid) {
    where.push("i.client_id = ?");
    params.push(cid);
  }
  const rows = await query(
    `SELECT i.id, i.invoice_number, i.amount, i.status, i.issued_date, i.due_date, i.paid_at, i.created_at,
            i.client_id, c.company_name
     FROM portal_invoices i JOIN portal_clients c ON c.id = i.client_id
     ${where.length ? "WHERE " + where.join(" AND ") : ""}
     ORDER BY i.created_at DESC`,
    params
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get10.mjs.map
