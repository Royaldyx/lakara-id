import { c as defineEventHandler, O as requireAdmin, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const rows = await query(
    `SELECT c.id, c.company_name, c.brand_name, c.pic_name, c.email, c.whatsapp,
            c.industry, c.status, c.created_at,
            (SELECT p.name FROM portal_subscriptions s
               JOIN portal_packages p ON p.id = s.package_id
              WHERE s.client_id = c.id AND s.status = 'active'
              ORDER BY s.created_at DESC LIMIT 1) AS package_name,
            (SELECT u.email FROM portal_users u
              WHERE u.client_id = c.id AND u.role = 'client'
              ORDER BY u.created_at ASC LIMIT 1) AS login_email
     FROM portal_clients c
     ORDER BY c.created_at DESC`
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get6.mjs.map
