import { c as defineEventHandler, L as requirePortalUser, x as getQuery, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const status = (getQuery(event).status || "").toString();
  if (user.role === "client") {
    const rows2 = await query(
      `SELECT t.id, t.subject, t.category, t.status, t.created_at, t.updated_at,
              (SELECT COUNT(*) FROM portal_ticket_messages m WHERE m.ticket_id = t.id) AS msg_count
       FROM portal_tickets t
       WHERE t.client_id = ? ${status ? "AND t.status = ?" : ""}
       ORDER BY t.updated_at DESC`,
      status ? [user.client_id, status] : [user.client_id]
    );
    return { ok: true, data: rows2 };
  }
  const rows = await query(
    `SELECT t.id, t.subject, t.category, t.status, t.created_at, t.updated_at, t.client_id,
            c.company_name,
            (SELECT COUNT(*) FROM portal_ticket_messages m WHERE m.ticket_id = t.id) AS msg_count
     FROM portal_tickets t
     JOIN portal_clients c ON c.id = t.client_id
     ${status ? "WHERE t.status = ?" : ""}
     ORDER BY t.updated_at DESC`,
    status ? [status] : []
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get20.mjs.map
