import { c as defineEventHandler, L as requirePortalUser, q as query, x as getQuery, f as createError } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  if (user.role === "staff" || user.role === "freelancer") {
    const rows = await query(
      `SELECT id, title, file_path, rate_type, rate, scope, start_date, end_date, status, created_at
       FROM portal_contracts WHERE user_id = ? ORDER BY created_at DESC`,
      [user.id]
    );
    return { ok: true, data: rows };
  }
  if (user.role === "admin" || user.role === "super_admin") {
    const uid = (getQuery(event).user_id || "").toString();
    const rows = await query(
      `SELECT c.*, u.name AS member_name, u.role AS member_role
       FROM portal_contracts c JOIN portal_users u ON u.id = c.user_id
       ${uid ? "WHERE c.user_id = ?" : ""} ORDER BY c.created_at DESC`,
      uid ? [uid] : []
    );
    return { ok: true, data: rows };
  }
  throw createError({ statusCode: 403, statusMessage: "Akses ditolak." });
});

export { index_get as default };
//# sourceMappingURL=index.get8.mjs.map
