import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership, q as query, V as getClientRevisionLimit } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const content = await queryOne(
    `SELECT ct.*, c.company_name, b.title AS brief_title
     FROM portal_contents ct
     JOIN portal_clients c ON c.id = ct.client_id
     LEFT JOIN portal_briefs b ON b.id = ct.brief_id
     WHERE ct.id = ?`,
    [id]
  );
  if (!content) throw createError({ statusCode: 404, statusMessage: "Konten tidak ditemukan." });
  assertClientOwnership(user, content.client_id);
  const revisions = await query(
    `SELECT r.id, r.version, r.action, r.reason, r.created_at, u.name AS user_name, u.role AS user_role
     FROM portal_content_revisions r
     LEFT JOIN portal_users u ON u.id = r.user_id
     WHERE r.content_id = ? ORDER BY r.created_at ASC`,
    [id]
  );
  const revisionLimit = await getClientRevisionLimit(content.client_id);
  const revisionUsed = revisions.filter((r) => r.action === "revision_requested").length;
  return {
    ok: true,
    data: content,
    revisions,
    revision_limit: revisionLimit,
    revision_used: revisionUsed,
    revision_left: Math.max(0, revisionLimit - revisionUsed)
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
