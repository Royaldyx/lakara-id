import { c as defineEventHandler, L as requirePortalUser, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  await requirePortalUser(event);
  const rows = await query(
    "SELECT id, name, price, content_quota, revision_limit, features, active FROM portal_packages WHERE active = 1 ORDER BY sort_order ASC"
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get14.mjs.map
