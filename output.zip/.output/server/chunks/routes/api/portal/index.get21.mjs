import { c as defineEventHandler, Z as requireSuperAdmin, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  await requireSuperAdmin(event);
  const rows = await query(
    `SELECT id, role, name, email, phone, active, last_login_at, created_at
     FROM portal_users
     WHERE role IN ('admin','super_admin')
     ORDER BY created_at DESC`
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get21.mjs.map
