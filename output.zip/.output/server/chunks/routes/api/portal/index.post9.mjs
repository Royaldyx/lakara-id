import { c as defineEventHandler, L as requirePortalUser, g as readBody, f as createError, M as scopedClientId, N as genId, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const b = await readBody(event);
  const name = (b.name || "").toString().trim().slice(0, 120);
  if (!name) throw createError({ statusCode: 400, statusMessage: "Nama folder wajib." });
  const clientId = scopedClientId(user, b.client_id);
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const id = genId("fld");
  await execute("INSERT INTO portal_folders (id, client_id, name) VALUES (?, ?, ?)", [id, clientId, name]);
  return { ok: true, id };
});

export { index_post as default };
//# sourceMappingURL=index.post9.mjs.map
