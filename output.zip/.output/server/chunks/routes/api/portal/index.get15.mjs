import { c as defineEventHandler, L as requirePortalUser, q as query, x as getQuery, f as createError } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  if (user.role === "staff" || user.role === "freelancer") {
    const rows = await query(
      `SELECT id, period_start, period_end, amount, status, paid_at, notes, created_at
       FROM portal_payouts WHERE user_id = ? ORDER BY created_at DESC`,
      [user.id]
    );
    return { ok: true, data: rows };
  }
  if (user.role === "admin" || user.role === "super_admin") {
    const status = (getQuery(event).status || "").toString();
    const rows = await query(
      `SELECT p.*, u.name AS member_name, u.role AS member_role
       FROM portal_payouts p JOIN portal_users u ON u.id = p.user_id
       ${status ? "WHERE p.status = ?" : ""} ORDER BY p.created_at DESC`,
      status ? [status] : []
    );
    return { ok: true, data: rows };
  }
  throw createError({ statusCode: 403, statusMessage: "Akses ditolak." });
});

export { index_get as default };
//# sourceMappingURL=index.get15.mjs.map
