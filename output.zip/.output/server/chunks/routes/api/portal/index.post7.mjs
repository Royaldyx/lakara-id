import { c as defineEventHandler, O as requireAdmin, v as readMultipartFormData, f as createError, C as getDataDir, N as genId, j as execute, W as notify, P as logActivity } from '../../../_/nitro.mjs';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { extname, join } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const RATE_TYPES = ["hourly", "per_task", "monthly"];
const ALLOWED = [".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png"];
const index_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const parts = await readMultipartFormData(event);
  if (!(parts == null ? void 0 : parts.length)) throw createError({ statusCode: 400, statusMessage: "Tidak ada data." });
  const field = (n) => {
    var _a, _b;
    return ((_b = (_a = parts.find((p) => p.name === n && !p.filename)) == null ? void 0 : _a.data) == null ? void 0 : _b.toString().trim()) || "";
  };
  const userId = field("user_id");
  const title = field("title");
  if (!userId || !title) throw createError({ statusCode: 400, statusMessage: "Anggota & judul wajib." });
  const rateType = RATE_TYPES.includes(field("rate_type")) ? field("rate_type") : "per_task";
  let filePath = null;
  const filePart = parts.find((p) => {
    var _a;
    return p.name === "file" && p.filename && ((_a = p.data) == null ? void 0 : _a.length);
  });
  if (filePart) {
    const ext = extname(filePart.filename).toLowerCase();
    if (!ALLOWED.includes(ext)) throw createError({ statusCode: 400, statusMessage: `Format ${ext} tidak didukung.` });
    if (filePart.data.length > 10 * 1024 * 1024) throw createError({ statusCode: 400, statusMessage: "File melebihi 10 MB." });
    const dir = join(getDataDir(), "uploads");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    const filename = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}${ext}`;
    writeFileSync(join(dir, filename), filePart.data);
    filePath = `/api/file/${filename}`;
  }
  const id = genId("ctr");
  await execute(
    `INSERT INTO portal_contracts (id, user_id, title, file_path, rate_type, rate, scope, start_date, end_date, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
    [
      id,
      userId,
      title,
      filePath,
      rateType,
      Math.max(0, Number(field("rate")) || 0),
      field("scope") || null,
      field("start_date") || null,
      field("end_date") || null
    ]
  );
  await notify(userId, "status_change", `Kontrak baru: ${title}`, "Cek detail kontrak/MOU kamu.", "/client/my-contract");
  await logActivity(event, admin, "create_contract", "user", userId);
  return { ok: true, id };
});

export { index_post as default };
//# sourceMappingURL=index.post7.mjs.map
