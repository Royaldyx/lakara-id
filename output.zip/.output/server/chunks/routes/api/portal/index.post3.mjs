import { c as defineEventHandler, L as requirePortalUser, g as readBody, f as createError, Q as assertClientOwnership, N as genId, j as execute, P as logActivity, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const BRIEF_STATUS = ["draft", "submitted", "in_progress", "completed"];
const index_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const b = await readBody(event);
  const action = b.action || "create";
  if (action === "create") {
    const clientId = user.role === "client" ? user.client_id || "" : (b.client_id || "").toString();
    if (!clientId) throw createError({ statusCode: 400, statusMessage: "Klien wajib dipilih." });
    assertClientOwnership(user, clientId);
    const title = (b.title || "").toString().trim();
    if (!title) throw createError({ statusCode: 400, statusMessage: "Judul brief wajib diisi." });
    let status = (b.status || (user.role === "client" ? "submitted" : "draft")).toString();
    if (!BRIEF_STATUS.includes(status)) status = "draft";
    const id = genId("brf");
    await execute(
      `INSERT INTO portal_briefs (id, client_id, title, objective, description, promo, cta, deadline, reference, status, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        clientId,
        title,
        b.objective || null,
        b.description || null,
        b.promo || null,
        b.cta || null,
        b.deadline || null,
        b.reference || null,
        status,
        user.id
      ]
    );
    await logActivity(event, user, "create_brief", "brief", id);
    return { ok: true, id };
  }
  if (!b.id) throw createError({ statusCode: 400, statusMessage: "id brief wajib." });
  const brief = await queryOne("SELECT id, client_id, status FROM portal_briefs WHERE id = ?", [b.id]);
  if (!brief) throw createError({ statusCode: 404, statusMessage: "Brief tidak ditemukan." });
  assertClientOwnership(user, brief.client_id);
  if (action === "set_status") {
    const status = (b.status || "").toString();
    if (!BRIEF_STATUS.includes(status)) throw createError({ statusCode: 400, statusMessage: "Status tidak valid." });
    if (user.role === "client" && !(brief.status === "draft" && status === "submitted"))
      throw createError({ statusCode: 403, statusMessage: "Klien hanya bisa submit brief draft." });
    await execute("UPDATE portal_briefs SET status = ? WHERE id = ?", [status, b.id]);
    await logActivity(event, user, "brief_status", "brief", b.id, { status });
    return { ok: true };
  }
  if (action === "update") {
    if (user.role === "client" && !["draft", "submitted"].includes(brief.status))
      throw createError({ statusCode: 403, statusMessage: "Brief sudah diproses, tidak bisa diedit." });
    const title = (b.title || "").toString().trim();
    if (!title) throw createError({ statusCode: 400, statusMessage: "Judul brief wajib diisi." });
    await execute(
      `UPDATE portal_briefs SET title = ?, objective = ?, description = ?, promo = ?, cta = ?, deadline = ?, reference = ?
       WHERE id = ?`,
      [
        title,
        b.objective || null,
        b.description || null,
        b.promo || null,
        b.cta || null,
        b.deadline || null,
        b.reference || null,
        b.id
      ]
    );
    await logActivity(event, user, "update_brief", "brief", b.id);
    return { ok: true };
  }
  if (action === "delete") {
    if (user.role === "client" && brief.status !== "draft")
      throw createError({ statusCode: 403, statusMessage: "Hanya brief draft yang bisa dihapus." });
    await execute("DELETE FROM portal_briefs WHERE id = ?", [b.id]);
    await logActivity(event, user, "delete_brief", "brief", b.id);
    return { ok: true };
  }
  throw createError({ statusCode: 400, statusMessage: "Action tidak dikenal." });
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
