import { c as defineEventHandler, L as requirePortalUser, x as getQuery, q as query, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const onlyUnread = getQuery(event).unread === "1";
  const rows = await query(
    `SELECT id, type, title, body, link, read_at, created_at
     FROM portal_notifications
     WHERE user_id = ? ${onlyUnread ? "AND read_at IS NULL" : ""}
     ORDER BY created_at DESC LIMIT 50`,
    [user.id]
  );
  const unread = await queryOne(
    "SELECT COUNT(*) AS n FROM portal_notifications WHERE user_id = ? AND read_at IS NULL",
    [user.id]
  );
  return { ok: true, data: rows, unread: Number((unread == null ? void 0 : unread.n) || 0) };
});

export { index_get as default };
//# sourceMappingURL=index.get13.mjs.map
