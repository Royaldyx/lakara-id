import { c as defineEventHandler, O as requireAdmin, I as getRouterParam, g as readBody, i as queryOne, f as createError, j as execute, W as notify, P as logActivity } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const status_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  const status = b.status === "paid" ? "paid" : "pending";
  const payout = await queryOne("SELECT * FROM portal_payouts WHERE id = ?", [id]);
  if (!payout) throw createError({ statusCode: 404, statusMessage: "Payout tidak ditemukan." });
  const paidAt = status === "paid" ? "NOW()" : "NULL";
  await execute(`UPDATE portal_payouts SET status = ?, paid_at = ${paidAt} WHERE id = ?`, [status, id]);
  if (status === "paid")
    await notify(payout.user_id, "status_change", `Pembayaran diterima \u{1F389}`, `Rp ${Number(payout.amount).toLocaleString("id-ID")} sudah dibayar.`, "/client/my-payouts");
  await logActivity(event, admin, "payout_status", "payout", id, { status });
  return { ok: true };
});

export { status_post as default };
//# sourceMappingURL=status.post.mjs.map
