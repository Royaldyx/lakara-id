import { c as defineEventHandler, O as requireAdmin, x as getQuery, f as createError, q as query } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const suggest_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const q = getQuery(event);
  const userId = (q.user_id || "").toString();
  if (!userId) throw createError({ statusCode: 400, statusMessage: "user_id wajib." });
  const from = (q.from || "").toString();
  const to = (q.to || "").toString();
  const where = ["assignee_id = ?", "status = 'done'", "fee > 0"];
  const params = [userId];
  if (from) {
    where.push("DATE(updated_at) >= ?");
    params.push(from);
  }
  if (to) {
    where.push("DATE(updated_at) <= ?");
    params.push(to);
  }
  const tasks = await query(
    `SELECT id, title, fee, updated_at FROM portal_tasks WHERE ${where.join(" AND ")} ORDER BY updated_at DESC`,
    params
  );
  const total = tasks.reduce((s, t) => s + Number(t.fee || 0), 0);
  return { ok: true, total, tasks };
});

export { suggest_get as default };
//# sourceMappingURL=suggest.get.mjs.map
