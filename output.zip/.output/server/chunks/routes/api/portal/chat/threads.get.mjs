import { c as defineEventHandler, O as requireAdmin, q as query } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const threads_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const rows = await query(
    `SELECT * FROM (
       SELECT c.id AS client_id, c.company_name,
         (SELECT body FROM portal_chat_messages m WHERE m.client_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message,
         (SELECT created_at FROM portal_chat_messages m WHERE m.client_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_at,
         (SELECT COUNT(*) FROM portal_chat_messages m WHERE m.client_id = c.id AND m.sender_role = 'client' AND m.read_at IS NULL) AS unread
       FROM portal_clients c
     ) t
     WHERE t.last_at IS NOT NULL
     ORDER BY t.last_at DESC`
  );
  return { ok: true, data: rows };
});

export { threads_get as default };
//# sourceMappingURL=threads.get.mjs.map
