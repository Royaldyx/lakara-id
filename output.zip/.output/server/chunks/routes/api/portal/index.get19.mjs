import { c as defineEventHandler, O as requireAdmin, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const rows = await query(
    `SELECT u.id, u.role, u.name, u.email, u.phone, u.active, u.created_at,
            (SELECT COUNT(*) FROM portal_tasks t WHERE t.assignee_id = u.id AND t.status != 'done') AS active_tasks
     FROM portal_users u
     WHERE u.role IN ('staff','freelancer')
     ORDER BY u.created_at DESC`
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get19.mjs.map
