import { c as defineEventHandler, L as requirePortalUser, M as scopedClientId, x as getQuery, f as createError, q as query, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const clientId = scopedClientId(user, (getQuery(event).client_id || "").toString());
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const rows = await query(
    `SELECT id, sender_user_id, sender_role, body, attachment, read_at, created_at
     FROM portal_chat_messages WHERE client_id = ? ORDER BY created_at ASC LIMIT 200`,
    [clientId]
  );
  const otherSide = user.role === "client" ? "sender_role != 'client'" : "sender_role = 'client'";
  await execute(
    `UPDATE portal_chat_messages SET read_at = NOW() WHERE client_id = ? AND read_at IS NULL AND ${otherSide}`,
    [clientId]
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get5.mjs.map
