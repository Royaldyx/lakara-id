import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, q as query } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  var _a, _b;
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const task = await queryOne("SELECT * FROM portal_tasks WHERE id = ?", [id]);
  if (!task) throw createError({ statusCode: 404, statusMessage: "Tugas tidak ditemukan." });
  const isTeam = user.role === "staff" || user.role === "freelancer";
  const isAdmin = user.role === "admin" || user.role === "super_admin";
  if (isTeam && task.assignee_id !== user.id)
    throw createError({ statusCode: 403, statusMessage: "Bukan tugas kamu." });
  if (!isTeam && !isAdmin)
    throw createError({ statusCode: 403, statusMessage: "Akses ditolak." });
  if (isTeam) {
    delete task.client_id;
    delete task.content_id;
    delete task.created_by;
  }
  let assignee_name = null, company_name = null;
  if (isAdmin) {
    if (task.assignee_id) assignee_name = (_a = await queryOne("SELECT name FROM portal_users WHERE id = ?", [task.assignee_id])) == null ? void 0 : _a.name;
    if (task.client_id) company_name = (_b = await queryOne("SELECT company_name FROM portal_clients WHERE id = ?", [task.client_id])) == null ? void 0 : _b.company_name;
  }
  const messages = await query(
    `SELECT m.id, m.user_id, m.body, m.attachment, m.created_at, u.name AS sender_name, u.role AS sender_role
     FROM portal_task_messages m LEFT JOIN portal_users u ON u.id = m.user_id
     WHERE m.task_id = ? ORDER BY m.created_at ASC`,
    [id]
  );
  return { ok: true, task: { ...task, assignee_name, company_name }, messages };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
