import { c as defineEventHandler, L as requirePortalUser, f as createError, I as getRouterParam, i as queryOne, v as readMultipartFormData, C as getDataDir, j as execute, N as genId, W as notify, Y as getAdminUserIds, P as logActivity } from '../../../../../_/nitro.mjs';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { extname, join } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const ALLOWED = [".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg", ".pdf", ".mp4", ".webm", ".zip", ".doc", ".docx", ".psd", ".ai", ".fig"];
const MAX_KB = 20480;
const submit_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  if (user.role !== "staff" && user.role !== "freelancer")
    throw createError({ statusCode: 403, statusMessage: "Hanya assignee yang bisa submit." });
  const id = getRouterParam(event, "id");
  const task = await queryOne("SELECT * FROM portal_tasks WHERE id = ?", [id]);
  if (!task) throw createError({ statusCode: 404, statusMessage: "Tugas tidak ditemukan." });
  if (task.assignee_id !== user.id) throw createError({ statusCode: 403, statusMessage: "Bukan tugas kamu." });
  const parts = await readMultipartFormData(event);
  const field = (n) => {
    var _a, _b;
    return ((_b = (_a = parts == null ? void 0 : parts.find((p) => p.name === n && !p.filename)) == null ? void 0 : _a.data) == null ? void 0 : _b.toString().trim()) || "";
  };
  const link = field("link");
  const note = field("note");
  let deliverable = link || task.deliverable;
  const filePart = parts == null ? void 0 : parts.find((p) => {
    var _a;
    return p.name === "file" && p.filename && ((_a = p.data) == null ? void 0 : _a.length);
  });
  if (filePart) {
    const ext = extname(filePart.filename).toLowerCase();
    if (!ALLOWED.includes(ext)) throw createError({ statusCode: 400, statusMessage: `Format ${ext} tidak didukung.` });
    if (filePart.data.length > MAX_KB * 1024) throw createError({ statusCode: 400, statusMessage: `File melebihi ${MAX_KB / 1024} MB.` });
    const uploadDir = join(getDataDir(), "uploads");
    if (!existsSync(uploadDir)) mkdirSync(uploadDir, { recursive: true });
    const filename = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}${ext}`;
    writeFileSync(join(uploadDir, filename), filePart.data);
    deliverable = `/api/file/${filename}`;
  }
  if (!deliverable) throw createError({ statusCode: 400, statusMessage: "Lampirkan file atau link hasil." });
  await execute(
    "UPDATE portal_tasks SET deliverable = ?, status = 'submitted', submitted_at = NOW() WHERE id = ?",
    [deliverable, id]
  );
  if (note) {
    await execute(
      "INSERT INTO portal_task_messages (id, task_id, user_id, body) VALUES (?, ?, ?, ?)",
      [genId("tmsg"), id, user.id, note]
    );
  }
  await notify(await getAdminUserIds(), "status_change", `Tugas disubmit: ${task.title}`, `oleh ${user.name}`, `/client/admin/tasks`);
  await logActivity(event, user, "submit_task", "task", id);
  return { ok: true };
});

export { submit_post as default };
//# sourceMappingURL=submit.post.mjs.map
