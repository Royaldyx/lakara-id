import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, g as readBody, f as createError, i as queryOne, j as execute, N as genId, W as notify, Y as getAdminUserIds } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const message_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  const body = (b.body || "").toString().trim();
  if (!body) throw createError({ statusCode: 400, statusMessage: "Pesan kosong." });
  const task = await queryOne("SELECT * FROM portal_tasks WHERE id = ?", [id]);
  if (!task) throw createError({ statusCode: 404, statusMessage: "Tugas tidak ditemukan." });
  const isTeam = user.role === "staff" || user.role === "freelancer";
  const isAdmin = user.role === "admin" || user.role === "super_admin";
  if (isTeam && task.assignee_id !== user.id) throw createError({ statusCode: 403, statusMessage: "Bukan tugas kamu." });
  if (!isTeam && !isAdmin) throw createError({ statusCode: 403, statusMessage: "Akses ditolak." });
  await execute(
    "INSERT INTO portal_task_messages (id, task_id, user_id, body) VALUES (?, ?, ?, ?)",
    [genId("tmsg"), id, user.id, body]
  );
  if (isTeam) await notify(await getAdminUserIds(), "status_change", `Balasan tugas: ${task.title}`, body, `/client/admin/tasks`);
  else if (task.assignee_id) await notify(task.assignee_id, "status_change", `Pesan tugas: ${task.title}`, body, `/client/tasks/${id}`);
  return { ok: true };
});

export { message_post as default };
//# sourceMappingURL=message.post.mjs.map
