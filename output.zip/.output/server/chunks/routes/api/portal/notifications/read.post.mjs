import { c as defineEventHandler, L as requirePortalUser, g as readBody, j as execute } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const read_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const body = await readBody(event);
  if (body.all) {
    await execute("UPDATE portal_notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL", [user.id]);
  } else if (body.id) {
    await execute("UPDATE portal_notifications SET read_at = NOW() WHERE id = ? AND user_id = ?", [body.id, user.id]);
  }
  return { ok: true };
});

export { read_post as default };
//# sourceMappingURL=read.post.mjs.map
