import { c as defineEventHandler, L as requirePortalUser, x as getQuery, M as scopedClientId, f as createError, Q as assertClientOwnership, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const q = getQuery(event);
  const cid = scopedClientId(user, (q.client_id || "").toString());
  if (!cid) throw createError({ statusCode: 400, statusMessage: "Klien tidak ditemukan." });
  assertClientOwnership(user, cid);
  const client = await queryOne(
    `SELECT id, company_name, brand_name, pic_name, email, whatsapp, website, industry, logo,
            brand_description, target_audience, competitor, tone_of_voice, business_goals, status
     FROM portal_clients WHERE id = ?`,
    [cid]
  );
  if (!client) throw createError({ statusCode: 404, statusMessage: "Klien tidak ditemukan." });
  const fields = [client.brand_name, client.industry, client.brand_description, client.target_audience, client.tone_of_voice, client.business_goals];
  const filled = fields.filter((v) => v && v.toString().trim()).length;
  const complete = filled === fields.length;
  return { ok: true, data: client, completeness: { filled, total: fields.length, complete } };
});

export { index_get as default };
//# sourceMappingURL=index.get16.mjs.map
