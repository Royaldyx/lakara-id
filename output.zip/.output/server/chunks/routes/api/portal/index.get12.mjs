import { c as defineEventHandler, O as requireAdmin, x as getQuery, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const ENTITIES = ["client", "brief", "content", "ticket"];
const index_get = defineEventHandler(async (event) => {
  await requireAdmin(event);
  const q = getQuery(event);
  const entityType = (q.entity_type || "").toString();
  const entityId = (q.entity_id || "").toString();
  if (!ENTITIES.includes(entityType) || !entityId)
    throw createError({ statusCode: 400, statusMessage: "entity_type/entity_id tidak valid." });
  const rows = await query(
    `SELECT n.id, n.body, n.created_at, u.name AS author
     FROM portal_notes n LEFT JOIN portal_users u ON u.id = n.created_by
     WHERE n.entity_type = ? AND n.entity_id = ?
     ORDER BY n.created_at DESC`,
    [entityType, entityId]
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get12.mjs.map
