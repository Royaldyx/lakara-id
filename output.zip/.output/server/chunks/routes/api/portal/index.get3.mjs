import { c as defineEventHandler, L as requirePortalUser, x as getQuery, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const q = getQuery(event);
  let targetId = user.id;
  if (user.role === "admin" || user.role === "super_admin") {
    if (!q.user_id) throw createError({ statusCode: 400, statusMessage: "user_id wajib." });
    targetId = q.user_id.toString();
  } else if (user.role !== "staff" && user.role !== "freelancer") {
    throw createError({ statusCode: 403, statusMessage: "Akses ditolak." });
  }
  const where = ["user_id = ?"];
  const params = [targetId];
  if (q.from) {
    where.push("`date` >= ?");
    params.push(q.from.toString());
  }
  if (q.to) {
    where.push("`date` <= ?");
    params.push(q.to.toString());
  }
  const rows = await query(
    `SELECT id, user_id, DATE_FORMAT(\`date\`, '%Y-%m-%d') AS date, status, note
     FROM portal_attendance WHERE ${where.join(" AND ")} ORDER BY \`date\` DESC LIMIT 400`,
    params
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
