import { c as defineEventHandler, L as requirePortalUser, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const onlyPublished = user.role === "client";
  const rows = await query(
    `SELECT id, category, title, slug, body, sort_order, published, created_at
     FROM portal_kb_articles ${onlyPublished ? "WHERE published = 1" : ""}
     ORDER BY category, sort_order ASC, created_at DESC`
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get11.mjs.map
