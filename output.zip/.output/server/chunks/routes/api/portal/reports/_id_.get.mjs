import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const rpt = await queryOne(
    `SELECT r.*, c.company_name FROM portal_reports r JOIN portal_clients c ON c.id = r.client_id WHERE r.id = ?`,
    [id]
  );
  if (!rpt) throw createError({ statusCode: 404, statusMessage: "Laporan tidak ditemukan." });
  assertClientOwnership(user, rpt.client_id);
  try {
    rpt.kpi = typeof rpt.kpi === "string" ? JSON.parse(rpt.kpi || "[]") : rpt.kpi || [];
  } catch {
    rpt.kpi = [];
  }
  return { ok: true, report: rpt };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
