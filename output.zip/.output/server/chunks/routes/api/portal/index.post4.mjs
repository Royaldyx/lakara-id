import { c as defineEventHandler, L as requirePortalUser, g as readBody, f as createError, M as scopedClientId, j as execute, N as genId } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const b = await readBody(event);
  const body = (b.body || "").toString().trim();
  if (!body && !b.attachment) throw createError({ statusCode: 400, statusMessage: "Pesan kosong." });
  const clientId = scopedClientId(user, b.client_id);
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  await execute(
    `INSERT INTO portal_chat_messages (id, client_id, sender_user_id, sender_role, body, attachment)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [genId("cht"), clientId, user.id, user.role, body || null, b.attachment || null]
  );
  return { ok: true };
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
