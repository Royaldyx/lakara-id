import { c as defineEventHandler, L as requirePortalUser, q as query, x as getQuery } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  if (user.role === "client") {
    const rows2 = await query(
      `SELECT id, title, period_start, period_end, created_at FROM portal_reports
       WHERE client_id = ? ORDER BY created_at DESC`,
      [user.client_id]
    );
    return { ok: true, data: rows2 };
  }
  const cid = (getQuery(event).client_id || "").toString();
  const rows = await query(
    `SELECT r.id, r.title, r.period_start, r.period_end, r.created_at, r.client_id, c.company_name
     FROM portal_reports r JOIN portal_clients c ON c.id = r.client_id
     ${cid ? "WHERE r.client_id = ?" : ""} ORDER BY r.created_at DESC`,
    cid ? [cid] : []
  );
  return { ok: true, data: rows };
});

export { index_get as default };
//# sourceMappingURL=index.get17.mjs.map
