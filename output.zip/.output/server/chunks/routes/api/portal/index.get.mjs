import { c as defineEventHandler, L as requirePortalUser, x as getQuery, M as scopedClientId, f as createError, q as query, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const q = getQuery(event);
  const clientId = scopedClientId(user, (q.client_id || "").toString());
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const days = Math.min(Math.max(Number(q.days) || 30, 1), 365);
  const accounts = await query(
    "SELECT id, platform, handle, connected FROM portal_social_accounts WHERE client_id = ? ORDER BY platform",
    [clientId]
  );
  const metrics = await query(
    `SELECT id, platform, metric_date, followers, reach, impressions, profile_visits, engagement_rate
     FROM portal_social_metrics
     WHERE client_id = ? AND metric_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
     ORDER BY metric_date DESC`,
    [clientId, days]
  );
  const latest = await queryOne(
    `SELECT followers, reach, impressions, profile_visits, engagement_rate, metric_date
     FROM portal_social_metrics WHERE client_id = ? ORDER BY metric_date DESC LIMIT 1`,
    [clientId]
  );
  return { ok: true, accounts, metrics, latest };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
