import { c as defineEventHandler, L as requirePortalUser, M as scopedClientId, x as getQuery, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const clientId = scopedClientId(user, (getQuery(event).client_id || "").toString());
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const folders = await query(
    "SELECT id, name, created_at FROM portal_folders WHERE client_id = ? ORDER BY name ASC",
    [clientId]
  );
  const assets = await query(
    `SELECT id, folder_id, category, name, file_path, mime, size, created_at
     FROM portal_assets WHERE client_id = ? ORDER BY created_at DESC`,
    [clientId]
  );
  return { ok: true, folders, assets };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
