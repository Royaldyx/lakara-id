import { c as defineEventHandler, L as requirePortalUser, g as readBody, M as scopedClientId, f as createError, j as execute, N as genId } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const PLATFORMS = ["instagram", "facebook", "tiktok"];
const account_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const b = await readBody(event);
  const clientId = scopedClientId(user, b.client_id);
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const platform = PLATFORMS.includes(b.platform) ? b.platform : "instagram";
  const handle = (b.handle || "").toString().trim().slice(0, 120);
  if (!handle) throw createError({ statusCode: 400, statusMessage: "Handle/username wajib." });
  await execute(
    `INSERT INTO portal_social_accounts (id, client_id, platform, handle, connected) VALUES (?, ?, ?, ?, 1)`,
    [genId("soc"), clientId, platform, handle]
  );
  return { ok: true };
});

export { account_post as default };
//# sourceMappingURL=account.post.mjs.map
