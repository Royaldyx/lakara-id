import { c as defineEventHandler, O as requireAdmin, g as readBody, f as createError, j as execute, N as genId, P as logActivity } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const PLATFORMS = ["instagram", "facebook", "tiktok"];
const metric_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const b = await readBody(event);
  const clientId = (b.client_id || "").toString();
  const platform = PLATFORMS.includes(b.platform) ? b.platform : "instagram";
  const date = (b.metric_date || "").toString() || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib." });
  const n = (v) => Math.max(0, Math.floor(Number(v) || 0));
  await execute(
    `INSERT INTO portal_social_metrics
       (id, client_id, platform, metric_date, followers, reach, impressions, profile_visits, engagement_rate)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      genId("met"),
      clientId,
      platform,
      date,
      n(b.followers),
      n(b.reach),
      n(b.impressions),
      n(b.profile_visits),
      Number(b.engagement_rate) || 0
    ]
  );
  await logActivity(event, admin, "add_metric", "client", clientId, { platform, date });
  return { ok: true };
});

export { metric_post as default };
//# sourceMappingURL=metric.post.mjs.map
