import { c as defineEventHandler, y as getHeader, z as checkRateLimit, f as createError, g as readBody, i as queryOne, l as hashPassword, B as recordFailedAttempt, R as createPortalSession, A as resetAttempts, P as logActivity } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const login_post = defineEventHandler(async (event) => {
  const ip = getHeader(event, "x-forwarded-for") || getHeader(event, "cf-connecting-ip") || "unknown";
  const key = `portal-login:${ip}`;
  const limit = checkRateLimit(key);
  if (!limit.allowed) throw createError({ statusCode: 429, statusMessage: limit.message });
  const { email, password } = await readBody(event);
  if (!email || !password)
    throw createError({ statusCode: 400, statusMessage: "Email dan password wajib diisi." });
  const user = await queryOne(
    "SELECT * FROM portal_users WHERE email = ?",
    [email.trim().toLowerCase()]
  );
  if (!user || user.password_hash !== hashPassword(password)) {
    recordFailedAttempt(key);
    throw createError({ statusCode: 401, statusMessage: "Email atau password salah." });
  }
  if (!user.active)
    throw createError({ statusCode: 403, statusMessage: "Akun kamu dinonaktifkan. Hubungi admin." });
  await createPortalSession(event, user.id);
  resetAttempts(key);
  await logActivity(event, user, "login");
  const { password_hash, ...safe } = user;
  return { ok: true, user: safe };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
