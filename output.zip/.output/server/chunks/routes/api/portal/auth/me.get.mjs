import { c as defineEventHandler, L as requirePortalUser } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const me_get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  return { ok: true, user };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
