import { c as defineEventHandler, O as requireAdmin, q as query, i as queryOne, N as genId, j as execute, W as notify, X as getClientUserIds, P as logActivity } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const generateRecurring_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const now = /* @__PURE__ */ new Date();
  const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const dueDate = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
  const subs = await query(
    `SELECT s.client_id, p.name AS package_name, p.price
     FROM portal_subscriptions s JOIN portal_packages p ON p.id = s.package_id
     WHERE s.status = 'active'`
  );
  let created = 0, skipped = 0;
  for (const s of subs) {
    const price = Number(s.price || 0);
    if (price <= 0) {
      skipped++;
      continue;
    }
    const exist = await queryOne(
      `SELECT id FROM portal_invoices
       WHERE client_id = ? AND YEAR(issued_date) = YEAR(CURDATE()) AND MONTH(issued_date) = MONTH(CURDATE())
         AND notes LIKE 'Langganan bulanan%'`,
      [s.client_id]
    );
    if (exist) {
      skipped++;
      continue;
    }
    try {
      const id = genId("inv");
      const invoiceNumber = `INV-${ym.replace("-", "")}${String(now.getDate()).padStart(2, "0")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const items = [{ desc: `Langganan ${s.package_name} (${ym})`, qty: 1, price }];
      await execute(
        `INSERT INTO portal_invoices (id, invoice_number, client_id, amount, items, status, issued_date, due_date, notes, created_by)
         VALUES (?, ?, ?, ?, ?, 'unpaid', CURDATE(), ?, ?, ?)`,
        [id, invoiceNumber, s.client_id, price, JSON.stringify(items), dueDate, `Langganan bulanan ${ym}`, admin.id]
      );
      await notify(
        await getClientUserIds(s.client_id),
        "invoice",
        `Invoice bulanan: ${invoiceNumber}`,
        `Tagihan langganan Rp ${price.toLocaleString("id-ID")}`,
        `/client/invoices/${id}`
      );
      created++;
    } catch {
      skipped++;
    }
  }
  await logActivity(event, admin, "generate_recurring_invoice", null, null, { ym, created, skipped });
  return { ok: true, created, skipped, period: ym };
});

export { generateRecurring_post as default };
//# sourceMappingURL=generate-recurring.post.mjs.map
