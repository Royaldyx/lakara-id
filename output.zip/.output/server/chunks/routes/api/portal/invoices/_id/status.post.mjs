import { c as defineEventHandler, O as requireAdmin, I as getRouterParam, g as readBody, f as createError, i as queryOne, j as execute, W as notify, X as getClientUserIds, P as logActivity } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const STATUSES = ["paid", "unpaid", "overdue"];
const status_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  if (!STATUSES.includes(b.status))
    throw createError({ statusCode: 400, statusMessage: "Status tidak valid." });
  const inv = await queryOne("SELECT * FROM portal_invoices WHERE id = ?", [id]);
  if (!inv) throw createError({ statusCode: 404, statusMessage: "Invoice tidak ditemukan." });
  const paidAt = b.status === "paid" ? "NOW()" : "NULL";
  await execute(`UPDATE portal_invoices SET status = ?, paid_at = ${paidAt} WHERE id = ?`, [b.status, id]);
  if (b.status === "paid")
    await notify(await getClientUserIds(inv.client_id), "invoice", `Pembayaran diterima`, `${inv.invoice_number} lunas. Terima kasih!`, `/client/invoices/${id}`);
  await logActivity(event, admin, "invoice_status", "invoice", id, { status: b.status });
  return { ok: true };
});

export { status_post as default };
//# sourceMappingURL=status.post.mjs.map
