import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const inv = await queryOne(
    `SELECT i.*, c.company_name, c.email AS client_email, c.whatsapp AS client_whatsapp, c.pic_name
     FROM portal_invoices i JOIN portal_clients c ON c.id = i.client_id WHERE i.id = ?`,
    [id]
  );
  if (!inv) throw createError({ statusCode: 404, statusMessage: "Invoice tidak ditemukan." });
  assertClientOwnership(user, inv.client_id);
  try {
    inv.items = typeof inv.items === "string" ? JSON.parse(inv.items || "[]") : inv.items || [];
  } catch {
    inv.items = [];
  }
  return { ok: true, invoice: inv };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
