import { c as defineEventHandler, L as requirePortalUser, I as getRouterParam, i as queryOne, f as createError, Q as assertClientOwnership } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const id = getRouterParam(event, "id");
  const brief = await queryOne(
    `SELECT b.*, c.company_name
     FROM portal_briefs b JOIN portal_clients c ON c.id = b.client_id
     WHERE b.id = ?`,
    [id]
  );
  if (!brief) throw createError({ statusCode: 404, statusMessage: "Brief tidak ditemukan." });
  assertClientOwnership(user, brief.client_id);
  return { ok: true, data: brief };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
