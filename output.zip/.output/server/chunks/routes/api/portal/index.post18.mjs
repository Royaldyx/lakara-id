import { c as defineEventHandler, L as requirePortalUser, g as readBody, f as createError, M as scopedClientId, N as genId, j as execute, W as notify, Y as getAdminUserIds, P as logActivity } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const CATEGORIES = ["revision", "billing", "technical", "general"];
const index_post = defineEventHandler(async (event) => {
  const user = await requirePortalUser(event);
  const b = await readBody(event);
  const subject = (b.subject || "").toString().trim();
  const category = CATEGORIES.includes(b.category) ? b.category : "general";
  const message = (b.message || "").toString().trim();
  if (!subject) throw createError({ statusCode: 400, statusMessage: "Subjek wajib diisi." });
  const clientId = scopedClientId(user, b.client_id);
  if (!clientId) throw createError({ statusCode: 400, statusMessage: "client_id wajib (untuk admin)." });
  const ticketId = genId("tkt");
  await execute(
    `INSERT INTO portal_tickets (id, client_id, subject, category, status, created_by)
     VALUES (?, ?, ?, ?, 'open', ?)`,
    [ticketId, clientId, subject, category, user.id]
  );
  if (message) {
    await execute(
      "INSERT INTO portal_ticket_messages (id, ticket_id, user_id, message) VALUES (?, ?, ?, ?)",
      [genId("msg"), ticketId, user.id, message]
    );
  }
  if (user.role === "client") {
    await notify(await getAdminUserIds(), "ticket_new", `Tiket baru: ${subject}`, message || void 0, `/client/tickets/${ticketId}`);
  }
  await logActivity(event, user, "create_ticket", "ticket", ticketId);
  return { ok: true, id: ticketId };
});

export { index_post as default };
//# sourceMappingURL=index.post18.mjs.map
