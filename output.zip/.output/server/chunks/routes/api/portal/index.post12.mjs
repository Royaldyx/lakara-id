import { c as defineEventHandler, O as requireAdmin, g as readBody, f as createError, N as genId, j as execute, P as logActivity } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const ENTITIES = ["client", "brief", "content", "ticket"];
const index_post = defineEventHandler(async (event) => {
  const admin = await requireAdmin(event);
  const b = await readBody(event);
  const entityType = (b.entity_type || "").toString();
  const entityId = (b.entity_id || "").toString();
  const body = (b.body || "").toString().trim();
  if (!ENTITIES.includes(entityType) || !entityId)
    throw createError({ statusCode: 400, statusMessage: "entity_type/entity_id tidak valid." });
  if (!body) throw createError({ statusCode: 400, statusMessage: "Catatan kosong." });
  const id = genId("note");
  await execute(
    "INSERT INTO portal_notes (id, entity_type, entity_id, body, created_by) VALUES (?, ?, ?, ?, ?)",
    [id, entityType, entityId, body, admin.id]
  );
  await logActivity(event, admin, "add_note", entityType, entityId);
  return { ok: true, id };
});

export { index_post as default };
//# sourceMappingURL=index.post12.mjs.map
