import { c as defineEventHandler, g as readBody, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const recordClick_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const store_id = (body.store_id || "").toString().slice(0, 20);
  const link_id = (body.link_id || "").toString().slice(0, 50);
  if (!store_id || !link_id) {
    return { ok: false };
  }
  try {
    await execute(
      "INSERT INTO link_clicks (store_id, link_id) VALUES (?, ?)",
      [store_id, link_id]
    );
  } catch {
  }
  return { ok: true };
});

export { recordClick_post as default };
//# sourceMappingURL=record-click.post.mjs.map
