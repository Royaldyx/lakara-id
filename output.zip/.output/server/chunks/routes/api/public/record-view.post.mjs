import { c as defineEventHandler, g as readBody, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const PAGE_VIEW_ID = "__view__";
const recordView_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const store_id = (body.store_id || "").toString().slice(0, 20);
  if (!store_id) {
    return { ok: false };
  }
  try {
    await execute(
      "INSERT INTO link_clicks (store_id, link_id) VALUES (?, ?)",
      [store_id, PAGE_VIEW_ID]
    );
  } catch {
  }
  return { ok: true };
});

export { PAGE_VIEW_ID, recordView_post as default };
//# sourceMappingURL=record-view.post.mjs.map
