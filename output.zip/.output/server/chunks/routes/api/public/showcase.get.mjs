import { c as defineEventHandler, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const showcase_get = defineEventHandler(async () => {
  const rows = await query(
    `SELECT slug, name, tagline, logo, primary_color, instagram, tiktok, whatsapp, youtube,
            product_tier, links_bio
     FROM stores
     WHERE show_on_showcase = 1 AND active = 1 AND member_active = 1
     ORDER BY FIELD(product_tier, 'premium', 'pro', 'free'), created_at DESC
     LIMIT 60`
  );
  const data = rows.map((r) => {
    let verified = false;
    try {
      const lb = typeof r.links_bio === "string" ? JSON.parse(r.links_bio) : r.links_bio;
      verified = !!(lb && lb.verified);
    } catch {
    }
    return {
      slug: r.slug,
      name: r.name,
      tagline: r.tagline,
      logo: r.logo,
      primary_color: r.primary_color || "#3358ff",
      tier: r.product_tier || "free",
      verified,
      socials: {
        instagram: r.instagram || "",
        tiktok: r.tiktok || "",
        whatsapp: r.whatsapp || "",
        youtube: r.youtube || ""
      }
    };
  });
  return { success: true, data };
});

export { showcase_get as default };
//# sourceMappingURL=showcase.get.mjs.map
