import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, r as readJson, _ as writeJson, m as slugify } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const portfolio_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = await readBody(event);
  const action = body.action;
  let data = readJson("portfolio.json");
  if (action === "delete") {
    data = data.filter((i) => i.id !== body.id);
    writeJson("portfolio.json", data);
    return { success: true };
  }
  if (action === "toggle_publish") {
    data = data.map((i) => i.id === body.id ? { ...i, published: !i.published } : i);
    writeJson("portfolio.json", data);
    return { success: true };
  }
  const item = {
    id: body.id || String(Date.now()),
    slug: body.slug || slugify(body.title),
    title: body.title || "",
    category: body.category || "",
    client: body.client || "",
    image: body.image || "",
    excerpt: body.excerpt || "",
    content: body.content || "",
    tags: Array.isArray(body.tags) ? body.tags : (body.tags || "").split(",").map((t) => t.trim()).filter(Boolean),
    link: body.link || "",
    date: body.date || "",
    featured: Boolean(body.featured),
    published: body.published !== false && body.published !== "false",
    created_at: body.created_at || (/* @__PURE__ */ new Date()).toISOString()
  };
  if (!item.title) throw createError({ statusCode: 400, statusMessage: "Judul wajib diisi." });
  const slugExists = data.find((i) => i.slug === item.slug && i.id !== item.id);
  if (slugExists) throw createError({ statusCode: 400, statusMessage: `Slug "${item.slug}" sudah digunakan.` });
  const idx = data.findIndex((i) => i.id === item.id);
  if (idx >= 0) data[idx] = item;
  else data.push(item);
  const ok = writeJson("portfolio.json", data);
  if (!ok) throw createError({ statusCode: 500, statusMessage: "Gagal menyimpan data." });
  return { success: true, data: item };
});

export { portfolio_post as default };
//# sourceMappingURL=portfolio.post.mjs.map
