import { c as defineEventHandler, f as createError, C as getDataDir, D as setHeader } from '../../../_/nitro.mjs';
import { existsSync, readFileSync } from 'fs';
import { join, extname } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const MIME = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".mp4": "video/mp4",
  ".webm": "video/webm"
};
const _filename__get = defineEventHandler((event) => {
  var _a, _b, _c;
  const filename = (_b = (_a = event.context.params) == null ? void 0 : _a.filename) != null ? _b : "";
  if (!filename || /[\/\\.]\./.test(filename)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid filename" });
  }
  const filepath = join(getDataDir(), "uploads", filename);
  if (!existsSync(filepath)) throw createError({ statusCode: 404, statusMessage: "File tidak ditemukan." });
  const mime = (_c = MIME[extname(filename).toLowerCase()]) != null ? _c : "application/octet-stream";
  setHeader(event, "Content-Type", mime);
  setHeader(event, "Cache-Control", "public, max-age=31536000, immutable");
  return readFileSync(filepath);
});

export { _filename__get as default };
//# sourceMappingURL=_filename_.get.mjs.map
