import { c as defineEventHandler, u as useRuntimeConfig, $ as readRawBody, y as getHeader, a0 as verifyCallbackSignature, a1 as setResponseStatus, j as execute, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const callback_post = defineEventHandler(async (event) => {
  const cfg = useRuntimeConfig();
  const privateKey = cfg.tripayPrivateKey;
  const rawBody = await readRawBody(event, false);
  const signature = getHeader(event, "x-callback-signature") || "";
  if (!rawBody || !verifyCallbackSignature(rawBody, signature, privateKey)) {
    setResponseStatus(event, 400);
    return { success: false, message: "Invalid signature" };
  }
  let data;
  try {
    data = JSON.parse(rawBody);
  } catch {
    setResponseStatus(event, 400);
    return { success: false, message: "Invalid JSON" };
  }
  const { merchant_ref, status, reference } = data;
  if (status !== "PAID") {
    if (merchant_ref && (status === "FAILED" || status === "EXPIRED")) {
      await execute(
        "UPDATE payments SET status = ?, tripay_ref = ?, updated_at = NOW() WHERE id = ?",
        [status.toLowerCase(), reference || null, merchant_ref]
      );
    }
    return { success: true };
  }
  const payment = await queryOne(
    "SELECT * FROM payments WHERE id = ?",
    [merchant_ref]
  );
  if (!payment) return { success: true };
  if (payment.status === "paid") return { success: true };
  const recentOtherPaid = await queryOne(
    `SELECT id FROM payments
     WHERE store_id = ? AND status = 'paid'
       AND paid_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)
       AND id != ?`,
    [payment.store_id, merchant_ref]
  );
  await execute(
    "UPDATE payments SET status = 'paid', tripay_ref = ?, paid_at = NOW(), updated_at = NOW() WHERE id = ?",
    [reference || null, merchant_ref]
  );
  if (recentOtherPaid) {
    console.warn(`[Callback] Double-payment guard: store ${payment.store_id} \u2014 payment ${recentOtherPaid.id} baru saja dibayar. Melewati tier upgrade untuk ${merchant_ref}.`);
    return { success: true };
  }
  const store = await queryOne("SELECT product_tier, tier_expires_at FROM stores WHERE id = ?", [payment.store_id]);
  const baseDate = (store == null ? void 0 : store.tier_expires_at) && new Date(store.tier_expires_at) > /* @__PURE__ */ new Date() ? new Date(store.tier_expires_at) : /* @__PURE__ */ new Date();
  baseDate.setMonth(baseDate.getMonth() + Number(payment.months || 1));
  await execute(
    "UPDATE stores SET product_tier = ?, tier_started_at = NOW(), tier_expires_at = ? WHERE id = ?",
    [payment.tier_type, baseDate, payment.store_id]
  );
  try {
    const refee = await queryOne(
      "SELECT referred_by, referral_rewarded FROM stores WHERE id = ?",
      [payment.store_id]
    );
    if ((refee == null ? void 0 : refee.referred_by) && !refee.referral_rewarded) {
      const refeeExp = new Date(baseDate);
      refeeExp.setMonth(refeeExp.getMonth() + 1);
      await execute(
        "UPDATE stores SET tier_expires_at = ?, referral_rewarded = 1 WHERE id = ?",
        [refeeExp, payment.store_id]
      );
      const referrer = await queryOne(
        "SELECT product_tier, tier_expires_at FROM stores WHERE id = ?",
        [refee.referred_by]
      );
      if (referrer) {
        const base = referrer.tier_expires_at && new Date(referrer.tier_expires_at) > /* @__PURE__ */ new Date() ? new Date(referrer.tier_expires_at) : /* @__PURE__ */ new Date();
        base.setMonth(base.getMonth() + 1);
        const newTier = referrer.product_tier === "premium" ? "premium" : "pro";
        await execute(
          "UPDATE stores SET product_tier = ?, tier_started_at = COALESCE(tier_started_at, NOW()), tier_expires_at = ? WHERE id = ?",
          [newTier, base, refee.referred_by]
        );
      }
    }
  } catch (e) {
    console.error("[Callback] Referral reward gagal:", e);
  }
  return { success: true };
});

export { callback_post as default };
//# sourceMappingURL=callback.post.mjs.map
