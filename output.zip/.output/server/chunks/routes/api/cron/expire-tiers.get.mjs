import { c as defineEventHandler, u as useRuntimeConfig, x as getQuery, f as createError, q as query, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const expireTiers_get = defineEventHandler(async (event) => {
  var _a;
  const cfg = useRuntimeConfig();
  const secret = cfg.cronSecret || cfg.adminPass || "";
  const key = (getQuery(event).key || "").toString();
  if (!secret || key !== secret) {
    throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  }
  const expiring = await query(
    `SELECT id, slug, product_tier, tier_expires_at FROM stores
     WHERE product_tier <> 'free' AND tier_expires_at IS NOT NULL AND tier_expires_at < NOW()`
  );
  const res = await execute(
    `UPDATE stores SET product_tier = 'free', tier_expires_at = NULL
     WHERE product_tier <> 'free' AND tier_expires_at IS NOT NULL AND tier_expires_at < NOW()`
  );
  return {
    ok: true,
    downgraded: (_a = res == null ? void 0 : res.affectedRows) != null ? _a : expiring.length,
    stores: expiring.map((s) => ({ slug: s.slug, was: s.product_tier, expired_at: s.tier_expires_at }))
  };
});

export { expireTiers_get as default };
//# sourceMappingURL=expire-tiers.get.mjs.map
