import { c as defineEventHandler, x as getQuery, r as readJson, y as getHeader, u as useRuntimeConfig } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const artikel_get = defineEventHandler((event) => {
  const q = getQuery(event);
  let items = readJson("artikel.json");
  const isAdmin = getHeader(event, "x-admin-token") === useRuntimeConfig().adminPass;
  if (!isAdmin) items = items.filter((i) => i.published !== false);
  if (q.slug) return { success: true, data: items.find((i) => i.slug === q.slug) || null };
  if (q.category) items = items.filter((i) => i.category === q.category);
  if (q.featured !== void 0) items = items.filter((i) => i.featured === true);
  items.sort((a, b) => (b.created_at || b.date || "").localeCompare(a.created_at || a.date || ""));
  if (q.limit) items = items.slice(0, Number(q.limit));
  return { success: true, data: items };
});

export { artikel_get as default };
//# sourceMappingURL=artikel.get.mjs.map
