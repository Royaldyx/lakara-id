import { c as defineEventHandler, i as queryOne } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const terms_get = defineEventHandler(async () => {
  const row = await queryOne(
    "SELECT `value`, updated_at FROM settings WHERE `key` = 'member_terms'"
  );
  return { ok: true, content: (row == null ? void 0 : row.value) || "", updated_at: (row == null ? void 0 : row.updated_at) || "" };
});

export { terms_get as default };
//# sourceMappingURL=terms.get.mjs.map
