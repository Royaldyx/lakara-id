import { c as defineEventHandler, y as getHeader, z as checkRateLimit, f as createError, g as readBody, B as recordFailedAttempt, i as queryOne, j as execute } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const newsletter_post = defineEventHandler(async (event) => {
  const ip = getHeader(event, "x-forwarded-for") || getHeader(event, "cf-connecting-ip") || "unknown";
  const limit = checkRateLimit(`newsletter:${ip}`);
  if (!limit.allowed) throw createError({ statusCode: 429, statusMessage: "Terlalu banyak request. Coba lagi nanti." });
  const body = await readBody(event);
  const email = ((body == null ? void 0 : body.email) || "").trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    recordFailedAttempt(`newsletter:${ip}`);
    throw createError({ statusCode: 400, statusMessage: "Email tidak valid." });
  }
  const exists = await queryOne("SELECT id FROM newsletter WHERE email = ?", [email]);
  if (exists) return { ok: true, message: "Email sudah terdaftar." };
  await execute(
    "INSERT INTO newsletter (id, email, name, source) VALUES (?, ?, ?, ?)",
    [String(Date.now()), email, (body == null ? void 0 : body.name) || "", (body == null ? void 0 : body.source) || "website"]
  );
  return { ok: true, message: "Berhasil subscribe! Terima kasih." };
});

export { newsletter_post as default };
//# sourceMappingURL=newsletter.post.mjs.map
