import { c as defineEventHandler, q as query } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const faq_get = defineEventHandler(async () => {
  const rows = await query(
    "SELECT id, question, answer, sort_order FROM faqs WHERE active = 1 ORDER BY sort_order ASC, id ASC"
  );
  return { success: true, data: rows };
});

export { faq_get as default };
//# sourceMappingURL=faq.get.mjs.map
