import { c as defineEventHandler, y as getHeader, z as checkRateLimit, f as createError, u as useRuntimeConfig, g as readBody, A as resetAttempts, h as setCookie, B as recordFailedAttempt } from '../../_/nitro.mjs';
import { createHash } from 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const makeSessionToken = (pass) => createHash("sha256").update(pass + "lakara_session_v1").digest("hex").slice(0, 32);
const auth_post = defineEventHandler(async (event) => {
  const ip = getHeader(event, "x-forwarded-for") || getHeader(event, "cf-connecting-ip") || "unknown";
  const key = `admin:${ip}`;
  const limit = checkRateLimit(key);
  if (!limit.allowed) throw createError({ statusCode: 429, statusMessage: limit.message });
  const config = useRuntimeConfig();
  const body = await readBody(event);
  if ((body == null ? void 0 : body.password) === config.adminPass) {
    resetAttempts(key);
    const sessionToken = makeSessionToken(config.adminPass);
    setCookie(event, "lakara_admin", "true", {
      maxAge: 60 * 60 * 8,
      path: "/",
      sameSite: "strict",
      httpOnly: false
    });
    return { ok: true, token: sessionToken };
  }
  recordFailedAttempt(key);
  throw createError({ statusCode: 401, statusMessage: "Username atau password salah." });
});

export { auth_post as default };
//# sourceMappingURL=auth.post.mjs.map
