import { c as defineEventHandler, x as getQuery, i as queryOne, p as parseStore, q as query } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const stores_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  if (q.slug) {
    const raw = await queryOne("SELECT * FROM stores WHERE slug = ? AND active = 1", [q.slug]);
    if (!raw) return { success: false, data: null };
    const store = parseStore(raw);
    store.products = (store.products || []).filter((p) => p.published !== false);
    const { member_password, member_email, ...safe } = store;
    return { success: true, data: safe };
  }
  if (q.slug_product && q.slug_store) {
    const raw = await queryOne("SELECT * FROM stores WHERE slug = ? AND active = 1", [q.slug_store]);
    if (!raw) return { success: false, data: null };
    const store = parseStore(raw);
    const product = (store.products || []).find((p) => p.slug === q.slug_product && p.published !== false);
    if (!product) return { success: false, data: null };
    const { member_password, member_email, ...safeStore } = store;
    return { success: true, data: { store: safeStore, product } };
  }
  const rows = await query("SELECT * FROM stores WHERE active = 1");
  const stores = rows.map((r) => {
    const s = parseStore(r);
    const { member_password, member_email, ...safe } = s;
    return { ...safe, products: void 0 };
  });
  return { success: true, data: stores };
});

export { stores_get as default };
//# sourceMappingURL=stores.get.mjs.map
