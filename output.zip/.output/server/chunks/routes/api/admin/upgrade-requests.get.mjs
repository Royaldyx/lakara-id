import { c as defineEventHandler, e as checkAuth, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const upgradeRequests_get = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const requests = await query("SELECT * FROM upgrade_requests ORDER BY created_at DESC");
  return { ok: true, data: requests };
});

export { upgradeRequests_get as default };
//# sourceMappingURL=upgrade-requests.get.mjs.map
