import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const terms_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const { content } = await readBody(event);
  const value = (content || "").toString();
  await execute(
    "INSERT INTO settings (`key`, `value`) VALUES ('member_terms', ?) ON DUPLICATE KEY UPDATE `value` = ?",
    [value, value]
  );
  return { ok: true };
});

export { terms_post as default };
//# sourceMappingURL=terms.post.mjs.map
