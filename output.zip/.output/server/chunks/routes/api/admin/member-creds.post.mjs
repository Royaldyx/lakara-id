import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, i as queryOne, j as execute, l as hashPassword } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const memberCreds_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const { storeId, email, password } = await readBody(event);
  if (!storeId) throw createError({ statusCode: 400, statusMessage: "storeId wajib diisi." });
  const exists = await queryOne("SELECT id FROM stores WHERE id = ?", [storeId]);
  if (!exists) throw createError({ statusCode: 404, statusMessage: "Toko tidak ditemukan." });
  if (email !== void 0 && password) {
    await execute(
      "UPDATE stores SET member_email = ?, member_password = ? WHERE id = ?",
      [email.trim().toLowerCase(), hashPassword(password), storeId]
    );
  } else if (email !== void 0) {
    await execute(
      "UPDATE stores SET member_email = ? WHERE id = ?",
      [email.trim().toLowerCase(), storeId]
    );
  } else if (password) {
    await execute(
      "UPDATE stores SET member_password = ? WHERE id = ?",
      [hashPassword(password), storeId]
    );
  }
  return { ok: true };
});

export { memberCreds_post as default };
//# sourceMappingURL=member-creds.post.mjs.map
