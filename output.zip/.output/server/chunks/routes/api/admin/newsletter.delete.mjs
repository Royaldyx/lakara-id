import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const newsletter_delete = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const { id } = await readBody(event);
  await execute("DELETE FROM newsletter WHERE id = ?", [id]);
  return { ok: true };
});

export { newsletter_delete as default };
//# sourceMappingURL=newsletter.delete.mjs.map
