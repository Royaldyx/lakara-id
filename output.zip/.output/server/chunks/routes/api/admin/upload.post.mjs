import { c as defineEventHandler, e as checkAuth, f as createError, u as useRuntimeConfig, v as readMultipartFormData } from '../../../_/nitro.mjs';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { join, extname } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const ALLOWED_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
const MAX_SIZE = 1.5 * 1024 * 1024;
const upload_post = defineEventHandler(async (event) => {
  var _a;
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const config = useRuntimeConfig();
  const uploadDir = join(config.dataDir, "uploads");
  if (!existsSync(uploadDir)) mkdirSync(uploadDir, { recursive: true });
  const parts = await readMultipartFormData(event);
  if (!(parts == null ? void 0 : parts.length)) throw createError({ statusCode: 400, statusMessage: "Tidak ada file yang dikirim." });
  const results = [];
  for (const part of parts) {
    if (part.name !== "file" || !((_a = part.data) == null ? void 0 : _a.length)) continue;
    if (part.data.length > MAX_SIZE) {
      throw createError({ statusCode: 400, statusMessage: `File "${part.filename}" terlalu besar (maks 1.5MB). Kompres dulu di squoosh.app atau tinypng.com.` });
    }
    const ext = extname(part.filename || "").toLowerCase();
    if (!ALLOWED_EXTS.includes(ext)) {
      throw createError({ statusCode: 400, statusMessage: `Format "${ext}" tidak didukung. Gunakan JPG, PNG, atau WebP.` });
    }
    const filename = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}${ext}`;
    writeFileSync(join(uploadDir, filename), part.data);
    results.push({ url: `/api/file/${filename}`, filename });
  }
  if (!results.length) throw createError({ statusCode: 400, statusMessage: "Tidak ada file valid yang dikirim." });
  return results.length === 1 ? { ok: true, ...results[0] } : { ok: true, files: results };
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
