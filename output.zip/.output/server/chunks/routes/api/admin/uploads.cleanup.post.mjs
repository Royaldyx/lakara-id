import { c as defineEventHandler, e as checkAuth, f as createError, q as query, w as cleanupUnusedUploads } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const uploads_cleanup_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const rows = await query("SELECT logo, products, links_bio FROM stores");
  const result = await cleanupUnusedUploads(rows);
  return { ok: true, ...result };
});

export { uploads_cleanup_post as default };
//# sourceMappingURL=uploads.cleanup.post.mjs.map
