import { c as defineEventHandler, e as checkAuth, f as createError, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { existsSync, readdirSync, statSync } from 'fs';
import { join } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const uploads_get = defineEventHandler((event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const config = useRuntimeConfig();
  const uploadDir = join(config.dataDir, "uploads");
  if (!existsSync(uploadDir)) return { ok: true, data: [] };
  const IMAGES = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
  const files = readdirSync(uploadDir).filter((f) => IMAGES.some((ext) => f.toLowerCase().endsWith(ext))).map((f) => {
    const stat = statSync(join(uploadDir, f));
    return {
      filename: f,
      url: `/api/file/${f}`,
      size: stat.size,
      created: stat.birthtime.toISOString()
    };
  }).sort((a, b) => b.created.localeCompare(a.created));
  return { ok: true, data: files };
});

export { uploads_get as default };
//# sourceMappingURL=uploads.get.mjs.map
