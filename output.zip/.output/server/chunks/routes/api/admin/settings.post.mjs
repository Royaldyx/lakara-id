import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, o as getDb } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const settings_post = defineEventHandler(async (event) => {
  var _a;
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = (_a = await readBody(event)) != null ? _a : {};
  const db = getDb();
  const conn = await db.getConnection();
  await conn.beginTransaction();
  try {
    for (const [key, value] of Object.entries(body)) {
      const serialized = typeof value === "string" ? value : JSON.stringify(value);
      await conn.execute(
        "INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?",
        [key, serialized, serialized]
      );
    }
    await conn.commit();
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
  return { ok: true };
});

export { settings_post as default };
//# sourceMappingURL=settings.post.mjs.map
