import { c as defineEventHandler, e as checkAuth, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const members_get = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const stores = await query(
    "SELECT id, slug, name, member_email, member_active, active, member_password, products, product_tier, tier_started_at, tier_expires_at, created_at FROM stores"
  );
  const members = stores.map((s) => ({
    store_id: s.id,
    store_name: s.name,
    store_slug: s.slug,
    member_email: s.member_email,
    member_active: s.member_active === 1 || s.member_active === true,
    store_active: s.active === 1 || s.active === true,
    has_password: !!s.member_password,
    product_count: (() => {
      try {
        return JSON.parse(s.products || "[]").length;
      } catch {
        return 0;
      }
    })(),
    product_tier: s.product_tier || "free",
    tier_started_at: s.tier_started_at,
    tier_expires_at: s.tier_expires_at,
    created_at: s.created_at
  }));
  return { ok: true, data: members };
});

export { members_get as default };
//# sourceMappingURL=members.get.mjs.map
