import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, i as queryOne, j as execute, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const faq_post = defineEventHandler(async (event) => {
  var _a;
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = await readBody(event);
  const { action, id, question, answer, sort_order, active } = body;
  if (action === "create") {
    if (!(question == null ? void 0 : question.trim()) || !(answer == null ? void 0 : answer.trim()))
      throw createError({ statusCode: 400, statusMessage: "Pertanyaan dan jawaban wajib diisi." });
    const maxRow = await queryOne("SELECT COALESCE(MAX(sort_order),0) AS m FROM faqs");
    const nextOrder = ((_a = maxRow == null ? void 0 : maxRow.m) != null ? _a : 0) + 1;
    await execute(
      "INSERT INTO faqs (question, answer, sort_order, active) VALUES (?, ?, ?, 1)",
      [question.trim(), answer.trim(), sort_order != null ? sort_order : nextOrder]
    );
    const rows = await query("SELECT id, question, answer, sort_order, active FROM faqs ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  if (action === "update") {
    if (!id) throw createError({ statusCode: 400, statusMessage: "ID wajib diisi." });
    const fields = [];
    const values = [];
    if (question !== void 0) {
      fields.push("question = ?");
      values.push(question.trim());
    }
    if (answer !== void 0) {
      fields.push("answer = ?");
      values.push(answer.trim());
    }
    if (sort_order !== void 0) {
      fields.push("sort_order = ?");
      values.push(Number(sort_order));
    }
    if (active !== void 0) {
      fields.push("active = ?");
      values.push(active ? 1 : 0);
    }
    if (!fields.length) throw createError({ statusCode: 400, statusMessage: "Tidak ada perubahan." });
    values.push(id);
    await execute(`UPDATE faqs SET ${fields.join(", ")} WHERE id = ?`, values);
    const rows = await query("SELECT id, question, answer, sort_order, active FROM faqs ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  if (action === "delete") {
    if (!id) throw createError({ statusCode: 400, statusMessage: "ID wajib diisi." });
    await execute("DELETE FROM faqs WHERE id = ?", [id]);
    const rows = await query("SELECT id, question, answer, sort_order, active FROM faqs ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  throw createError({ statusCode: 400, statusMessage: "Action tidak dikenal." });
});

export { faq_post as default };
//# sourceMappingURL=faq.post.mjs.map
