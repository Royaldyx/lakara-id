import { c as defineEventHandler, u as useRuntimeConfig, g as readBody, h as setCookie } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const auth_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const body = await readBody(event);
  if ((body == null ? void 0 : body.username) === config.adminUser && (body == null ? void 0 : body.password) === config.adminPass) {
    setCookie(event, "lakara_admin", "true", {
      maxAge: 60 * 60 * 8,
      path: "/",
      sameSite: "strict",
      httpOnly: false
      // perlu false agar useCookie di client bisa baca
    });
    return { ok: true };
  }
  return { ok: false, message: "Username atau password salah." };
});

export { auth_post as default };
//# sourceMappingURL=auth.post.mjs.map
