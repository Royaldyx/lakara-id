import { c as defineEventHandler, e as checkAuth, f as createError, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const newsletter_get = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const items = await query("SELECT * FROM newsletter ORDER BY created_at DESC");
  return { ok: true, data: items };
});

export { newsletter_get as default };
//# sourceMappingURL=newsletter.get.mjs.map
