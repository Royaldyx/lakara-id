import { c as defineEventHandler, e as checkAuth, f as createError, u as useRuntimeConfig, g as readBody } from '../../../_/nitro.mjs';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { resolve, dirname } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const seo_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const config = useRuntimeConfig();
  const body = await readBody(event);
  const file = resolve(config.dataDir, "seo.json");
  const dir = dirname(file);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  writeFileSync(file, JSON.stringify(body != null ? body : {}, null, 2), "utf-8");
  return { ok: true };
});

export { seo_post as default };
//# sourceMappingURL=seo.post.mjs.map
