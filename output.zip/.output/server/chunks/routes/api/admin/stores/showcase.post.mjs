import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, j as execute } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const showcase_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = await readBody(event);
  const id = (body.id || "").toString();
  if (!id) throw createError({ statusCode: 400, statusMessage: "id toko wajib." });
  await execute("UPDATE stores SET show_on_showcase = ? WHERE id = ?", [body.value ? 1 : 0, id]);
  return { ok: true };
});

export { showcase_post as default };
//# sourceMappingURL=showcase.post.mjs.map
