import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, i as queryOne, j as execute, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const testimoni_post = defineEventHandler(async (event) => {
  var _a;
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = await readBody(event);
  const { action, id, name, role, text, rating, avatar, sort_order, active } = body;
  if (action === "create") {
    if (!(name == null ? void 0 : name.trim()) || !(text == null ? void 0 : text.trim()))
      throw createError({ statusCode: 400, statusMessage: "Nama dan teks testimoni wajib diisi." });
    const maxRow = await queryOne("SELECT COALESCE(MAX(sort_order),0) AS m FROM testimonials");
    const nextOrder = ((_a = maxRow == null ? void 0 : maxRow.m) != null ? _a : 0) + 1;
    await execute(
      "INSERT INTO testimonials (name, role, text, rating, avatar, sort_order, active) VALUES (?, ?, ?, ?, ?, ?, 1)",
      [name.trim(), (role == null ? void 0 : role.trim()) || "", text.trim(), Number(rating != null ? rating : 5), (avatar == null ? void 0 : avatar.trim()) || "", sort_order != null ? sort_order : nextOrder]
    );
    const rows = await query("SELECT id, name, role, text, rating, avatar, sort_order, active FROM testimonials ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  if (action === "update") {
    if (!id) throw createError({ statusCode: 400, statusMessage: "ID wajib diisi." });
    const fields = [];
    const values = [];
    if (name !== void 0) {
      fields.push("name = ?");
      values.push(name.trim());
    }
    if (role !== void 0) {
      fields.push("role = ?");
      values.push(role.trim());
    }
    if (text !== void 0) {
      fields.push("text = ?");
      values.push(text.trim());
    }
    if (rating !== void 0) {
      fields.push("rating = ?");
      values.push(Number(rating));
    }
    if (avatar !== void 0) {
      fields.push("avatar = ?");
      values.push(avatar.trim());
    }
    if (sort_order !== void 0) {
      fields.push("sort_order = ?");
      values.push(Number(sort_order));
    }
    if (active !== void 0) {
      fields.push("active = ?");
      values.push(active ? 1 : 0);
    }
    if (!fields.length) throw createError({ statusCode: 400, statusMessage: "Tidak ada perubahan." });
    values.push(id);
    await execute(`UPDATE testimonials SET ${fields.join(", ")} WHERE id = ?`, values);
    const rows = await query("SELECT id, name, role, text, rating, avatar, sort_order, active FROM testimonials ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  if (action === "delete") {
    if (!id) throw createError({ statusCode: 400, statusMessage: "ID wajib diisi." });
    await execute("DELETE FROM testimonials WHERE id = ?", [id]);
    const rows = await query("SELECT id, name, role, text, rating, avatar, sort_order, active FROM testimonials ORDER BY sort_order ASC, id ASC");
    return { success: true, data: rows };
  }
  throw createError({ statusCode: 400, statusMessage: "Action tidak dikenal." });
});

export { testimoni_post as default };
//# sourceMappingURL=testimoni.post.mjs.map
