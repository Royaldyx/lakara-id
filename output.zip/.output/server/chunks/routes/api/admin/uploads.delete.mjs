import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { existsSync, unlinkSync } from 'fs';
import { join, basename } from 'path';
import 'crypto';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const uploads_delete = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const { filename } = await readBody(event);
  if (!filename || filename.includes("..") || filename.includes("/"))
    throw createError({ statusCode: 400, statusMessage: "Nama file tidak valid." });
  const config = useRuntimeConfig();
  const filepath = join(config.dataDir, "uploads", basename(filename));
  if (!existsSync(filepath)) throw createError({ statusCode: 404, statusMessage: "File tidak ditemukan." });
  unlinkSync(filepath);
  return { ok: true };
});

export { uploads_delete as default };
//# sourceMappingURL=uploads.delete.mjs.map
