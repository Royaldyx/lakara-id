import { c as defineEventHandler, e as checkAuth, f as createError, r as readJson } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const artikel_get = defineEventHandler((event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  return readJson("artikel.json");
});

export { artikel_get as default };
//# sourceMappingURL=artikel.get.mjs.map
