import { c as defineEventHandler, e as checkAuth, f as createError, q as query, p as parseStore } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const stores_get = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const stores = await query("SELECT * FROM stores ORDER BY created_at DESC");
  return stores.map(parseStore);
});

export { stores_get as default };
//# sourceMappingURL=stores.get.mjs.map
