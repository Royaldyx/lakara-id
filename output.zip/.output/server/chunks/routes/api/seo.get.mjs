import { c as defineEventHandler, n as readJsonObj, x as getQuery } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const seo_get = defineEventHandler((event) => {
  const data = readJsonObj("seo.json");
  const page = getQuery(event).page;
  if (page && data[page]) return { success: true, data: data[page] };
  return { success: true, data };
});

export { seo_get as default };
//# sourceMappingURL=seo.get.mjs.map
