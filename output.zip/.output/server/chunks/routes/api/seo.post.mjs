import { c as defineEventHandler, e as checkAuth, f as createError, g as readBody, n as readJsonObj, _ as writeJson } from '../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const seo_post = defineEventHandler(async (event) => {
  if (!checkAuth(event)) throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  const body = await readBody(event);
  const current = readJsonObj("seo.json");
  const merged = { ...current, ...body };
  const ok = writeJson("seo.json", merged);
  if (!ok) throw createError({ statusCode: 500, statusMessage: "Gagal menyimpan data." });
  return { success: true };
});

export { seo_post as default };
//# sourceMappingURL=seo.post.mjs.map
