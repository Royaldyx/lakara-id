import { c as defineEventHandler, E as getMemberStore, g as readBody, f as createError, m as slugify, i as queryOne, j as execute, F as safeMemberStore } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const RESERVED_SLUGS = [
  "about",
  "contact",
  "pricing",
  "portfolio",
  "services",
  "artikel",
  "layanan",
  "member",
  "admin",
  "kalkulator",
  "privacy",
  "terms",
  "api",
  "sitemap",
  "favicon",
  "robots",
  "lakara",
  "hapus-akun",
  "showcase",
  "client"
];
const changeSlug_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const { slug: rawSlug } = await readBody(event);
  if (!rawSlug || typeof rawSlug !== "string")
    throw createError({ statusCode: 400, statusMessage: "URL toko wajib diisi." });
  const slug = slugify(rawSlug);
  if (!slug)
    throw createError({ statusCode: 400, statusMessage: "URL tidak valid. Gunakan huruf, angka, atau tanda hubung." });
  if (slug === store.slug)
    throw createError({ statusCode: 400, statusMessage: "URL baru sama dengan yang sekarang." });
  if (RESERVED_SLUGS.includes(slug))
    throw createError({ statusCode: 400, statusMessage: `URL "${slug}" tidak bisa digunakan. Pilih yang lain.` });
  const taken = await queryOne("SELECT id FROM stores WHERE slug = ? AND id != ?", [slug, store.id]);
  if (taken)
    throw createError({ statusCode: 400, statusMessage: `URL "/${slug}" sudah dipakai. Pilih yang lain.` });
  await execute("UPDATE stores SET slug = ? WHERE id = ?", [slug, store.id]);
  return { ok: true, data: safeMemberStore({ ...store, slug }) };
});

export { changeSlug_post as default };
//# sourceMappingURL=change-slug.post.mjs.map
