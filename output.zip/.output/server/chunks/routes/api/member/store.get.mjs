import { c as defineEventHandler, E as getMemberStore, F as safeMemberStore } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const store_get = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  return { ok: true, data: safeMemberStore(store) };
});

export { store_get as default };
//# sourceMappingURL=store.get.mjs.map
