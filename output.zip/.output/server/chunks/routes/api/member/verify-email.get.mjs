import { c as defineEventHandler, x as getQuery, f as createError, i as queryOne, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const verifyEmail_get = defineEventHandler(async (event) => {
  const token = (getQuery(event).token || "").toString().trim();
  if (!token)
    throw createError({ statusCode: 400, statusMessage: "Token verifikasi tidak ada." });
  const row = await queryOne(
    "SELECT store_id, email FROM email_verifications WHERE token = ? AND expires_at > NOW()",
    [token]
  );
  if (!row) {
    throw createError({ statusCode: 400, statusMessage: "Link verifikasi tidak valid atau sudah kedaluwarsa. Silakan kirim ulang." });
  }
  await execute("UPDATE stores SET email_verified = 1 WHERE id = ?", [row.store_id]);
  await execute("DELETE FROM email_verifications WHERE store_id = ?", [row.store_id]);
  return { ok: true, email: row.email };
});

export { verifyEmail_get as default };
//# sourceMappingURL=verify-email.get.mjs.map
