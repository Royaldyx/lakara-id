import { c as defineEventHandler, E as getMemberStore, g as readBody, f as createError, i as queryOne, j as execute } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const cancel_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const { merchant_ref } = await readBody(event);
  if (!merchant_ref)
    throw createError({ statusCode: 400, statusMessage: "merchant_ref diperlukan." });
  const payment = await queryOne(
    "SELECT id, store_id, status FROM payments WHERE id = ? AND store_id = ?",
    [merchant_ref, store.id]
  );
  if (!payment)
    throw createError({ statusCode: 404, statusMessage: "Transaksi tidak ditemukan." });
  if (payment.status !== "pending")
    throw createError({ statusCode: 400, statusMessage: "Transaksi tidak bisa dibatalkan (sudah diproses)." });
  await execute(
    "UPDATE payments SET status = 'cancelled', updated_at = NOW() WHERE id = ?",
    [merchant_ref]
  );
  return { ok: true };
});

export { cancel_post as default };
//# sourceMappingURL=cancel.post.mjs.map
