import { c as defineEventHandler, E as getMemberStore, i as queryOne } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const pending_get = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const payment = await queryOne(
    `SELECT id, tier_type, months, amount, method, expired_at
     FROM payments
     WHERE store_id = ? AND status = 'pending' AND expired_at > NOW()
     ORDER BY created_at DESC LIMIT 1`,
    [store.id]
  );
  return { payment: payment || null };
});

export { pending_get as default };
//# sourceMappingURL=pending.get.mjs.map
