import { c as defineEventHandler, E as getMemberStore, u as useRuntimeConfig, g as readBody, f as createError, T as TRIPAY_CHANNELS, i as queryOne, J as createTripayTransaction, j as execute, q as query } from '../../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

async function getSettings() {
  const rows = await query("SELECT `key`, `value` FROM settings");
  const result = {};
  for (const row of rows) {
    try {
      result[row.key] = JSON.parse(row.value);
    } catch {
      result[row.key] = row.value;
    }
  }
  return result;
}
const create_post = defineEventHandler(async (event) => {
  var _a;
  const store = await getMemberStore(event);
  const cfg = useRuntimeConfig();
  const body = await readBody(event);
  const { tier_type, payment_method, months: rawMonths } = body;
  const tier = tier_type === "premium" ? "premium" : "pro";
  const months = Math.max(1, Math.min(12, Number(rawMonths) || 1));
  const billedMonths = months === 12 ? 10 : months;
  if (store.product_tier === "premium")
    throw createError({ statusCode: 400, statusMessage: "Akun kamu sudah Premium." });
  if (store.product_tier === "pro" && tier === "pro")
    throw createError({ statusCode: 400, statusMessage: "Akun kamu sudah Pro." });
  const channel = TRIPAY_CHANNELS.find((c) => c.code === payment_method);
  if (!channel)
    throw createError({ statusCode: 400, statusMessage: "Metode pembayaran tidak valid." });
  const settings = await getSettings();
  const unitPrice = tier === "premium" ? Number(settings.premium_price) || 35e3 : Number(settings.pro_price) || 9e3;
  const amount = unitPrice * billedMonths;
  if (amount < channel.minAmount)
    throw createError({
      statusCode: 400,
      statusMessage: `Nominal terlalu kecil untuk ${channel.name}. Minimum Rp ${channel.minAmount.toLocaleString("id-ID")}.`
    });
  const existing = await queryOne(
    "SELECT id FROM payments WHERE store_id = ? AND status = 'pending' AND expired_at > NOW()",
    [store.id]
  );
  if (existing)
    throw createError({ statusCode: 400, statusMessage: "Kamu masih punya pembayaran yang belum selesai." });
  const merchantRef = `LKR-${Date.now()}-${store.id.slice(0, 6)}`;
  const expiredTime = Math.floor(Date.now() / 1e3) + 24 * 60 * 60;
  const expiredAt = new Date(expiredTime * 1e3);
  const appUrl = cfg.appUrl || "https://lakara.id";
  const returnUrl = `${appUrl}/member/payment/${merchantRef}`;
  const callbackUrl = `${appUrl}/api/tripay/callback`;
  let tripayData;
  try {
    tripayData = await createTripayTransaction({
      method: payment_method,
      merchant_ref: merchantRef,
      amount,
      customer_name: (store.name || "Member Lakara").slice(0, 50),
      customer_email: store.member_email && !store.member_email.includes("@lakara.local") ? store.member_email : "member@lakara.id",
      order_items: [{
        name: `Lakara ${tier === "premium" ? "Premium" : "Pro"} ${months} bulan${months === 12 ? " (hemat 2 bln)" : ""}`,
        price: unitPrice,
        quantity: billedMonths
      }],
      return_url: returnUrl,
      callback_url: callbackUrl,
      expired_time: expiredTime
    });
  } catch (err) {
    const tripayMessage = ((_a = err == null ? void 0 : err.data) == null ? void 0 : _a.message) || (typeof (err == null ? void 0 : err.data) === "string" ? err.data : null) || (err == null ? void 0 : err.message) || "Gagal membuat transaksi Tripay.";
    console.error("[Tripay Error]", JSON.stringify({ status: err == null ? void 0 : err.statusCode, data: err == null ? void 0 : err.data }));
    throw createError({ statusCode: 502, statusMessage: tripayMessage });
  }
  await execute(
    `INSERT INTO payments
       (id, tripay_ref, store_id, tier_type, months, amount, method, method_type,
        pay_code, pay_url, checkout_url, qr_url, qr_string, status, expired_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    [
      merchantRef,
      tripayData.reference,
      store.id,
      tier,
      months,
      amount,
      payment_method,
      channel.type,
      tripayData.pay_code || null,
      tripayData.pay_url || null,
      tripayData.checkout_url || null,
      tripayData.qr_url || null,
      tripayData.qr_string || null,
      expiredAt
    ]
  );
  return {
    ok: true,
    merchant_ref: merchantRef,
    tripay_ref: tripayData.reference,
    method: payment_method,
    method_type: channel.type,
    amount,
    pay_code: tripayData.pay_code || null,
    pay_url: tripayData.pay_url || null,
    checkout_url: tripayData.checkout_url || null,
    qr_url: tripayData.qr_url || null,
    qr_string: tripayData.qr_string || null,
    expired_at: expiredAt.toISOString()
  };
});

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
