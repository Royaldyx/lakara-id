import { c as defineEventHandler, E as getMemberStore, g as readBody, f as createError, l as hashPassword, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const password_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const { current_password, new_password } = await readBody(event);
  if (!current_password || !new_password)
    throw createError({ statusCode: 400, statusMessage: "Semua field wajib diisi." });
  if (new_password.length < 6)
    throw createError({ statusCode: 400, statusMessage: "Password baru minimal 6 karakter." });
  if (store.member_password !== hashPassword(current_password))
    throw createError({ statusCode: 401, statusMessage: "Password saat ini salah." });
  await execute("UPDATE stores SET member_password = ? WHERE id = ?", [hashPassword(new_password), store.id]);
  return { ok: true };
});

export { password_post as default };
//# sourceMappingURL=password.post.mjs.map
