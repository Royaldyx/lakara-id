import { c as defineEventHandler, E as getMemberStore, f as createError, x as getQuery, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const PAGE_VIEW_ID = "__view__";
const analytics_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const store = await getMemberStore(event);
  if (!["pro", "premium"].includes(store.product_tier || "")) {
    throw createError({ statusCode: 403, statusMessage: "Fitur analytics tersedia untuk member Pro dan Premium." });
  }
  const urlQuery = getQuery(event);
  const days = Math.min(Math.max(Number(urlQuery.days) || 30, 1), 90);
  const isPremium = store.product_tier === "premium";
  const totalsNow = await query(
    `SELECT CASE WHEN link_id = ? THEN 'view' ELSE 'click' END AS kind, COUNT(*) AS total
     FROM link_clicks
     WHERE store_id = ?
       AND clicked_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
     GROUP BY kind`,
    [PAGE_VIEW_ID, store.id, days]
  );
  const clicks = Number(((_a = totalsNow.find((r) => r.kind === "click")) == null ? void 0 : _a.total) || 0);
  const views = Number(((_b = totalsNow.find((r) => r.kind === "view")) == null ? void 0 : _b.total) || 0);
  const totalsPrev = await query(
    `SELECT CASE WHEN link_id = ? THEN 'view' ELSE 'click' END AS kind, COUNT(*) AS total
     FROM link_clicks
     WHERE store_id = ?
       AND clicked_at <  DATE_SUB(NOW(), INTERVAL ? DAY)
       AND clicked_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
     GROUP BY kind`,
    [PAGE_VIEW_ID, store.id, days, days * 2]
  );
  const clicksPrev = Number(((_c = totalsPrev.find((r) => r.kind === "click")) == null ? void 0 : _c.total) || 0);
  const viewsPrev = Number(((_d = totalsPrev.find((r) => r.kind === "view")) == null ? void 0 : _d.total) || 0);
  const todayRows = await query(
    `SELECT COUNT(*) AS total
     FROM link_clicks
     WHERE store_id = ?
       AND link_id <> ?
       AND DATE(clicked_at) = CURDATE()`,
    [store.id, PAGE_VIEW_ID]
  );
  const clicksToday = Number(((_e = todayRows[0]) == null ? void 0 : _e.total) || 0);
  const rows = await query(
    `SELECT link_id, COUNT(*) AS total
     FROM link_clicks
     WHERE store_id = ?
       AND link_id <> ?
       AND clicked_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
     GROUP BY link_id
     ORDER BY total DESC`,
    [store.id, PAGE_VIEW_ID, days]
  );
  const dailyDays = isPremium ? days : Math.min(days, 7);
  const dailyRows = await query(
    `SELECT DATE(clicked_at) AS date,
            SUM(CASE WHEN link_id = ? THEN 0 ELSE 1 END) AS clicks,
            SUM(CASE WHEN link_id = ? THEN 1 ELSE 0 END) AS views
     FROM link_clicks
     WHERE store_id = ?
       AND clicked_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
     GROUP BY DATE(clicked_at)
     ORDER BY date ASC`,
    [PAGE_VIEW_ID, PAGE_VIEW_ID, store.id, dailyDays]
  );
  const pct = (now, prev) => prev === 0 ? now > 0 ? 100 : 0 : Math.round((now - prev) / prev * 100);
  return {
    ok: true,
    days,
    tier: store.product_tier,
    totals: {
      clicks,
      views,
      clicks_today: clicksToday,
      ctr: views > 0 ? Math.round(clicks / views * 1e3) / 10 : 0,
      // % 1 desimal
      clicks_growth: pct(clicks, clicksPrev),
      views_growth: pct(views, viewsPrev)
    },
    by_link: rows.map((r) => ({ link_id: r.link_id, total: Number(r.total) })),
    daily: dailyRows.map((r) => ({
      date: typeof r.date === "string" ? r.date : new Date(r.date).toISOString().slice(0, 10),
      clicks: Number(r.clicks),
      views: Number(r.views)
    }))
  };
});

export { analytics_get as default };
//# sourceMappingURL=analytics.get.mjs.map
