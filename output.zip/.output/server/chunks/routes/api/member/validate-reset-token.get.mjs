import { c as defineEventHandler, x as getQuery, f as createError, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const validateResetToken_get = defineEventHandler(async (event) => {
  const token = (getQuery(event).token || "").toString().trim();
  if (!token)
    throw createError({ statusCode: 400, statusMessage: "Token tidak valid." });
  const entry = await queryOne(
    "SELECT id FROM reset_tokens WHERE token = ? AND expires_at > NOW()",
    [token]
  );
  if (!entry)
    throw createError({ statusCode: 400, statusMessage: "Link reset password tidak valid atau sudah kedaluwarsa." });
  return { ok: true };
});

export { validateResetToken_get as default };
//# sourceMappingURL=validate-reset-token.get.mjs.map
