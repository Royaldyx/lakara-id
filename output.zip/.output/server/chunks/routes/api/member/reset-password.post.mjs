import { c as defineEventHandler, g as readBody, f as createError, i as queryOne, j as execute, l as hashPassword } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const resetPassword_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const token = (body.token || "").toString().trim();
  const password = (body.password || "").toString();
  if (!token)
    throw createError({ statusCode: 400, statusMessage: "Token tidak valid." });
  if (!password || password.length < 6)
    throw createError({ statusCode: 400, statusMessage: "Password minimal 6 karakter." });
  if (password.length > 100)
    throw createError({ statusCode: 400, statusMessage: "Password terlalu panjang." });
  const entry = await queryOne(
    "SELECT * FROM reset_tokens WHERE token = ? AND expires_at > NOW()",
    [token]
  );
  if (!entry)
    throw createError({ statusCode: 400, statusMessage: "Link reset password tidak valid atau sudah kedaluwarsa." });
  const storeExists = await queryOne("SELECT id FROM stores WHERE id = ?", [entry.store_id]);
  if (!storeExists)
    throw createError({ statusCode: 404, statusMessage: "Akun tidak ditemukan." });
  await execute("UPDATE stores SET member_password = ?, email_verified = 1 WHERE id = ?", [hashPassword(password), entry.store_id]);
  await execute("DELETE FROM reset_tokens WHERE token = ? OR expires_at <= NOW()", [token]);
  return { ok: true };
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
