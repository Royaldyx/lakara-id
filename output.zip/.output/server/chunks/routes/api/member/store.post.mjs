import { c as defineEventHandler, E as getMemberStore, g as readBody, f as createError, j as execute, H as deleteOrphanUploads, F as safeMemberStore } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const ALLOWED = [
  "name",
  "tagline",
  "description",
  "logo",
  "primary_color",
  "instagram",
  "tiktok",
  "whatsapp",
  "youtube",
  "why_buy",
  "show_on_showcase",
  "product_image_ratio"
];
const store_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const body = await readBody(event);
  const updates = {};
  for (const key of ALLOWED) {
    if (key in body) updates[key] = body[key];
  }
  if (Object.keys(updates).length === 0)
    throw createError({ statusCode: 400, statusMessage: "Tidak ada perubahan." });
  const setClause = Object.keys(updates).map((k) => `${k} = ?`).join(", ");
  const values = Object.values(updates).map((v) => typeof v === "object" ? JSON.stringify(v) : v);
  values.push(store.id);
  await execute(`UPDATE stores SET ${setClause} WHERE id = ?`, values);
  await deleteOrphanUploads(store, { ...store, ...updates });
  return { ok: true, data: safeMemberStore({ ...store, ...updates }) };
});

export { store_post as default };
//# sourceMappingURL=store.post.mjs.map
