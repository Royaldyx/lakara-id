import { c as defineEventHandler, E as getMemberStore } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const links_get = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const linksBio = store.links_bio || {
    title: store.name || "",
    bio: store.tagline || "",
    bg_color: "#ffffff",
    text_color: "#111111",
    accent_color: store.primary_color || "#3358ff",
    links: []
  };
  return { ok: true, data: linksBio };
});

export { links_get as default };
//# sourceMappingURL=links.get.mjs.map
