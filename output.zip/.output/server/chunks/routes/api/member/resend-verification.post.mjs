import { c as defineEventHandler, y as getHeader, z as checkRateLimit, f as createError, g as readBody, i as queryOne, K as sendVerificationEmail, A as resetAttempts } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const resendVerification_post = defineEventHandler(async (event) => {
  const ip = getHeader(event, "x-forwarded-for") || "unknown";
  const limit = checkRateLimit(`resend-verif:${ip}`);
  if (!limit.allowed) throw createError({ statusCode: 429, statusMessage: limit.message });
  const body = await readBody(event);
  const email = (body.email || "").toString().trim().toLowerCase();
  if (!email)
    throw createError({ statusCode: 400, statusMessage: "Email wajib diisi." });
  const store = await queryOne("SELECT * FROM stores WHERE member_email = ?", [email]);
  if (store && !store.email_verified) {
    try {
      await sendVerificationEmail(store);
    } catch (e) {
      console.error("[resend-verif]", e);
    }
  }
  resetAttempts(`resend-verif:${ip}`);
  return { ok: true };
});

export { resendVerification_post as default };
//# sourceMappingURL=resend-verification.post.mjs.map
