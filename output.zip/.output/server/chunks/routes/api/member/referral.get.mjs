import { c as defineEventHandler, E as getMemberStore, i as queryOne } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const referral_get = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const row = await queryOne(
    `SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN referral_rewarded = 1 THEN 1 ELSE 0 END) AS rewarded
     FROM stores WHERE referred_by = ?`,
    [store.id]
  );
  return {
    ok: true,
    code: store.slug,
    total: Number((row == null ? void 0 : row.total) || 0),
    rewarded: Number((row == null ? void 0 : row.rewarded) || 0)
  };
});

export { referral_get as default };
//# sourceMappingURL=referral.get.mjs.map
