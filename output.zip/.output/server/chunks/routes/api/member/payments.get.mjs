import { c as defineEventHandler, E as getMemberStore, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const payments_get = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const payments = await query(
    `SELECT id, tier_type, months, amount, method, status, created_at, paid_at
     FROM payments
     WHERE store_id = ?
     ORDER BY created_at DESC
     LIMIT 20`,
    [store.id]
  );
  return { payments };
});

export { payments_get as default };
//# sourceMappingURL=payments.get.mjs.map
