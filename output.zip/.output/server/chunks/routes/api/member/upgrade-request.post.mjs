import { c as defineEventHandler, E as getMemberStore, f as createError, i as queryOne, g as readBody, j as execute } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const upgradeRequest_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  if (store.product_tier === "premium")
    throw createError({ statusCode: 400, statusMessage: "Toko kamu sudah di tier Premium." });
  const hasPending = await queryOne(
    "SELECT id FROM upgrade_requests WHERE store_id = ? AND status = 'pending'",
    [store.id]
  );
  if (hasPending)
    throw createError({ statusCode: 400, statusMessage: "Kamu sudah punya request upgrade yang sedang diproses." });
  const body = await readBody(event);
  const { note } = body;
  const tier_type = body.tier_type === "premium" ? "premium" : "pro";
  if (store.product_tier === "pro" && tier_type === "pro")
    throw createError({ statusCode: 400, statusMessage: "Toko kamu sudah di tier Pro." });
  await execute(
    "INSERT INTO upgrade_requests (id, store_id, store_name, store_slug, tier_type, note, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [String(Date.now()), store.id, store.name, store.slug, tier_type, note || "", "pending"]
  );
  return { ok: true };
});

export { upgradeRequest_post as default };
//# sourceMappingURL=upgrade-request.post.mjs.map
