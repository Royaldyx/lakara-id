import { c as defineEventHandler, E as getMemberStore, i as queryOne, q as query } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

async function getSettings() {
  const rows = await query("SELECT `key`, `value` FROM settings");
  const result = {};
  for (const row of rows) {
    try {
      result[row.key] = JSON.parse(row.value);
    } catch {
      result[row.key] = row.value;
    }
  }
  return result;
}
const upgradeStatus_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const store = await getMemberStore(event);
  const settings = await getSettings();
  const pending = await queryOne(
    "SELECT id FROM upgrade_requests WHERE store_id = ? AND status = 'pending'",
    [store.id]
  );
  return {
    ok: true,
    tier: store.product_tier || "free",
    tier_expires_at: store.tier_expires_at || null,
    has_pending: !!pending,
    pro_price: (_a = settings.pro_price) != null ? _a : 9e3,
    premium_price: (_b = settings.premium_price) != null ? _b : 35e3,
    upgrade_price: (_c = settings.upgrade_price) != null ? _c : 9e3,
    // legacy fallback
    upgrade_promo: (_d = settings.upgrade_promo) != null ? _d : null,
    bank_name: settings.bank_name || "",
    bank_account: settings.bank_account || "",
    bank_holder: settings.bank_holder || ""
  };
});

export { upgradeStatus_get as default };
//# sourceMappingURL=upgrade-status.get.mjs.map
