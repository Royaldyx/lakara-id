import { c as defineEventHandler, E as getMemberStore, g as readBody, f as createError, j as execute, H as deleteOrphanUploads } from '../../../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const FREE_PRODUCT_LIMIT = 10;
const products_post = defineEventHandler(async (event) => {
  const store = await getMemberStore(event);
  const { products } = await readBody(event);
  if (!Array.isArray(products))
    throw createError({ statusCode: 400, statusMessage: "Data produk tidak valid." });
  const existingCount = (store.products || []).length;
  const isPro = store.product_tier === "pro";
  if (!isPro && products.length > existingCount && products.length > FREE_PRODUCT_LIMIT) {
    throw createError({
      statusCode: 403,
      statusMessage: `Paket Free hanya bisa menyimpan ${FREE_PRODUCT_LIMIT} produk. Upgrade ke Pro untuk produk unlimited.`
    });
  }
  await execute("UPDATE stores SET products = ? WHERE id = ?", [JSON.stringify(products), store.id]);
  await deleteOrphanUploads(store, { ...store, products });
  return { ok: true };
});

export { products_post as default };
//# sourceMappingURL=products.post.mjs.map
