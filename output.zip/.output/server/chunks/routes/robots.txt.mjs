import { c as defineEventHandler, D as setHeader } from '../_/nitro.mjs';
import 'crypto';
import 'fs';
import 'path';
import 'fs/promises';
import 'mysql2/promise';
import 'nodemailer';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const robots_txt = defineEventHandler((event) => {
  setHeader(event, "Content-Type", "text/plain; charset=utf-8");
  return `User-agent: *
Allow: /
Disallow: /admin
Disallow: /member
Disallow: /client
Disallow: /api/

Sitemap: https://lakara.id/sitemap.xml
`;
});

export { robots_txt as default };
//# sourceMappingURL=robots.txt.mjs.map
