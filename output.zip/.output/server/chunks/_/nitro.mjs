import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { createHash as createHash$1, randomBytes, createHmac } from 'crypto';
import { existsSync as existsSync$1, readFileSync, mkdirSync, writeFileSync } from 'fs';
import { join as join$1, resolve as resolve$2 } from 'path';
import { readdir as readdir$1, stat, unlink as unlink$1 } from 'fs/promises';
import mysql from 'mysql2/promise';
import nodemailer from 'nodemailer';
import http from 'node:http';
import https from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getIcons } from '@iconify/utils';
import { createHash } from 'node:crypto';
import { consola } from 'consola';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function parse(multipartBodyBuffer, boundary) {
  let lastline = "";
  let state = 0 /* INIT */;
  let buffer = [];
  const allParts = [];
  let currentPartHeaders = [];
  for (let i = 0; i < multipartBodyBuffer.length; i++) {
    const prevByte = i > 0 ? multipartBodyBuffer[i - 1] : null;
    const currByte = multipartBodyBuffer[i];
    const newLineChar = currByte === 10 || currByte === 13;
    if (!newLineChar) {
      lastline += String.fromCodePoint(currByte);
    }
    const newLineDetected = currByte === 10 && prevByte === 13;
    if (0 /* INIT */ === state && newLineDetected) {
      if ("--" + boundary === lastline) {
        state = 1 /* READING_HEADERS */;
      }
      lastline = "";
    } else if (1 /* READING_HEADERS */ === state && newLineDetected) {
      if (lastline.length > 0) {
        const i2 = lastline.indexOf(":");
        if (i2 > 0) {
          const name = lastline.slice(0, i2).toLowerCase();
          const value = lastline.slice(i2 + 1).trim();
          currentPartHeaders.push([name, value]);
        }
      } else {
        state = 2 /* READING_DATA */;
        buffer = [];
      }
      lastline = "";
    } else if (2 /* READING_DATA */ === state) {
      if (lastline.length > boundary.length + 4) {
        lastline = "";
      }
      if ("--" + boundary === lastline) {
        const j = buffer.length - lastline.length;
        const part = buffer.slice(0, j - 1);
        allParts.push(process$1(part, currentPartHeaders));
        buffer = [];
        currentPartHeaders = [];
        lastline = "";
        state = 3 /* READING_PART_SEPARATOR */;
      } else {
        buffer.push(currByte);
      }
      if (newLineDetected) {
        lastline = "";
      }
    } else if (3 /* READING_PART_SEPARATOR */ === state && newLineDetected) {
      state = 1 /* READING_HEADERS */;
    }
  }
  return allParts;
}
function process$1(data, headers) {
  const dataObj = {};
  const contentDispositionHeader = headers.find((h) => h[0] === "content-disposition")?.[1] || "";
  for (const i of contentDispositionHeader.split(";")) {
    const s = i.split("=");
    if (s.length !== 2) {
      continue;
    }
    const key = (s[0] || "").trim();
    if (key === "name" || key === "filename") {
      const _value = (s[1] || "").trim().replace(/"/g, "");
      dataObj[key] = Buffer.from(_value, "latin1").toString("utf8");
    }
  }
  const contentType = headers.find((h) => h[0] === "content-type")?.[1] || "";
  if (contentType) {
    dataObj.type = contentType;
  }
  dataObj.data = Buffer.from(data);
  return dataObj;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$1(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
async function readMultipartFormData(event) {
  const contentType = getRequestHeader(event, "content-type");
  if (!contentType || !contentType.startsWith("multipart/form-data")) {
    return;
  }
  const boundary = contentType.match(/boundary=([^;]*)(;|$)/i)?.[1];
  if (!boundary) {
    return;
  }
  const body = await readRawBody(event, false);
  if (!body) {
    return;
  }
  return parse(body, boundary);
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController });
const $fetch$1 = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const defineAppConfig = (config) => config;

const appConfig0 = defineAppConfig({
  ui: {
    primary: "indigo",
    gray: "cool",
    button: {
      rounded: "rounded-lg",
      default: {
        size: "md"
      }
    },
    card: {
      rounded: "rounded-2xl",
      shadow: "shadow-sm"
    }
  }
});

const inlineAppConfig = {
  "nuxt": {},
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "dashicons",
      "devicon",
      "devicon-plain",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fad",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "logos",
      "ls",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "pixelarticons",
      "prime",
      "ps",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "si-glyph",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "streamline",
      "streamline-emojis",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  },
  "ui": {
    "primary": "green",
    "gray": "cool",
    "colors": [
      "red",
      "orange",
      "amber",
      "yellow",
      "lime",
      "green",
      "emerald",
      "teal",
      "cyan",
      "sky",
      "blue",
      "indigo",
      "violet",
      "purple",
      "fuchsia",
      "pink",
      "rose",
      "lakara",
      "primary"
    ],
    "strategy": "merge"
  }
};

const appConfig = defuFn(appConfig0, inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function upperFirst(str) {
  return str ? str[0].toUpperCase() + str.slice(1) : "";
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "903cae45-3e06-4955-8a14-351d5557cac7",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/admin/**": {
        "ssr": false
      },
      "/admin": {
        "ssr": false
      },
      "/member/**": {
        "ssr": false
      },
      "/member": {
        "ssr": false
      },
      "/client/**": {
        "ssr": false
      },
      "/client": {
        "ssr": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {},
  "dataDir": "",
  "adminUser": "admin",
  "adminPass": "Lakara@2024",
  "cronSecret": "",
  "smtpHost": "",
  "smtpPort": "465",
  "smtpUser": "",
  "smtpPass": "",
  "smtpFrom": "Lakara <noreply@lakara.id>",
  "appUrl": "https://lakara.id",
  "dbHost": "localhost",
  "dbPort": "3306",
  "dbUser": "",
  "dbPass": "",
  "dbName": "",
  "tripayApiKey": "",
  "tripayPrivateKey": "",
  "tripayMerchantCode": "",
  "tripayMode": "sandbox",
  "icon": {
    "serverKnownCssClasses": []
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
	
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		
		return;
	}
	
	const defaultRes = await defaultHandler(error, event, { json: true });
	
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	
	const reqHeaders = getRequestHeaders(event);
	
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"] || !!event.context.nuxt?.["~rendering-error"];
	if (!isRenderingError) {
		event.context.nuxt ||= {};
		event.context.nuxt["~rendering-error"] = true;
	}
	
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	
	if (!res) {
		const { template } = await import('./error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"light\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _AHn3tdRtXUEOu9sd_YImjqy12LdAMi1zcwhudXsXsPI = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _AHn3tdRtXUEOu9sd_YImjqy12LdAMi1zcwhudXsXsPI
];

const assets = {
  "/.htaccess": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"b1-e9VMrEboH9Pz7Fr60EDr93JQyfU\"",
    "mtime": "2026-06-17T11:17:58.457Z",
    "size": 177,
    "path": "../public/.htaccess"
  },
  "/favicon-round.svg": {
    "type": "image/svg+xml",
    "etag": "\"9ce-OLXMx5Ri2dAiTawbV7otJihPfCg\"",
    "mtime": "2026-06-17T11:17:58.501Z",
    "size": 2510,
    "path": "../public/favicon-round.svg"
  },
  "/apple-touch-icon.png": {
    "type": "image/png",
    "etag": "\"153b-p9aiI6LNTTye8Rrro3eDFj0wUzc\"",
    "mtime": "2026-06-17T11:17:58.465Z",
    "size": 5435,
    "path": "../public/apple-touch-icon.png"
  },
  "/favicon-16.png": {
    "type": "image/png",
    "etag": "\"200-BAUJyivL21+TCscbEHM+UmfoYxw\"",
    "mtime": "2026-06-17T11:17:58.472Z",
    "size": 512,
    "path": "../public/favicon-16.png"
  },
  "/favicon-32.png": {
    "type": "image/png",
    "etag": "\"3cf-CuWvCA2VDBNgO0hVgJ0fCj0iQ4Y\"",
    "mtime": "2026-06-17T11:17:58.486Z",
    "size": 975,
    "path": "../public/favicon-32.png"
  },
  "/favicon-180.png": {
    "type": "image/png",
    "etag": "\"153b-p9aiI6LNTTye8Rrro3eDFj0wUzc\"",
    "mtime": "2026-06-17T11:17:58.480Z",
    "size": 5435,
    "path": "../public/favicon-180.png"
  },
  "/favicon-48.png": {
    "type": "image/png",
    "etag": "\"5a7-KqUquuweqMGOuG8z9XaIldpwA4s\"",
    "mtime": "2026-06-17T11:17:58.495Z",
    "size": 1447,
    "path": "../public/favicon-48.png"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"5f5-r3N3TisyDIMubMJujObMzATAenk\"",
    "mtime": "2026-06-17T11:17:58.508Z",
    "size": 1525,
    "path": "../public/favicon.ico"
  },
  "/favicon.svg": {
    "type": "image/svg+xml",
    "etag": "\"990-ee27zmrDP2xSfYHOjGn5JA8rI2c\"",
    "mtime": "2026-06-17T11:17:58.515Z",
    "size": 2448,
    "path": "../public/favicon.svg"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"258-pxuXvhQpEpdTZs8QH3ecfIyWY3w\"",
    "mtime": "2026-06-17T13:08:50.330Z",
    "size": 600,
    "path": "../public/sw.js"
  },
  "/icon-maskable.svg": {
    "type": "image/svg+xml",
    "etag": "\"22b-Zt+u5W+YW/14diTf0naRmU3+RMM\"",
    "mtime": "2026-06-17T13:08:22.443Z",
    "size": 555,
    "path": "../public/icon-maskable.svg"
  },
  "/og-cover.svg": {
    "type": "image/svg+xml",
    "etag": "\"f4d-KJqvWo99H1H3lK0Fxod7YvF20QM\"",
    "mtime": "2026-06-17T11:17:58.529Z",
    "size": 3917,
    "path": "../public/og-cover.svg"
  },
  "/og-cover.png.png": {
    "type": "image/png",
    "etag": "\"5c1f-wMXLJXQ1JVkS4RNiwPQ4KG1r/NM\"",
    "mtime": "2026-06-17T11:17:58.522Z",
    "size": 23583,
    "path": "../public/og-cover.png.png"
  },
  "/stock/forest.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-yZ/8Mj0ck6l0C1WxQ81fkfFzwLw\"",
    "mtime": "2026-06-17T11:17:58.545Z",
    "size": 380,
    "path": "../public/stock/forest.svg"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"3f9-G5TLamk5vyZ8esSO3rLTprxSd4k\"",
    "mtime": "2026-06-17T13:08:29.587Z",
    "size": 1017,
    "path": "../public/manifest.webmanifest"
  },
  "/stock/dark-minimal.svg": {
    "type": "image/svg+xml",
    "etag": "\"157-6rclAW5Nb7LE10eB/1IoCM9nl/4\"",
    "mtime": "2026-06-17T11:17:58.538Z",
    "size": 343,
    "path": "../public/stock/dark-minimal.svg"
  },
  "/stock/mesh.svg": {
    "type": "image/svg+xml",
    "etag": "\"148-AlD3Wkzta/yMzpbcw48Q8CUQ7OU\"",
    "mtime": "2026-06-17T11:17:58.560Z",
    "size": 328,
    "path": "../public/stock/mesh.svg"
  },
  "/stock/gaming-neon.svg": {
    "type": "image/svg+xml",
    "etag": "\"28a-hnay1UcxS1n39eoMQUXfjhOL3Xg\"",
    "mtime": "2026-06-17T11:17:58.551Z",
    "size": 650,
    "path": "../public/stock/gaming-neon.svg"
  },
  "/stock/ocean.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a5-beK9omIH4mB6/983CfERNL6aG1U\"",
    "mtime": "2026-06-17T11:17:58.574Z",
    "size": 421,
    "path": "../public/stock/ocean.svg"
  },
  "/stock/pastel.svg": {
    "type": "image/svg+xml",
    "etag": "\"17a-XVba45BnIY/Y+NFwI80/tG45N8k\"",
    "mtime": "2026-06-17T11:17:58.582Z",
    "size": 378,
    "path": "../public/stock/pastel.svg"
  },
  "/stock/mono-light.svg": {
    "type": "image/svg+xml",
    "etag": "\"110-6E9eVg8DrTSzsJv+7wRCaKJbc6E\"",
    "mtime": "2026-06-17T11:17:58.567Z",
    "size": 272,
    "path": "../public/stock/mono-light.svg"
  },
  "/.well-known/assetlinks.json": {
    "type": "application/json",
    "etag": "\"112-9g8x/joVoSXtjumvMsm/WlVCdfE\"",
    "mtime": "2026-06-17T13:09:18.097Z",
    "size": 274,
    "path": "../public/.well-known/assetlinks.json"
  },
  "/stock/sunset.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-HDWc0eVCFwG31Xix5fYUs1fhjnU\"",
    "mtime": "2026-06-17T11:17:58.589Z",
    "size": 380,
    "path": "../public/stock/sunset.svg"
  },
  "/_nuxt/-4j8CrVv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"985-3LNM1SN8tYvMGG08/4JEAhv9TWA\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 2437,
    "path": "../public/_nuxt/-4j8CrVv.js"
  },
  "/_nuxt/0Ye0GjCj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16b-wvB7IBdxqJxiYgaeaOAwpny4gns\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 363,
    "path": "../public/_nuxt/0Ye0GjCj.js"
  },
  "/_nuxt/5dWx9PTI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1585-uXHFmzq7h3elZ86K/YxiHWVRrUY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 5509,
    "path": "../public/_nuxt/5dWx9PTI.js"
  },
  "/_nuxt/1KlW-nVq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14b0-VYv5cHun8qj241QDhOJMtdDe3CY\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 5296,
    "path": "../public/_nuxt/1KlW-nVq.js"
  },
  "/_nuxt/3NVNAJ67.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2f6-WqeK8fkls3VrABuw3oJ8lPoucG8\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 758,
    "path": "../public/_nuxt/3NVNAJ67.js"
  },
  "/_nuxt/38ib02ZW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"22fd-KkEnWXqlbufQuehSaQwYhjTr7xc\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 8957,
    "path": "../public/_nuxt/38ib02ZW.js"
  },
  "/_nuxt/6tpwta1L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6e3-5YNDWjyWUKSP6YBM91xhuSpcn7E\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 1763,
    "path": "../public/_nuxt/6tpwta1L.js"
  },
  "/_nuxt/7_6iQR12.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2200-MA7uUWqd3NaT0G84BHStyNJigtI\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 8704,
    "path": "../public/_nuxt/7_6iQR12.js"
  },
  "/_nuxt/6hIrQMj0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17b4-i74VqTebAg5RKTHy0ZAFRFkncIg\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 6068,
    "path": "../public/_nuxt/6hIrQMj0.js"
  },
  "/_nuxt/9uH0sDRK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"376-/UY82jvsT0QfZn+2gAZJWnyMNiw\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 886,
    "path": "../public/_nuxt/9uH0sDRK.js"
  },
  "/_nuxt/Ao3JTd_g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bb7-gVMWb5ONcsj4YD1q5Qj/RFA6HRA\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 7095,
    "path": "../public/_nuxt/Ao3JTd_g.js"
  },
  "/_nuxt/a7Ddf_nl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1399-e0d616rhM9OKRYXo8VsnxcOwef4\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 5017,
    "path": "../public/_nuxt/a7Ddf_nl.js"
  },
  "/_nuxt/B-1_MucA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"410-tUQC+sYF/LNytFpuNOS0KQxFLvI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 1040,
    "path": "../public/_nuxt/B-1_MucA.js"
  },
  "/_nuxt/a_KaH6Kh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"111e-IFxcZkmhfGaqP0JBkJ7o3gihGDs\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 4382,
    "path": "../public/_nuxt/a_KaH6Kh.js"
  },
  "/_nuxt/B25O3jkA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13a3-PqFmzdO2UzDu3kM9LMOsN8GX6L8\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 5027,
    "path": "../public/_nuxt/B25O3jkA.js"
  },
  "/_nuxt/B1Djrs1l.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"72b-IsteeRFKDWtd93LG0u7f8tlRJ+4\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 1835,
    "path": "../public/_nuxt/B1Djrs1l.js"
  },
  "/_nuxt/B2Wt57nM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1820-K+IhERooDd8qrr5U0pF2Jp2L654\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 6176,
    "path": "../public/_nuxt/B2Wt57nM.js"
  },
  "/_nuxt/B7oW5zeo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2fa5-X1S+6Qb2q0LkvrV6KnnOClxYpoE\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 12197,
    "path": "../public/_nuxt/B7oW5zeo.js"
  },
  "/_nuxt/B41_Gt9a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19a-ZvfINkeZoYIOEmLJH+osWMwEru4\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 410,
    "path": "../public/_nuxt/B41_Gt9a.js"
  },
  "/_nuxt/B8T7fFUS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1388-LmHksc4YMYL726JaGxqCPSat0To\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5000,
    "path": "../public/_nuxt/B8T7fFUS.js"
  },
  "/_nuxt/B9uSl02J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e7c-Tva+D5/gXFxNkcGG56JLuNqyrng\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 3708,
    "path": "../public/_nuxt/B9uSl02J.js"
  },
  "/_nuxt/B3yJAl2W.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19f4-iw2J/8gWFfSOsd7p0lqVZ7WYo1o\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 6644,
    "path": "../public/_nuxt/B3yJAl2W.js"
  },
  "/_nuxt/BBEjNJcI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e45-qW9rpwP6yiWdBoGUwKF7ff2tZRY\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3653,
    "path": "../public/_nuxt/BBEjNJcI.js"
  },
  "/_nuxt/BALs0QcB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f78-6yVL2AyfzxNz+xo5B7+7Pry+CP8\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3960,
    "path": "../public/_nuxt/BALs0QcB.js"
  },
  "/_nuxt/BdDiPmwV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"159f-Uhcap/f8lcj6VeQCIV2K3h9u5Us\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 5535,
    "path": "../public/_nuxt/BdDiPmwV.js"
  },
  "/_nuxt/BEGnLHRi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fa4a-J5fAfz5DF1Ib7mP9WESPyl0xWJU\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 64074,
    "path": "../public/_nuxt/BEGnLHRi.js"
  },
  "/_nuxt/BetXVs0b.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9de-Au4QsyjRMz2HdGD+Md5jdy8oHfI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2526,
    "path": "../public/_nuxt/BetXVs0b.js"
  },
  "/_nuxt/BFItyJwL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25f5-DbOIbvweI2Up6uGu6gY9BOT4MTE\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 9717,
    "path": "../public/_nuxt/BFItyJwL.js"
  },
  "/_nuxt/bFZEpA37.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8ee5-GYfD2J6WyA1ucCzGMD89tfrMkv8\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 36581,
    "path": "../public/_nuxt/bFZEpA37.js"
  },
  "/_nuxt/BFywKa0P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1128-BERW9cjjNIcXxnwPZNPgY9kAPF8\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4392,
    "path": "../public/_nuxt/BFywKa0P.js"
  },
  "/_nuxt/BIHBHLbP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ce2b-KSzcg6m/AV+9pX8WBsDVO+V9w34\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 52779,
    "path": "../public/_nuxt/BIHBHLbP.js"
  },
  "/_nuxt/BFLf3450.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ab3-jtaF1W78w0boMwXAKjFDEEt/kTY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 2739,
    "path": "../public/_nuxt/BFLf3450.js"
  },
  "/_nuxt/BIdFfYk-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cbd-3PeN+waGMArd92lv6LwKlMc01R8\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3261,
    "path": "../public/_nuxt/BIdFfYk-.js"
  },
  "/_nuxt/BIlmRAyG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d71-Skr5Bjkc0tSdwhWRAsHrEI48944\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 3441,
    "path": "../public/_nuxt/BIlmRAyG.js"
  },
  "/_nuxt/Bl5pzR2X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7a9-XY6523ulwzW82UB1br2+4YAj2+c\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 1961,
    "path": "../public/_nuxt/Bl5pzR2X.js"
  },
  "/_nuxt/BJOJcXLK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13fd-BxfZdbT5G1rW0lqygCF6kO3SbtQ\"",
    "mtime": "2026-06-23T06:29:17.938Z",
    "size": 5117,
    "path": "../public/_nuxt/BJOJcXLK.js"
  },
  "/_nuxt/BkfTQxlC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31d6-oDUOyI2qw/I6F2GH1SEMYPxwENY\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 12758,
    "path": "../public/_nuxt/BkfTQxlC.js"
  },
  "/_nuxt/BLZRWeSa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17d1-g0gQJOzdidXKvddvcqoqBIA0Qj0\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 6097,
    "path": "../public/_nuxt/BLZRWeSa.js"
  },
  "/_nuxt/Bl_ykZZf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cf8-WcJgWsGlWGVNuMxCT1mdwVXmKpI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3320,
    "path": "../public/_nuxt/Bl_ykZZf.js"
  },
  "/_nuxt/BkjGVgdb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3479-JMEDZueCInQeXdUi7xgSib2HHvg\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 13433,
    "path": "../public/_nuxt/BkjGVgdb.js"
  },
  "/_nuxt/Bm92f-5u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"619-wpu0cE9UVD1zlkg/XplIpjQzOxE\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 1561,
    "path": "../public/_nuxt/Bm92f-5u.js"
  },
  "/_nuxt/bMzEsecZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bc8-G0eFIChzpH7xNvExPDOnfkIh3iM\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3016,
    "path": "../public/_nuxt/bMzEsecZ.js"
  },
  "/_nuxt/Bn76Gw6s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1081-9fY/06GS8oBk1+woOx69IsKK+rU\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4225,
    "path": "../public/_nuxt/Bn76Gw6s.js"
  },
  "/_nuxt/Bo80UHfj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5ee-Vd/knabe7mUHHzWxA05/AHN9H3o\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 1518,
    "path": "../public/_nuxt/Bo80UHfj.js"
  },
  "/_nuxt/BsXNMKs0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33ca-ffjWgPhDAYqCpOztuW62UhRcNwY\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 13258,
    "path": "../public/_nuxt/BsXNMKs0.js"
  },
  "/_nuxt/BqN1YbN6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1781-6DBgPM3Hz1xcPNtglTW2l2XYMe4\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 6017,
    "path": "../public/_nuxt/BqN1YbN6.js"
  },
  "/_nuxt/BRDbXMxH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2de9-YPwq3smJpashbmMvcq/u/T6dX2c\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 11753,
    "path": "../public/_nuxt/BRDbXMxH.js"
  },
  "/_nuxt/BULHnxYW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"21d8-H8GxylCkchRYinKBmRMzGbspAfw\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 8664,
    "path": "../public/_nuxt/BULHnxYW.js"
  },
  "/_nuxt/BurPIWYH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"112-TLd/Z8X+8OIkbeK9r/BTZZwwjCs\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 274,
    "path": "../public/_nuxt/BurPIWYH.js"
  },
  "/_nuxt/Bw23VWiD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18db-oPG9pVbhyQuYzpR7IuZyBq7oVpE\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 6363,
    "path": "../public/_nuxt/Bw23VWiD.js"
  },
  "/_nuxt/Bx7fo6fW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1af2-gwQF0m++YbQ+qRVCb0lWhIHo3iE\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 6898,
    "path": "../public/_nuxt/Bx7fo6fW.js"
  },
  "/_nuxt/Bxp4WF2y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a04-T9a+uEDx5bJ+RD/GOIOQiROoId8\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 2564,
    "path": "../public/_nuxt/Bxp4WF2y.js"
  },
  "/_nuxt/BYVNv6mW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"824-+l/tInMj2PZv3+IWBusJuRdNhEQ\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 2084,
    "path": "../public/_nuxt/BYVNv6mW.js"
  },
  "/_nuxt/ByjkSVTj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4a7-OcYaimwjGkhK+FxDr1KXuF23vm4\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 1191,
    "path": "../public/_nuxt/ByjkSVTj.js"
  },
  "/_nuxt/BZyzHNzH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9e1-IjOD20+FZxJ6DBn6NPZqSNhy2d0\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 2529,
    "path": "../public/_nuxt/BZyzHNzH.js"
  },
  "/_nuxt/C-pYcCDL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"177e-KtiL0Y6bbDOz+3u/w4bj8Qk3zqE\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 6014,
    "path": "../public/_nuxt/C-pYcCDL.js"
  },
  "/_nuxt/BzDhFWC3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"643-erQHnQXKqka56LgXDLTEpfnYkZg\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 1603,
    "path": "../public/_nuxt/BzDhFWC3.js"
  },
  "/_nuxt/C2zJTNtd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d31-dIFPetJ5cVnPuZvKvBRgtBfA2pY\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 3377,
    "path": "../public/_nuxt/C2zJTNtd.js"
  },
  "/_nuxt/C3eOHf4W.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c77-IDNuGzWEJ/ku1CCRfYzVyKxOPwc\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3191,
    "path": "../public/_nuxt/C3eOHf4W.js"
  },
  "/_nuxt/C-bpvdyZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fde-yY6jAvz/IPU0B3l+lDNnd0snmUs\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 4062,
    "path": "../public/_nuxt/C-bpvdyZ.js"
  },
  "/_nuxt/C6agP2mF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"368c-XrpfsQX7lRTVQItxI+FidH5jkBo\"",
    "mtime": "2026-06-23T06:29:17.938Z",
    "size": 13964,
    "path": "../public/_nuxt/C6agP2mF.js"
  },
  "/_nuxt/C3Vw5oXa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f39-dwtBhWfNiyjTLfUjbfzbVlqZY0E\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 7993,
    "path": "../public/_nuxt/C3Vw5oXa.js"
  },
  "/_nuxt/C69hhRJx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2a58-MZKMHXhtbiZcSJ334kMhet4pGsg\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 10840,
    "path": "../public/_nuxt/C69hhRJx.js"
  },
  "/_nuxt/C8MV16Li.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1559-RL5/3fuAO/nMZR9pc88QJdTQwZ0\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5465,
    "path": "../public/_nuxt/C8MV16Li.js"
  },
  "/_nuxt/C8VYGbCm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4be9-MkjjuPzmknLybpXcyGgwhnwOTJg\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 19433,
    "path": "../public/_nuxt/C8VYGbCm.js"
  },
  "/_nuxt/C90AS_ls.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c2f-Eo87WXO+ob5sfY0pCIVSyxrmJBI\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 11311,
    "path": "../public/_nuxt/C90AS_ls.js"
  },
  "/_nuxt/C98R4az2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"94a-+g1q0OMzj9EX99IW8msWEwtw804\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2378,
    "path": "../public/_nuxt/C98R4az2.js"
  },
  "/_nuxt/C9HbHnCb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a1-/1oBqHvwm1CAvfyVzknBu7N6rYM\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 417,
    "path": "../public/_nuxt/C9HbHnCb.js"
  },
  "/_nuxt/calendar.C2FOI2fv.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-AoZYlI/NcYR7ph+STSxGqu94AUk\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 420,
    "path": "../public/_nuxt/calendar.C2FOI2fv.css"
  },
  "/_nuxt/Carousel.jsXCKPF9.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8c-tEwjnzcxLI5w4AY9J6/6gWq4VBE\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 140,
    "path": "../public/_nuxt/Carousel.jsXCKPF9.css"
  },
  "/_nuxt/CbqrbWj1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ec6-fIkzsln/gufB5mM8m9358/SP+6E\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 7878,
    "path": "../public/_nuxt/CbqrbWj1.js"
  },
  "/_nuxt/CbOBw5Ep.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dbb-5bhnScQMSoX/Nq/1iUAoGuzy2lw\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3515,
    "path": "../public/_nuxt/CbOBw5Ep.js"
  },
  "/_nuxt/CDEg4Bda.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"261f-yBQ2XGIYo/Hh9D3OJ5iIi9KDGzA\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 9759,
    "path": "../public/_nuxt/CDEg4Bda.js"
  },
  "/_nuxt/CEF5kygr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"10ec-SDuBZAymwGTeiFQA2Cnvus/x/uc\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 4332,
    "path": "../public/_nuxt/CEF5kygr.js"
  },
  "/_nuxt/Cf84N8rC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11f3-l9NgY326XhgntkkIu93x72L9fCo\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4595,
    "path": "../public/_nuxt/Cf84N8rC.js"
  },
  "/_nuxt/cF9GOey_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"24b9-HWB4h4WJmWJr8Yzmm//6hHrUtVE\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 9401,
    "path": "../public/_nuxt/cF9GOey_.js"
  },
  "/_nuxt/CfGzcLRb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"135-ywftIRzU6n4QZQ/mT/aJ2H8FMMI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 309,
    "path": "../public/_nuxt/CfGzcLRb.js"
  },
  "/_nuxt/CgyLNsDx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3261-cWy8PuiGsP7JttvVcSxAKvbLxq0\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 12897,
    "path": "../public/_nuxt/CgyLNsDx.js"
  },
  "/_nuxt/Cj3Enwz6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b05-HhGcqZBe2Zh2rfyhZ9XpidKYNsw\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 6917,
    "path": "../public/_nuxt/Cj3Enwz6.js"
  },
  "/_nuxt/Cg7QBzgA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"256f-S7WGYtHEVCQ9IDY2nIdbL5GiLHk\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 9583,
    "path": "../public/_nuxt/Cg7QBzgA.js"
  },
  "/_nuxt/CipTv0vK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2e1e-jh9fQRuSbg1AyPaA7gYXWMQdwX8\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 11806,
    "path": "../public/_nuxt/CipTv0vK.js"
  },
  "/_nuxt/CjVs2Rwd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8eb-21RDGcOYxSesXh5tut/D1w8mcB0\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 2283,
    "path": "../public/_nuxt/CjVs2Rwd.js"
  },
  "/_nuxt/Cj4OemwZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f13-cj2MWlI79PT8YxXDw1xkX8J+vSg\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 7955,
    "path": "../public/_nuxt/Cj4OemwZ.js"
  },
  "/_nuxt/ClCnPCuW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"47e2-gJcoQdJST15imC7M3P7vk79bGzE\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 18402,
    "path": "../public/_nuxt/ClCnPCuW.js"
  },
  "/_nuxt/CjGAFxgq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14be-ToVDx4lR80unIc2e7h+9Zapm4uI\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5310,
    "path": "../public/_nuxt/CjGAFxgq.js"
  },
  "/_nuxt/CLCNpstF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3cb7-lZZF54Bj2APDzkmnG0Dy0vyugzY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 15543,
    "path": "../public/_nuxt/CLCNpstF.js"
  },
  "/_nuxt/ClG9_xCk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a4-dpHScwsxjuFidlBE9OCEhncXfT8\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 1700,
    "path": "../public/_nuxt/ClG9_xCk.js"
  },
  "/_nuxt/CLPK4ZF0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16e6-GYHZJag/qTdQv2s+CZLWAGAnI7g\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 5862,
    "path": "../public/_nuxt/CLPK4ZF0.js"
  },
  "/_nuxt/CmoCOIC8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6288-rRL4U0hmF62jndGXdhPdSti3oFI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 25224,
    "path": "../public/_nuxt/CmoCOIC8.js"
  },
  "/_nuxt/CmOm0Fhz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"499-WLXqSbk9ncg8xJBO7cH9I9DCbhM\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 1177,
    "path": "../public/_nuxt/CmOm0Fhz.js"
  },
  "/_nuxt/Co1Zh51_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"126-X/zZAwDjQv817ow4ZXblXvH5wcI\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 294,
    "path": "../public/_nuxt/Co1Zh51_.js"
  },
  "/_nuxt/CommandPaletteGroup.DEQs0rUo.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5e-blKk9AHrSiBt2XtYIyElh9dZDYE\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 94,
    "path": "../public/_nuxt/CommandPaletteGroup.DEQs0rUo.css"
  },
  "/_nuxt/CPGIFjD6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f41-JTNVLqO+90J0J/H2QbfCn43a9ts\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3905,
    "path": "../public/_nuxt/CPGIFjD6.js"
  },
  "/_nuxt/CP-YWnqw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11c6-VxSAJuKQtXdKkiZnBGWla/OuB4E\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 4550,
    "path": "../public/_nuxt/CP-YWnqw.js"
  },
  "/_nuxt/CpHNkKDD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cb3-cgTg8U++oyta7mKx6ttZLtk7wec\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3251,
    "path": "../public/_nuxt/CpHNkKDD.js"
  },
  "/_nuxt/CP8K_Lot.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a23-HxMDLIuQVLvJmdYEX2LC8wpGLOU\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 6691,
    "path": "../public/_nuxt/CP8K_Lot.js"
  },
  "/_nuxt/CPnO5umP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29a6-juT+ex2nb+6TVC1illgsnVdnNhc\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 10662,
    "path": "../public/_nuxt/CPnO5umP.js"
  },
  "/_nuxt/CQnXRA9F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cc1-x1l2B/HmRvFhjEQJbuU585Pug+k\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 7361,
    "path": "../public/_nuxt/CQnXRA9F.js"
  },
  "/_nuxt/CqPizI7M.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"20c1-pT41LFqhfBxHPmmu0HVb+Rnn90I\"",
    "mtime": "2026-06-23T06:29:17.938Z",
    "size": 8385,
    "path": "../public/_nuxt/CqPizI7M.js"
  },
  "/_nuxt/CR1NQ318.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"318-BMFsr7CLxb5T1Hinhn/tzJfhcbc\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 792,
    "path": "../public/_nuxt/CR1NQ318.js"
  },
  "/_nuxt/Cr4B0645.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ec3-EX39nvz+dZ/BdJ7HDuQs1G1fb4w\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3779,
    "path": "../public/_nuxt/Cr4B0645.js"
  },
  "/_nuxt/CRlQUfLX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bde-QT5fKE2hRTIW6bQoxu+ttxaUjBU\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3038,
    "path": "../public/_nuxt/CRlQUfLX.js"
  },
  "/_nuxt/CsyYHaxo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e72-24zg0INxp9CaNC4B6xAB9ADD0N8\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3698,
    "path": "../public/_nuxt/CsyYHaxo.js"
  },
  "/_nuxt/CSpio54h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f37-Qv16Lh5WY0Rh3g3XUViX/0GdLrs\"",
    "mtime": "2026-06-23T06:29:17.938Z",
    "size": 3895,
    "path": "../public/_nuxt/CSpio54h.js"
  },
  "/_nuxt/Ctx6dixD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b0a-Ut0kNCvxd+cqfkwtSQaHEiTP1kU\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2826,
    "path": "../public/_nuxt/Ctx6dixD.js"
  },
  "/_nuxt/CVL3HRk1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"245-Vf3DohGtEPex1najD5EenzLhvn8\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 581,
    "path": "../public/_nuxt/CVL3HRk1.js"
  },
  "/_nuxt/CsywpAxa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"79d5-Ipyg8GJG8toERB39f/sRZrPKwkw\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 31189,
    "path": "../public/_nuxt/CsywpAxa.js"
  },
  "/_nuxt/CtYRvYgT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13e9-avHSEnNDuvq7/xHLDPEUKuY+eGY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 5097,
    "path": "../public/_nuxt/CtYRvYgT.js"
  },
  "/_nuxt/CX0O5TME.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6ed-5PgKXJIqm6XAZ0WoJPmuWnfpSH4\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 1773,
    "path": "../public/_nuxt/CX0O5TME.js"
  },
  "/_nuxt/CWzOw7FV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"850-7xd9KO03Lje8gX5lpzWm30CthFY\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2128,
    "path": "../public/_nuxt/CWzOw7FV.js"
  },
  "/_nuxt/CxIZtCgj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"90-L+vmpYXKtWfVvfoQuvT0iSCG5+I\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 144,
    "path": "../public/_nuxt/CxIZtCgj.js"
  },
  "/_nuxt/CX-IfusY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"163e-PvmWTvPOU72WKQmkMsR+tIbxH3k\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5694,
    "path": "../public/_nuxt/CX-IfusY.js"
  },
  "/_nuxt/CXNsDIKn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1743-nNKan1Sfqs90Tj2cXC4HcdyEwgY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 5955,
    "path": "../public/_nuxt/CXNsDIKn.js"
  },
  "/_nuxt/CzOtXfzE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4ac-qmz1kv8TykKOr2cSUkfgv24TJKM\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 1196,
    "path": "../public/_nuxt/CzOtXfzE.js"
  },
  "/_nuxt/CXZNOnb9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2a3b-0/jUAinEXQSyii2xhVAm6KiR+Lg\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 10811,
    "path": "../public/_nuxt/CXZNOnb9.js"
  },
  "/_nuxt/D3JU1_-i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bb-cizNKQDL1zYpmaDE72gLlUz3jQ0\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 443,
    "path": "../public/_nuxt/D3JU1_-i.js"
  },
  "/_nuxt/D0zE3Jqi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"280c-0WQkILFJKA7pRaOYmkfsbw3tK8M\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 10252,
    "path": "../public/_nuxt/D0zE3Jqi.js"
  },
  "/_nuxt/D5C6XNpG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1099-mlqwrB/KoA3R+koQ/JniF7m8VEI\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4249,
    "path": "../public/_nuxt/D5C6XNpG.js"
  },
  "/_nuxt/D2qQD86h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"142e-p186+zTMi1CcR2iXVGtyW1iaBbY\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 5166,
    "path": "../public/_nuxt/D2qQD86h.js"
  },
  "/_nuxt/D5yyxxeg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"308-En+Vb6p9I2ak/QkaGapvfLkdD34\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 776,
    "path": "../public/_nuxt/D5yyxxeg.js"
  },
  "/_nuxt/D4VRKVzL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26d4-C13DvAmKN96cq6d1ic5GExwBp2U\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 9940,
    "path": "../public/_nuxt/D4VRKVzL.js"
  },
  "/_nuxt/D6hfx0BJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5850-pS3fKUNeVKmaCdc8flWrCc1CRU8\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 22608,
    "path": "../public/_nuxt/D6hfx0BJ.js"
  },
  "/_nuxt/DaokZLv9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dcc-uMpFQNNFstjgwdzcGiZYmEhyjYk\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3532,
    "path": "../public/_nuxt/DaokZLv9.js"
  },
  "/_nuxt/D9DVcNQp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2f10-CPSgvdPj5v0xw6f+OtRSFg/i1dU\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 12048,
    "path": "../public/_nuxt/D9DVcNQp.js"
  },
  "/_nuxt/DAq_rLjn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cf2-UvEJOzBiXhxrSXQD2N6Wk4JZPZY\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 7410,
    "path": "../public/_nuxt/DAq_rLjn.js"
  },
  "/_nuxt/default.C_ZS3hJD.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2d8-VoXTykz2M8rJkPlo78pG/eIyNOI\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 728,
    "path": "../public/_nuxt/default.C_ZS3hJD.css"
  },
  "/_nuxt/DfOrFG7g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"964-2zT2aFjoOlFpE6zvSQGCE+PBOY0\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2404,
    "path": "../public/_nuxt/DfOrFG7g.js"
  },
  "/_nuxt/Dh1ktqNV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"188c-u9WNLeqynhqqYBMpSu5iSmqiDho\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 6284,
    "path": "../public/_nuxt/Dh1ktqNV.js"
  },
  "/_nuxt/dFwP3aIR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2039-HK4FqEsZsx0p96qAaSMpb8GoA7c\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 8249,
    "path": "../public/_nuxt/dFwP3aIR.js"
  },
  "/_nuxt/DgyqiXgS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8ab1-AbYLXdr1KhcCs7g+NbGEL5IJ8r8\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 35505,
    "path": "../public/_nuxt/DgyqiXgS.js"
  },
  "/_nuxt/DHaFV-q-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"edb-6a/jyjALhTkoiDhx7V5LMNp01Tg\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 3803,
    "path": "../public/_nuxt/DHaFV-q-.js"
  },
  "/_nuxt/DHkeYEJV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7b92-EhLLSee12VXvEEO2vVsGF1G1G0E\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 31634,
    "path": "../public/_nuxt/DHkeYEJV.js"
  },
  "/_nuxt/DIM_ClvK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"919-veIW1+QC7KFAsnWl7vhIBV7Mnjg\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 2329,
    "path": "../public/_nuxt/DIM_ClvK.js"
  },
  "/_nuxt/DJ9xnB-L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bb2-n7vhSzqCRflxHMQfxAK9TLdTzP4\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 2994,
    "path": "../public/_nuxt/DJ9xnB-L.js"
  },
  "/_nuxt/DJugkw9v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1388-+6YhaBaMN0ysnA0firYPlv3j5sY\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5000,
    "path": "../public/_nuxt/DJugkw9v.js"
  },
  "/_nuxt/DKwcPt5u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"70e-krFBqsIlbAvQNPUIeHixX25BBkI\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 1806,
    "path": "../public/_nuxt/DKwcPt5u.js"
  },
  "/_nuxt/DMjiXjk0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"22d0-LfPxDHlrg1uMdLGzeWi4C/feyCA\"",
    "mtime": "2026-06-23T06:29:17.938Z",
    "size": 8912,
    "path": "../public/_nuxt/DMjiXjk0.js"
  },
  "/_nuxt/DKjvV9h4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1161-llZiYBTFvkKQLioOfNjQ/+50Ltg\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 4449,
    "path": "../public/_nuxt/DKjvV9h4.js"
  },
  "/_nuxt/DNG7bKMT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ba-NY9YcD8xUxUNeUBHcPQcAJiuCqU\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 442,
    "path": "../public/_nuxt/DNG7bKMT.js"
  },
  "/_nuxt/DNsoCGH1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"546b-Bs0g7nDBu9U4Fsup2KIPmveq6yg\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 21611,
    "path": "../public/_nuxt/DNsoCGH1.js"
  },
  "/_nuxt/DnxxohHm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2b3-7/VHNtfGsGl+7JGmZB/xT43ys/M\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 691,
    "path": "../public/_nuxt/DnxxohHm.js"
  },
  "/_nuxt/DnZn5lcP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a9b-MbZ7X+b16DkkiE2WKQzRPe+Q2D0\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 2715,
    "path": "../public/_nuxt/DnZn5lcP.js"
  },
  "/_nuxt/DO3Lhxv6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a8a-eUGRhBi+QVGK+1EETmBOGbQi54M\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 2698,
    "path": "../public/_nuxt/DO3Lhxv6.js"
  },
  "/_nuxt/DovVz3Vr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40-y7I73IRCLZ9f6iwwxBs2aibZqg8\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 64,
    "path": "../public/_nuxt/DovVz3Vr.js"
  },
  "/_nuxt/DkUMpoHM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5c7e9-c849XxmvYcgt2GYoT79WEr+4kM0\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 378857,
    "path": "../public/_nuxt/DkUMpoHM.js"
  },
  "/_nuxt/DSIua47B.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"831-Urz63k5FjD++SUNN4pSbHt3dUUY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 2097,
    "path": "../public/_nuxt/DSIua47B.js"
  },
  "/_nuxt/DQCoQcJC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e21-pT0q6yoRsXo1iiHUfkonFe5XzzQ\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3617,
    "path": "../public/_nuxt/DQCoQcJC.js"
  },
  "/_nuxt/DT3TV2Ov.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1198-bZ7QYdhlpb3vp7I78ndgc531PJk\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4504,
    "path": "../public/_nuxt/DT3TV2Ov.js"
  },
  "/_nuxt/DsYuS0vp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d6f-Rb6SgR3Y1tUJ/oIfnn6WfJmWnag\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3439,
    "path": "../public/_nuxt/DsYuS0vp.js"
  },
  "/_nuxt/DtgmHLEu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15fb-zdjHRBWunJEkjAW9LY5x0LyZUK0\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 5627,
    "path": "../public/_nuxt/DtgmHLEu.js"
  },
  "/_nuxt/Du2CWEMg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5550-19FscxSo1X0cSPC0AHWIt+NNNrM\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 21840,
    "path": "../public/_nuxt/Du2CWEMg.js"
  },
  "/_nuxt/duklLpYK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"567-a5Jd+6MMTeuQcRxlhMTKuTgIpGI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 1383,
    "path": "../public/_nuxt/duklLpYK.js"
  },
  "/_nuxt/DVfAXoSn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19e-Da/vJhlG9dBD6qBxWCpk3CR3zTw\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 414,
    "path": "../public/_nuxt/DVfAXoSn.js"
  },
  "/_nuxt/Duwp4glY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dbc-2nya41zTThG17hZoeHP6vN8n0Bw\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3516,
    "path": "../public/_nuxt/Duwp4glY.js"
  },
  "/_nuxt/DVR9g6w4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"eeb-G22vhEdvp+msD9wbL9CmQp9ZhYI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3819,
    "path": "../public/_nuxt/DVR9g6w4.js"
  },
  "/_nuxt/DWY12leg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5360-IIh/64p8KT2m+nC3M/RyAzt0uIo\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 21344,
    "path": "../public/_nuxt/DWY12leg.js"
  },
  "/_nuxt/Dx6fFC3c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11f8-bEBbbnCGdwRGaATUr0bj8ltG+gc\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 4600,
    "path": "../public/_nuxt/Dx6fFC3c.js"
  },
  "/_nuxt/DxLpux0U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1297-sc/FxtfayoKiJBrvN+27LaH4XtY\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 4759,
    "path": "../public/_nuxt/DxLpux0U.js"
  },
  "/_nuxt/DypqxKzc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bf5-cOU0YnWjCWFkQG81bvaxnRr+nDY\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3061,
    "path": "../public/_nuxt/DypqxKzc.js"
  },
  "/_nuxt/DXz5Qe44.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a30-c/7L0I5Gj/RsCWlriTcik4p2U4Y\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 2608,
    "path": "../public/_nuxt/DXz5Qe44.js"
  },
  "/_nuxt/DZevcvw4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2bf-h3jZXDYk/3NX8V+2AXdJUFUDehk\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 703,
    "path": "../public/_nuxt/DZevcvw4.js"
  },
  "/_nuxt/DzlazSzm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2cd-3H6L50YPvprsNO5lZWGX6BBSgM0\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 717,
    "path": "../public/_nuxt/DzlazSzm.js"
  },
  "/_nuxt/edit.kK7smXrW.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5f8-D6BiMktHb18OzvODd1K8nedLT/Q\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 1528,
    "path": "../public/_nuxt/edit.kK7smXrW.css"
  },
  "/_nuxt/h1uQ36T5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"990-HDVEjHenZnnKfN9k74+pLFQVaUY\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 2448,
    "path": "../public/_nuxt/h1uQ36T5.js"
  },
  "/_nuxt/HmG_esK6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25c0-5bfruz8lwDT5l99Z0qmWEV5SMgk\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 9664,
    "path": "../public/_nuxt/HmG_esK6.js"
  },
  "/_nuxt/FTkEtgMt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"60c-+rhQ8qJXPuZacFfh+mdxh0+xlYk\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 1548,
    "path": "../public/_nuxt/FTkEtgMt.js"
  },
  "/_nuxt/iHAZz0AH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2bb-zOoutqikGlW9LyaqVuxVYBrAt4s\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 699,
    "path": "../public/_nuxt/iHAZz0AH.js"
  },
  "/_nuxt/index.BTfrCtVY.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-HnEl3Ock1cU1PtnSlM2x6JHhqUA\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 420,
    "path": "../public/_nuxt/index.BTfrCtVY.css"
  },
  "/_nuxt/index.Bf2LU_eM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-dDSQP7XUbMUxe0AC/l3vGrgrBKI\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 420,
    "path": "../public/_nuxt/index.Bf2LU_eM.css"
  },
  "/_nuxt/index.BZVAHpDK.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-R0es7/Wcujlsk/MtCBY1s1gah74\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 420,
    "path": "../public/_nuxt/index.BZVAHpDK.css"
  },
  "/_nuxt/index.D3x2sJ0J.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1ef-E8Mgv9lqhNOwHaB0cNg3brZnTz0\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 495,
    "path": "../public/_nuxt/index.D3x2sJ0J.css"
  },
  "/_nuxt/index.CmX22s-U.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-Q5FuaX8SDJ2g+HZRG6VM+UsJMkg\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 420,
    "path": "../public/_nuxt/index.CmX22s-U.css"
  },
  "/_nuxt/IykBLXiV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d1c-tNA9VzjbyS9L8S/5LajlBWOnyHE\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 15644,
    "path": "../public/_nuxt/IykBLXiV.js"
  },
  "/_nuxt/index.DbZjYMh6.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"114-aGnQm1oPVWs76MxXjuHJWvxZRPU\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 276,
    "path": "../public/_nuxt/index.DbZjYMh6.css"
  },
  "/_nuxt/j9HTKnVh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"392-fJSC7gQQY98zk2judyDqR3xIh9M\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 914,
    "path": "../public/_nuxt/j9HTKnVh.js"
  },
  "/_nuxt/kop8Y4CA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dea-Dm+k46Trp5gJBTlT5CoKzGqls00\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3562,
    "path": "../public/_nuxt/kop8Y4CA.js"
  },
  "/_nuxt/LXV-vm8V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1920-fafnqQkJlgtuvI8qGcOOIqKqWgI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 6432,
    "path": "../public/_nuxt/LXV-vm8V.js"
  },
  "/_nuxt/member.DK0N6hs_.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d1-nnncTxD27DEoMiLWjSEwMoLhf74\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 209,
    "path": "../public/_nuxt/member.DK0N6hs_.css"
  },
  "/_nuxt/Lyz-vNMk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1874-X0Z3dCfW/g7dXETL6aOh8lZSfu8\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 6260,
    "path": "../public/_nuxt/Lyz-vNMk.js"
  },
  "/_nuxt/my-calendar.Bib5ngvo.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a4-YK+vTrAP5reYCh598v55o2CQI6s\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 420,
    "path": "../public/_nuxt/my-calendar.Bib5ngvo.css"
  },
  "/_nuxt/portal.wgB6SLVX.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d1-Kpemxq/rtwqWVdRauYTLiRWGep4\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 209,
    "path": "../public/_nuxt/portal.wgB6SLVX.css"
  },
  "/_nuxt/Progress.BIrL3Irv.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"dd3-TGuHku3ztMciMzyyRrgGScwZ5Cw\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 3539,
    "path": "../public/_nuxt/Progress.BIrL3Irv.css"
  },
  "/_nuxt/print.BN6KpkF_.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4f-0y6Hd2hG6HF80TJoa6aXawIWJe0\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 79,
    "path": "../public/_nuxt/print.BN6KpkF_.css"
  },
  "/_nuxt/rDKF6lGO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3228-zJk1yLaqBMVHAuo/QkWivk9BrkI\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 12840,
    "path": "../public/_nuxt/rDKF6lGO.js"
  },
  "/_nuxt/RsvXJ3dk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9fe1-vekrWrZpmHfrxXvQbn8dG/A5vZ4\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 40929,
    "path": "../public/_nuxt/RsvXJ3dk.js"
  },
  "/_nuxt/SuXysKev.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3e6-MciEGFSuK+4TzIdfzr7Z2hFgDZs\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 998,
    "path": "../public/_nuxt/SuXysKev.js"
  },
  "/_nuxt/rtq5Bt9h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e0c-k0lXLTrv2Nuk0J1MTEC4JKId0Sw\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3596,
    "path": "../public/_nuxt/rtq5Bt9h.js"
  },
  "/_nuxt/sjkIIfVy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1797-eXBOtOq+nJ/Lfdeg8GUDkv9ombE\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 6039,
    "path": "../public/_nuxt/sjkIIfVy.js"
  },
  "/_nuxt/Select.qOczc23w.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"35-Hb86PzaLnD1sW/ziYwV0CUep5rA\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 53,
    "path": "../public/_nuxt/Select.qOczc23w.css"
  },
  "/_nuxt/s_r3nF0T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fc3-1DOSwv77Ayl43rRvD9T6JfqGjgI\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 4035,
    "path": "../public/_nuxt/s_r3nF0T.js"
  },
  "/_nuxt/terms.BmFFO6qs.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3aa-L9WsQJcarHHkWJJHtv7WmbGq5/0\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 938,
    "path": "../public/_nuxt/terms.BmFFO6qs.css"
  },
  "/_nuxt/TlOopTAL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c69-d2ZE20QlUkGVwABuK+N2UK6IvAI\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 7273,
    "path": "../public/_nuxt/TlOopTAL.js"
  },
  "/_nuxt/terms.90oj9N3c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"55d-1c8QYobXwFUyRST8MG6VLWyi/4Q\"",
    "mtime": "2026-06-23T06:29:17.881Z",
    "size": 1373,
    "path": "../public/_nuxt/terms.90oj9N3c.css"
  },
  "/_nuxt/unxR3S7c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e73-MiKzHTZeQsCOkDKJK3tczFv4yh0\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 3699,
    "path": "../public/_nuxt/unxR3S7c.js"
  },
  "/_nuxt/upgrade.BkILxqCx.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1ef-LL6HuPf9x8kNKcP4SxP18K2MbHU\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 495,
    "path": "../public/_nuxt/upgrade.BkILxqCx.css"
  },
  "/_nuxt/UTMLSGsk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1686-Zeb0xDMzfKKfgeLmz580vUe3nn8\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 5766,
    "path": "../public/_nuxt/UTMLSGsk.js"
  },
  "/_nuxt/X-WqJUAa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"526b-lrVKFhpwjlwZoShC4JPyy9mymRQ\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 21099,
    "path": "../public/_nuxt/X-WqJUAa.js"
  },
  "/_nuxt/XdIDCcTu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e69-LnRu/oidadvNN1eIFJdI8lEpNzY\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 20073,
    "path": "../public/_nuxt/XdIDCcTu.js"
  },
  "/_nuxt/Xn3Cv_qy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1235-poy0BRrG7qvhyaFUCiJEDPskI+U\"",
    "mtime": "2026-06-23T06:29:17.932Z",
    "size": 4661,
    "path": "../public/_nuxt/Xn3Cv_qy.js"
  },
  "/_nuxt/XnCB5YEH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e62-hATunPfHFxaz2k7oSPlDxhzicCM\"",
    "mtime": "2026-06-23T06:29:17.936Z",
    "size": 3682,
    "path": "../public/_nuxt/XnCB5YEH.js"
  },
  "/_nuxt/zdk6BqFo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"95f-G7w40XcIwm1lRgNrw9WPLr0LJqE\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 2399,
    "path": "../public/_nuxt/zdk6BqFo.js"
  },
  "/_nuxt/zu4HBU4v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d9a-qnZ8M2d1P0voMhXESgF0lSB13Gs\"",
    "mtime": "2026-06-23T06:29:17.933Z",
    "size": 3482,
    "path": "../public/_nuxt/zu4HBU4v.js"
  },
  "/_nuxt/_produk_.TaH8-xKp.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"19f-ocCF0+B996gpzon0HrwzqmNrAsY\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 415,
    "path": "../public/_nuxt/_produk_.TaH8-xKp.css"
  },
  "/_nuxt/_ref_.DeuHesc8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"408-linC4FwBDSOSaXvyPk7DOwplU6k\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 1032,
    "path": "../public/_nuxt/_ref_.DeuHesc8.css"
  },
  "/_nuxt/_2Keb7LM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bd3-wye+vVUaKrEvreNzEGsMiqqmJlE\"",
    "mtime": "2026-06-23T06:29:17.935Z",
    "size": 7123,
    "path": "../public/_nuxt/_2Keb7LM.js"
  },
  "/_nuxt/_slug_.BDgEFWDN.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"eb4-FmOOGqckJjlwIVfJZRKpak0WpeM\"",
    "mtime": "2026-06-23T06:29:17.931Z",
    "size": 3764,
    "path": "../public/_nuxt/_slug_.BDgEFWDN.css"
  },
  "/_nuxt/_tEBmik9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d1c-BysfcNAof+5r2GemgUSmRHanhxY\"",
    "mtime": "2026-06-23T06:29:17.937Z",
    "size": 3356,
    "path": "../public/_nuxt/_tEBmik9.js"
  },
  "/_nuxt/builds/meta/903cae45-3e06-4955-8a14-351d5557cac7.json": {
    "type": "application/json",
    "etag": "\"58-ZswWV7YN/fMciPAxYv6G6JXZPR4\"",
    "mtime": "2026-06-23T06:29:33.333Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/903cae45-3e06-4955-8a14-351d5557cac7.json"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-pZsazFUI/zR1nmozG7337fWIZ0s\"",
    "mtime": "2026-06-23T06:29:33.333Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
const basename = function(p, extension) {
  const segments = normalizeWindowsPath(p).split("/");
  let lastSegment = "";
  for (let i = segments.length - 1; i >= 0; i--) {
    const val = segments[i];
    if (val) {
      lastSegment = val;
      break;
    }
  }
  return extension && lastSegment.endsWith(extension) ? lastSegment.slice(0, -extension.length) : lastSegment;
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _l2xa41 = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

function baseURL() {
	
	return useRuntimeConfig().app.baseURL;
}
function buildAssetsDir() {
	
	return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
	return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
	
	const app = useRuntimeConfig().app;
	const publicBase = app.cdnURL || app.baseURL;
	return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

const getDataDir = () => {
  const config = useRuntimeConfig();
  return config.dataDir || resolve$2(process.cwd(), "..", "data");
};
function readJson(filename) {
  const file = join$1(getDataDir(), filename);
  if (!existsSync$1(file)) return [];
  try {
    const content = readFileSync(file, "utf-8");
    const parsed = JSON.parse(content);
    return Array.isArray(parsed) ? parsed : typeof parsed === "object" ? parsed : [];
  } catch {
    return [];
  }
}
function readJsonObj(filename) {
  const file = join$1(getDataDir(), filename);
  if (!existsSync$1(file)) return {};
  try {
    return JSON.parse(readFileSync(file, "utf-8"));
  } catch {
    return {};
  }
}
function writeJson(filename, data) {
  const dir = getDataDir();
  try {
    if (!existsSync$1(dir)) mkdirSync(dir, { recursive: true });
    const file = join$1(dir, filename);
    writeFileSync(file, JSON.stringify(data, null, 2), "utf-8");
    return true;
  } catch {
    return false;
  }
}
const makeSessionToken = (pass) => createHash$1("sha256").update(pass + "lakara_session_v1").digest("hex").slice(0, 32);
function checkAuth(event) {
  const config = useRuntimeConfig();
  const token = getHeader(event, "x-admin-token") || "";
  const validToken = makeSessionToken(config.adminPass);
  return token === validToken || token === config.adminPass;
}
function slugify(str) {
  return str.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "").replace(/-+/g, "-").replace(/^-|-$/g, "");
}

let pool = null;
function getDb() {
  if (!pool) {
    const config = useRuntimeConfig();
    pool = mysql.createPool({
      host: config.dbHost || "localhost",
      port: Number(config.dbPort) || 3306,
      user: config.dbUser,
      password: config.dbPass,
      database: config.dbName,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      charset: "utf8mb4",
      timezone: "+00:00"
    });
  }
  return pool;
}
async function query(sql, params) {
  const [rows] = await getDb().execute(sql, params);
  return rows;
}
async function queryOne(sql, params) {
  var _a;
  const rows = await query(sql, params);
  return (_a = rows[0]) != null ? _a : null;
}
async function execute(sql, params) {
  const [result] = await getDb().execute(sql, params);
  return result;
}
async function withTransaction(fn) {
  const conn = await getDb().getConnection();
  try {
    await conn.beginTransaction();
    const tx = {
      async execute(sql, params) {
        const [r] = await conn.execute(sql, params);
        return r;
      },
      async query(sql, params) {
        const [rows] = await conn.execute(sql, params);
        return rows;
      },
      async queryOne(sql, params) {
        var _a;
        const [rows] = await conn.execute(sql, params);
        return (_a = rows[0]) != null ? _a : null;
      }
    };
    const result = await fn(tx);
    await conn.commit();
    return result;
  } catch (e) {
    try {
      await conn.rollback();
    } catch {
    }
    throw e;
  } finally {
    conn.release();
  }
}

async function sendEmail(to, subject, html) {
  const config = useRuntimeConfig();
  const port = parseInt(config.smtpPort) || 465;
  const transporter = nodemailer.createTransport({
    host: config.smtpHost,
    port,
    secure: port === 465,
    auth: {
      user: config.smtpUser,
      pass: config.smtpPass
    },
    tls: {
      rejectUnauthorized: false
    }
  });
  try {
    await transporter.sendMail({
      from: config.smtpFrom || "Lakara <noreply@lakara.id>",
      to,
      subject,
      html
    });
    return true;
  } catch (err) {
    console.error("[Lakara email] Failed to send to", to, ":", err);
    return false;
  }
}

const hashPassword = (p) => createHash$1("sha256").update(p + "lakara_salt").digest("hex");
function parseStore(store) {
  var _a, _b;
  if (!store) return null;
  return {
    ...store,
    active: store.active === 1 || store.active === true,
    member_active: store.member_active === 1 || store.member_active === true,
    why_buy: typeof store.why_buy === "string" ? JSON.parse(store.why_buy || "[]") : (_a = store.why_buy) != null ? _a : [],
    products: typeof store.products === "string" ? JSON.parse(store.products || "[]") : (_b = store.products) != null ? _b : [],
    links_bio: store.links_bio ? typeof store.links_bio === "string" ? JSON.parse(store.links_bio) : store.links_bio : null
  };
}
async function getMemberStore(event) {
  const storeId = getCookie(event, "lakara_member");
  if (!storeId) throw createError$1({ statusCode: 401, statusMessage: "Silakan login terlebih dahulu." });
  const raw = await queryOne("SELECT * FROM stores WHERE id = ?", [storeId]);
  if (!raw) throw createError$1({ statusCode: 401, statusMessage: "Sesi tidak valid. Silakan login ulang." });
  return parseStore(raw);
}
function safeMemberStore(store) {
  const parsed = parseStore(store);
  if (!parsed) return null;
  const { member_password, ...safe } = parsed;
  return safe;
}

const escHtmlPortal = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
async function emailNotification(emails, title, body, link) {
  if (!emails.length) return;
  const config = useRuntimeConfig();
  const appUrl = config.appUrl || "https://lakara.id";
  const fullUrl = link ? link.startsWith("http") ? link : appUrl + link : `${appUrl}/client`;
  const html = `
<div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; background:#ffffff;">
  <div style="background:#3358ff; padding:24px 28px; border-radius:12px 12px 0 0;">
    <span style="color:white; font-size:18px; font-weight:bold;">\u{1F514} ${escHtmlPortal(title)}</span>
  </div>
  <div style="background:#f8fafc; padding:28px; border:1px solid #e2e8f0; border-top:none; border-radius:0 0 12px 12px;">
    ${body ? `<p style="color:#374151; font-size:15px; line-height:1.6; margin-top:0;">${escHtmlPortal(body)}</p>` : ""}
    <div style="text-align:center; margin:22px 0;">
      <a href="${fullUrl}" style="display:inline-block; background:#3358ff; color:#fff; text-decoration:none; padding:12px 28px; border-radius:8px; font-weight:bold; font-size:14px;">Buka Client Portal</a>
    </div>
    <p style="color:#9ca3af; font-size:12px; margin:0; line-height:1.6;">Notifikasi otomatis dari Lakara Client Portal. Jangan balas email ini.</p>
  </div>
</div>`.trim();
  for (const u of emails) {
    try {
      await sendEmail(u.email, `[Lakara] ${title}`, html);
    } catch {
    }
  }
}
const SESSION_COOKIE = "lakara_portal";
const SESSION_DAYS = 30;
function genId(prefix) {
  const t = Date.now().toString(36);
  const r = randomBytes(3).toString("hex");
  return `${prefix}_${t}${r}`.slice(0, 20);
}
async function createPortalSession(event, userId) {
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1e3);
  const ip = getHeader(event, "x-forwarded-for") || getHeader(event, "cf-connecting-ip") || "";
  const ua = (getHeader(event, "user-agent") || "").slice(0, 255);
  await execute(
    "INSERT INTO portal_sessions (token, user_id, ip, user_agent, expires_at) VALUES (?, ?, ?, ?, ?)",
    [token, userId, ip.toString().slice(0, 64), ua, expires]
  );
  await execute("UPDATE portal_users SET last_login_at = NOW() WHERE id = ?", [userId]);
  setCookie(event, SESSION_COOKIE, token, {
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    path: "/",
    httpOnly: true,
    sameSite: "lax"
  });
  return token;
}
async function getPortalUser(event) {
  const token = getCookie(event, SESSION_COOKIE);
  if (!token) return null;
  const row = await queryOne(
    `SELECT u.id, u.role, u.name, u.email, u.phone, u.avatar, u.client_id, u.active
     FROM portal_sessions s
     JOIN portal_users u ON u.id = s.user_id
     WHERE s.token = ? AND s.expires_at > NOW() AND u.active = 1`,
    [token]
  );
  return row || null;
}
async function requirePortalUser(event) {
  const user = await getPortalUser(event);
  if (!user) throw createError$1({ statusCode: 401, statusMessage: "Silakan login ke Client Portal." });
  return user;
}
async function requireRole(event, roles) {
  const user = await requirePortalUser(event);
  if (!roles.includes(user.role))
    throw createError$1({ statusCode: 403, statusMessage: "Akses ditolak." });
  return user;
}
const requireAdmin = (event) => requireRole(event, ["admin", "super_admin"]);
const requireSuperAdmin = (event) => requireRole(event, ["super_admin"]);
function assertClientOwnership(user, clientId) {
  if (user.role === "client" && user.client_id !== clientId)
    throw createError$1({ statusCode: 403, statusMessage: "Akses ke data klien lain ditolak." });
}
function scopedClientId(user, requested) {
  if (user.role === "client") return user.client_id || "";
  return requested || "";
}
async function getClientRevisionLimit(clientId) {
  const row = await queryOne(
    `SELECT COALESCE(s.revision_limit_override, p.revision_limit) AS lim
     FROM portal_subscriptions s JOIN portal_packages p ON p.id = s.package_id
     WHERE s.client_id = ? AND s.status = 'active'
     ORDER BY s.created_at DESC LIMIT 1`,
    [clientId]
  );
  return row ? Number(row.lim) : 1;
}
async function logActivity(event, user, action, entityType, entityId, meta) {
  try {
    const ip = (getHeader(event, "x-forwarded-for") || "").toString().slice(0, 64);
    await execute(
      `INSERT INTO portal_activity_logs (user_id, role, action, entity_type, entity_id, meta, ip)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        (user == null ? void 0 : user.id) || null,
        (user == null ? void 0 : user.role) || null,
        action,
        entityType || null,
        entityId || null,
        meta ? JSON.stringify(meta) : null,
        ip
      ]
    );
  } catch {
  }
}
async function notify(userIds, type, title, body, link) {
  const ids = (Array.isArray(userIds) ? userIds : [userIds]).filter(Boolean);
  for (const uid of ids) {
    try {
      await execute(
        "INSERT INTO portal_notifications (id, user_id, type, title, body, link) VALUES (?, ?, ?, ?, ?, ?)",
        [genId("ntf"), uid, type, title.slice(0, 255), body || null, link || null]
      );
    } catch {
    }
  }
  try {
    if (ids.length) {
      const ph = ids.map(() => "?").join(",");
      const rows = await query(
        `SELECT email, name FROM portal_users WHERE id IN (${ph}) AND active = 1 AND email IS NOT NULL`,
        ids
      );
      emailNotification(rows.filter((r) => r.email), title, body, link).catch(() => {
      });
    }
  } catch {
  }
}
async function getAdminUserIds() {
  const rows = await query(
    "SELECT id FROM portal_users WHERE role IN ('admin','super_admin') AND active = 1"
  );
  return rows.map((r) => r.id);
}
async function getClientUserIds(clientId) {
  const rows = await query(
    "SELECT id FROM portal_users WHERE role = 'client' AND client_id = ? AND active = 1",
    [clientId]
  );
  return rows.map((r) => r.id);
}
async function destroyPortalSession(event) {
  const token = getCookie(event, SESSION_COOKIE);
  if (token) await execute("DELETE FROM portal_sessions WHERE token = ?", [token]);
  deleteCookie(event, SESSION_COOKIE, { path: "/" });
}

const store = /* @__PURE__ */ new Map();
const MAX_ATTEMPTS = 10;
const WINDOW_MS = 30 * 60 * 1e3;
const LOCKOUT_MS = 10 * 60 * 1e3;
function checkRateLimit(key) {
  const now = Date.now();
  const record = store.get(key);
  if ((record == null ? void 0 : record.lockedUntil) && now < record.lockedUntil) {
    const mins = Math.ceil((record.lockedUntil - now) / 6e4);
    return { allowed: false, message: `Terlalu banyak percobaan. Coba lagi dalam ${mins} menit.` };
  }
  if (record && now - record.firstAt > WINDOW_MS) {
    store.delete(key);
  }
  return { allowed: true };
}
function recordFailedAttempt(key) {
  const now = Date.now();
  const record = store.get(key);
  if (!record) {
    store.set(key, { count: 1, firstAt: now });
    return;
  }
  record.count++;
  if (record.count >= MAX_ATTEMPTS) {
    record.lockedUntil = now + LOCKOUT_MS;
  }
}
function resetAttempts(key) {
  store.delete(key);
}

function getTripayConfig() {
  const cfg = useRuntimeConfig();
  const isSandbox = (cfg.tripayMode || "sandbox") !== "production";
  return {
    apiKey: cfg.tripayApiKey,
    privateKey: cfg.tripayPrivateKey,
    merchantCode: cfg.tripayMerchantCode,
    baseUrl: isSandbox ? "https://tripay.co.id/api-sandbox" : "https://tripay.co.id/api",
    isSandbox
  };
}
const TRIPAY_CHANNELS = [
  { code: "QRIS", name: "QRIS", group: "E-Wallet", type: "direct", minAmount: 1e3, feeFlat: 750, feePercent: 0.7 },
  { code: "SHOPEEPAY", name: "ShopeePay", group: "E-Wallet", type: "redirect", minAmount: 1e3, feeFlat: 0, feePercent: 3 },
  { code: "DANA", name: "DANA", group: "E-Wallet", type: "redirect", minAmount: 1e3, feeFlat: 0, feePercent: 3 },
  { code: "BRIVA", name: "BRI Virtual Account", group: "Virtual Account", type: "direct", minAmount: 1e4, feeFlat: 4250, feePercent: 0 },
  { code: "BNIVA", name: "BNI Virtual Account", group: "Virtual Account", type: "direct", minAmount: 1e4, feeFlat: 4250, feePercent: 0 },
  { code: "MANDIRIVA", name: "Mandiri Virtual Account", group: "Virtual Account", type: "direct", minAmount: 1e4, feeFlat: 4250, feePercent: 0 },
  { code: "BCAVA", name: "BCA Virtual Account", group: "Virtual Account", type: "direct", minAmount: 1e4, feeFlat: 5500, feePercent: 0 }
];
function createTransactionSignature(merchantCode, merchantRef, amount, privateKey) {
  return createHmac("sha256", privateKey).update(merchantCode + merchantRef + String(amount)).digest("hex");
}
function verifyCallbackSignature(rawBody, signature, privateKey) {
  const expected = createHmac("sha256", privateKey).update(rawBody).digest("hex");
  return expected === signature;
}
async function tripayFetch(endpoint, method, body, apiKey, baseUrl) {
  const cfg = getTripayConfig();
  const key = cfg.apiKey;
  const url = cfg.baseUrl;
  const res = await $fetch(`${url}${endpoint}`, {
    method,
    headers: { Authorization: `Bearer ${key}` },
    ...{ body } 
  });
  return res;
}
async function createTripayTransaction(payload) {
  const cfg = getTripayConfig();
  const signature = createTransactionSignature(
    cfg.merchantCode,
    payload.merchant_ref,
    payload.amount,
    cfg.privateKey
  );
  const res = await tripayFetch(
    "/transaction/create",
    "POST",
    { ...payload, signature }
  );
  if (!res.success) throw new Error(res.message || "Tripay error");
  return res.data;
}

const FILE_RE = /\/api\/file\/([A-Za-z0-9_.\-]+)/g;
function collectUploadFiles(store) {
  const set = /* @__PURE__ */ new Set();
  const scan = (v) => {
    if (!v) return;
    if (typeof v === "string") {
      FILE_RE.lastIndex = 0;
      let m;
      while (m = FILE_RE.exec(v)) set.add(m[1]);
      return;
    }
    if (Array.isArray(v)) {
      v.forEach(scan);
      return;
    }
    if (typeof v === "object") {
      Object.values(v).forEach(scan);
    }
  };
  scan(store == null ? void 0 : store.logo);
  scan(store == null ? void 0 : store.products);
  scan(store == null ? void 0 : store.links_bio);
  return set;
}
async function deleteOrphanUploads(oldStore, newStore) {
  try {
    const before = collectUploadFiles(oldStore);
    if (!before.size) return;
    const after = collectUploadFiles(newStore);
    const dir = join$1(getDataDir(), "uploads");
    for (const f of before) {
      if (!after.has(f)) {
        try {
          await unlink$1(join$1(dir, f));
        } catch {
        }
      }
    }
  } catch {
  }
}
async function cleanupUnusedUploads(allStores, minAgeMs = 0) {
  const referenced = /* @__PURE__ */ new Set();
  for (const s of allStores) collectUploadFiles(s).forEach((f) => referenced.add(f));
  const dir = join$1(getDataDir(), "uploads");
  let deleted = 0, kept = 0;
  let files = [];
  try {
    files = await readdir$1(dir);
  } catch {
    return { deleted: 0, kept: 0 };
  }
  const now = Date.now();
  for (const f of files) {
    if (referenced.has(f)) {
      kept++;
      continue;
    }
    try {
      if (minAgeMs > 0) {
        const st = await stat(join$1(dir, f));
        if (now - st.mtimeMs < minAgeMs) {
          kept++;
          continue;
        }
      }
      await unlink$1(join$1(dir, f));
      deleted++;
    } catch {
    }
  }
  return { deleted, kept };
}

const escHtml = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
async function sendVerificationEmail(store) {
  const email = (store.member_email || store.email || "").toString().trim().toLowerCase();
  if (!email) return false;
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1e3);
  await execute("DELETE FROM email_verifications WHERE store_id = ? OR expires_at <= NOW()", [store.id]);
  await execute(
    "INSERT INTO email_verifications (token, store_id, email, expires_at) VALUES (?, ?, ?, ?)",
    [token, store.id, email, expiresAt]
  );
  const config = useRuntimeConfig();
  const appUrl = config.appUrl || "https://lakara.id";
  const verifyUrl = `${appUrl}/member/verify-email?token=${token}`;
  const html = `
<div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; background: #ffffff;">
  <div style="background: #3358ff; padding: 28px 32px; border-radius: 12px 12px 0 0;">
    <span style="color: white; font-size: 20px; font-weight: bold;">\u2709\uFE0F Verifikasi Email Lakara</span>
  </div>
  <div style="background: #f8fafc; padding: 32px; border-radius: 0 0 12px 12px; border: 1px solid #e2e8f0; border-top: none;">
    <p style="color: #374151; font-size: 15px; margin-top: 0; line-height: 1.6;">
      Halo <strong>${escHtml(store.name || "Member Lakara")}</strong>,
    </p>
    <p style="color: #374151; font-size: 15px; line-height: 1.6;">
      Terima kasih sudah mendaftar di Lakara. Satu langkah lagi \u2014 konfirmasi alamat email kamu
      (<strong>${escHtml(email)}</strong>) untuk mengaktifkan akun.
    </p>
    <div style="text-align: center; margin: 24px 0;">
      <a href="${verifyUrl}"
         style="display: inline-block; background: #3358ff; color: #ffffff; text-decoration: none;
                padding: 14px 32px; border-radius: 8px; font-weight: bold; font-size: 15px;">
        Verifikasi Email Sekarang
      </a>
    </div>
    <p style="color: #6b7280; font-size: 13px; line-height: 1.6;">
      \u23F0 Link ini berlaku selama <strong>24 jam</strong>.<br>
      Jika kamu tidak merasa mendaftar di Lakara, abaikan email ini.
    </p>
    <p style="color: #9ca3af; font-size: 12px; line-height: 1.6; word-break: break-all;">
      Jika tombol tidak berfungsi, salin link ini ke browser:<br>${verifyUrl}
    </p>
    <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;">
    <p style="color: #9ca3af; font-size: 12px; margin: 0; line-height: 1.6;">
      Email ini dikirim otomatis oleh sistem Lakara. Jangan membalas email ini.<br>
      Butuh bantuan? Hubungi kami di
      <a href="https://wa.me/6285161313693" style="color: #3358ff; text-decoration: none;">WhatsApp</a>.
    </p>
  </div>
</div>`.trim();
  return await sendEmail(email, "Verifikasi Email Akun Lakara", html);
}

const collections = {
  'heroicons': () => import('./icons.mjs').then(m => m.default),
  'tabler': () => import('./icons2.mjs').then(m => m.default),
};

const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _Bdr9mw = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError$1({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError$1({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola.error(e);
      if (e.status === 404)
        return createError$1({ status: 404 });
      else
        return createError$1({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError$1({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_CXft41 = () => import('../routes/api/admin/artikel.get.mjs');
const _lazy_6aTBDH = () => import('../routes/api/admin/artikel.post.mjs');
const _lazy_0xreLK = () => import('../routes/api/admin/auth.post.mjs');
const _lazy_1f9npr = () => import('../routes/api/admin/faq.get.mjs');
const _lazy_2PuEXk = () => import('../routes/api/admin/faq.post.mjs');
const _lazy_RpSJms = () => import('../routes/api/admin/logout.post.mjs');
const _lazy_t_39xR = () => import('../routes/api/admin/member-creds.post.mjs');
const _lazy_H3l3R9 = () => import('../routes/api/admin/members.get.mjs');
const _lazy_kO7tCR = () => import('../routes/api/admin/members.post.mjs');
const _lazy_dFev6v = () => import('../routes/api/admin/newsletter.delete.mjs');
const _lazy_J66IIp = () => import('../routes/api/admin/newsletter.get.mjs');
const _lazy_4Yiel1 = () => import('../routes/api/admin/pending-members.get.mjs');
const _lazy_Rt26r9 = () => import('../routes/api/admin/pending-members.post.mjs');
const _lazy_3OPf48 = () => import('../routes/api/admin/portfolio.get.mjs');
const _lazy_Fj3oou = () => import('../routes/api/admin/portfolio.post.mjs');
const _lazy_fe38DJ = () => import('../routes/api/admin/seo.get.mjs');
const _lazy_IGhdZw = () => import('../routes/api/admin/seo.post.mjs');
const _lazy_kE4AH7 = () => import('../routes/api/admin/settings.get.mjs');
const _lazy_r5IIel = () => import('../routes/api/admin/settings.post.mjs');
const _lazy_slr3_n = () => import('../routes/api/admin/stores.get.mjs');
const _lazy_kA_CzP = () => import('../routes/api/admin/stores.post.mjs');
const _lazy_m4plbv = () => import('../routes/api/admin/stores/showcase.post.mjs');
const _lazy_upBr_R = () => import('../routes/api/admin/terms.post.mjs');
const _lazy_omjM1a = () => import('../routes/api/admin/testimoni.get.mjs');
const _lazy_YLqWqv = () => import('../routes/api/admin/testimoni.post.mjs');
const _lazy_XYN6p8 = () => import('../routes/api/admin/upgrade-history.get.mjs');
const _lazy_NDqJpm = () => import('../routes/api/admin/upgrade-requests.get.mjs');
const _lazy_F1kM2m = () => import('../routes/api/admin/upgrade-requests.post.mjs');
const _lazy_e4KKgu = () => import('../routes/api/admin/upload.post.mjs');
const _lazy_xdRxjN = () => import('../routes/api/admin/uploads.cleanup.post.mjs');
const _lazy_Y7L0TA = () => import('../routes/api/admin/uploads.delete.mjs');
const _lazy_Hwe7SC = () => import('../routes/api/admin/uploads.get.mjs');
const _lazy_qs5UmO = () => import('../routes/api/artikel.get.mjs');
const _lazy__xAhbf = () => import('../routes/api/auth.post.mjs');
const _lazy_Vm9Su8 = () => import('../routes/api/cron/expire-tiers.get.mjs');
const _lazy_8aDUcy = () => import('../routes/api/faq.get.mjs');
const _lazy_jKsAZ1 = () => import('../routes/api/file/_filename_.get.mjs');
const _lazy_S9aRdL = () => import('../routes/api/member/analytics.get.mjs');
const _lazy_r7cEKb = () => import('../routes/api/member/auth.post.mjs');
const _lazy_iC_Af6 = () => import('../routes/api/member/change-slug.post.mjs');
const _lazy_v9TTQK = () => import('../routes/api/member/forgot-password.post.mjs');
const _lazy_kepksk = () => import('../routes/api/member/links.get.mjs');
const _lazy_WduPi8 = () => import('../routes/api/member/links.post.mjs');
const _lazy_FtVzTo = () => import('../routes/api/member/logout.post.mjs');
const _lazy_aZzrUF = () => import('../routes/api/member/password.post.mjs');
const _lazy_rmUBLv = () => import('../routes/api/member/payment/_ref_.get.mjs');
const _lazy_KI3QfQ = () => import('../routes/api/member/payment/cancel.post.mjs');
const _lazy_NOMb64 = () => import('../routes/api/member/payment/create.post.mjs');
const _lazy_JkaP5P = () => import('../routes/api/member/payment/pending.get.mjs');
const _lazy_Iq7r7I = () => import('../routes/api/member/payments.get.mjs');
const _lazy_58vo5K = () => import('../routes/api/member/products.post.mjs');
const _lazy_X943pm = () => import('../routes/api/member/referral.get.mjs');
const _lazy_SxEuyN = () => import('../routes/api/member/register.post.mjs');
const _lazy_E7pILT = () => import('../routes/api/member/resend-verification.post.mjs');
const _lazy_01uZvH = () => import('../routes/api/member/reset-password.post.mjs');
const _lazy_FL6bOC = () => import('../routes/api/member/store.get.mjs');
const _lazy_ER3dEz = () => import('../routes/api/member/store.post.mjs');
const _lazy_EG4jUI = () => import('../routes/api/member/upgrade-request.post.mjs');
const _lazy_p9LC1x = () => import('../routes/api/member/upgrade-status.get.mjs');
const _lazy_P3K6_o = () => import('../routes/api/member/upload.post.mjs');
const _lazy_E1yFNN = () => import('../routes/api/member/validate-reset-token.get.mjs');
const _lazy_3dkuHo = () => import('../routes/api/member/verify-email.get.mjs');
const _lazy_4Fntu7 = () => import('../routes/api/newsletter.post.mjs');
const _lazy_Wj5dEg = () => import('../routes/api/portal/analytics/account.post.mjs');
const _lazy_BnBnS9 = () => import('../routes/api/portal/index.get.mjs');
const _lazy_c09Z7c = () => import('../routes/api/portal/analytics/metric.post.mjs');
const _lazy_c9aW5g = () => import('../routes/api/portal/assets/_id_.delete.mjs');
const _lazy_X13jbf = () => import('../routes/api/portal/index.get2.mjs');
const _lazy_0wNFT6 = () => import('../routes/api/portal/index.post.mjs');
const _lazy_d3fglL = () => import('../routes/api/portal/index.get3.mjs');
const _lazy_N59YrD = () => import('../routes/api/portal/index.post2.mjs');
const _lazy_6zQdm1 = () => import('../routes/api/portal/auth/login.post.mjs');
const _lazy_ILK8DP = () => import('../routes/api/portal/auth/logout.post.mjs');
const _lazy_IRRi0L = () => import('../routes/api/portal/auth/me.get.mjs');
const _lazy_XupbWq = () => import('../routes/api/portal/briefs/_id_.get.mjs');
const _lazy_kfSsaA = () => import('../routes/api/portal/index.get4.mjs');
const _lazy_bqs40l = () => import('../routes/api/portal/index.post3.mjs');
const _lazy_kEPpRM = () => import('../routes/api/portal/index.get5.mjs');
const _lazy_rZT2xk = () => import('../routes/api/portal/index.post4.mjs');
const _lazy_QQzwFu = () => import('../routes/api/portal/chat/threads.get.mjs');
const _lazy_fqEENw = () => import('../routes/api/portal/index.get6.mjs');
const _lazy_ezPtGN = () => import('../routes/api/portal/index.post5.mjs');
const _lazy_VO37My = () => import('../routes/api/portal/contents/_id_.get.mjs');
const _lazy_ZNBrud = () => import('../routes/api/portal/contents/_id/review.post.mjs');
const _lazy_7Kh2MG = () => import('../routes/api/portal/index.get7.mjs');
const _lazy_D7mPjc = () => import('../routes/api/portal/index.post6.mjs');
const _lazy_HvtX7p = () => import('../routes/api/portal/contracts/_id_.delete.mjs');
const _lazy_6vlZn2 = () => import('../routes/api/portal/index.get8.mjs');
const _lazy_NtWfOY = () => import('../routes/api/portal/index.post7.mjs');
const _lazy_D9a2p_ = () => import('../routes/api/portal/index.get9.mjs');
const _lazy_3DC1Ga = () => import('../routes/api/portal/index.post8.mjs');
const _lazy_1yVzC3 = () => import('../routes/api/portal/dashboard.get.mjs');
const _lazy_gMxDTY = () => import('../routes/api/portal/index.post9.mjs');
const _lazy_wtEkbF = () => import('../routes/api/portal/invoices/_id_.get.mjs');
const _lazy_GBr3o7 = () => import('../routes/api/portal/invoices/_id/status.post.mjs');
const _lazy_ukg3WO = () => import('../routes/api/portal/invoices/generate-recurring.post.mjs');
const _lazy_m71T2o = () => import('../routes/api/portal/index.get10.mjs');
const _lazy_A5Ybjm = () => import('../routes/api/portal/index.post10.mjs');
const _lazy_wJcfno = () => import('../routes/api/portal/kb/_id_.delete.mjs');
const _lazy_pUvJUi = () => import('../routes/api/portal/index.get11.mjs');
const _lazy_JRoKz6 = () => import('../routes/api/portal/index.post11.mjs');
const _lazy_kPLfkj = () => import('../routes/api/portal/notes/_id_.delete.mjs');
const _lazy_k9iu5j = () => import('../routes/api/portal/index.get12.mjs');
const _lazy_bqHRlo = () => import('../routes/api/portal/index.post12.mjs');
const _lazy_zpow4q = () => import('../routes/api/portal/index.get13.mjs');
const _lazy_ZIwATP = () => import('../routes/api/portal/notifications/read.post.mjs');
const _lazy_7D8v83 = () => import('../routes/api/portal/index.get14.mjs');
const _lazy_vCXz1r = () => import('../routes/api/portal/payouts/_id/status.post.mjs');
const _lazy_q8NU6Y = () => import('../routes/api/portal/index.get15.mjs');
const _lazy_IVgmuQ = () => import('../routes/api/portal/index.post13.mjs');
const _lazy_tvGdP4 = () => import('../routes/api/portal/payouts/suggest.get.mjs');
const _lazy_oNU6dA = () => import('../routes/api/portal/index.get16.mjs');
const _lazy_CfmTMc = () => import('../routes/api/portal/index.post14.mjs');
const _lazy_0Y2HfA = () => import('../routes/api/portal/reports/_id_.get.mjs');
const _lazy_a8kzLk = () => import('../routes/api/portal/index.get17.mjs');
const _lazy_yjFi4F = () => import('../routes/api/portal/index.post15.mjs');
const _lazy_usCNa6 = () => import('../routes/api/portal/tasks/_id_.get.mjs');
const _lazy_VVsqYT = () => import('../routes/api/portal/tasks/_id/message.post.mjs');
const _lazy_IPP4j5 = () => import('../routes/api/portal/tasks/_id/submit.post.mjs');
const _lazy_KMH4uT = () => import('../routes/api/portal/index.get18.mjs');
const _lazy_epQEQ9 = () => import('../routes/api/portal/index.post16.mjs');
const _lazy__eUL2V = () => import('../routes/api/portal/index.get19.mjs');
const _lazy_Sbznvx = () => import('../routes/api/portal/index.post17.mjs');
const _lazy_B2z62u = () => import('../routes/api/portal/tickets/_id_.get.mjs');
const _lazy_3FYRHx = () => import('../routes/api/portal/tickets/_id/reply.post.mjs');
const _lazy_uQs8AW = () => import('../routes/api/portal/tickets/_id/status.post.mjs');
const _lazy_WxbjuN = () => import('../routes/api/portal/index.get20.mjs');
const _lazy_Dqdqc2 = () => import('../routes/api/portal/index.post18.mjs');
const _lazy_NKQPpu = () => import('../routes/api/portal/index.get21.mjs');
const _lazy_eaTlGf = () => import('../routes/api/portal/index.post19.mjs');
const _lazy_vQgKsb = () => import('../routes/api/portfolio.get.mjs');
const _lazy_NbYM7M = () => import('../routes/api/portfolio.post.mjs');
const _lazy_bKJQ_N = () => import('../routes/api/public/delete-account-request.post.mjs');
const _lazy_i7zHMa = () => import('../routes/api/public/record-click.post.mjs');
const _lazy_5rlZ10 = () => import('../routes/api/public/record-view.post.mjs');
const _lazy_QpzzSG = () => import('../routes/api/public/showcase.get.mjs');
const _lazy_WddPkH = () => import('../routes/api/seo.get.mjs');
const _lazy_lsYfsu = () => import('../routes/api/seo.post.mjs');
const _lazy_9e_hU2 = () => import('../routes/api/settings.get.mjs');
const _lazy_9PeXks = () => import('../routes/api/stores.get.mjs');
const _lazy_ibneqp = () => import('../routes/api/terms.get.mjs');
const _lazy_H0VJmB = () => import('../routes/api/testimoni.get.mjs');
const _lazy_tGxw7l = () => import('../routes/api/tripay/callback.post.mjs');
const _lazy_68EROv = () => import('../routes/robots.txt.mjs');
const _lazy_JRGGJY = () => import('../routes/sitemap.xml.mjs');
const _lazy_gpcpv4 = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _l2xa41, lazy: false, middleware: true, method: undefined },
  { route: '/api/admin/artikel', handler: _lazy_CXft41, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/artikel', handler: _lazy_6aTBDH, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/auth', handler: _lazy_0xreLK, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/faq', handler: _lazy_1f9npr, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/faq', handler: _lazy_2PuEXk, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/logout', handler: _lazy_RpSJms, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/member-creds', handler: _lazy_t_39xR, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/members', handler: _lazy_H3l3R9, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/members', handler: _lazy_kO7tCR, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/newsletter', handler: _lazy_dFev6v, lazy: true, middleware: false, method: "delete" },
  { route: '/api/admin/newsletter', handler: _lazy_J66IIp, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/pending-members', handler: _lazy_4Yiel1, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/pending-members', handler: _lazy_Rt26r9, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/portfolio', handler: _lazy_3OPf48, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/portfolio', handler: _lazy_Fj3oou, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/seo', handler: _lazy_fe38DJ, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/seo', handler: _lazy_IGhdZw, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/settings', handler: _lazy_kE4AH7, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/settings', handler: _lazy_r5IIel, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/stores', handler: _lazy_slr3_n, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/stores', handler: _lazy_kA_CzP, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/stores/showcase', handler: _lazy_m4plbv, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/terms', handler: _lazy_upBr_R, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/testimoni', handler: _lazy_omjM1a, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/testimoni', handler: _lazy_YLqWqv, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/upgrade-history', handler: _lazy_XYN6p8, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/upgrade-requests', handler: _lazy_NDqJpm, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/upgrade-requests', handler: _lazy_F1kM2m, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/upload', handler: _lazy_e4KKgu, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/uploads.cleanup', handler: _lazy_xdRxjN, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/uploads', handler: _lazy_Y7L0TA, lazy: true, middleware: false, method: "delete" },
  { route: '/api/admin/uploads', handler: _lazy_Hwe7SC, lazy: true, middleware: false, method: "get" },
  { route: '/api/artikel', handler: _lazy_qs5UmO, lazy: true, middleware: false, method: "get" },
  { route: '/api/auth', handler: _lazy__xAhbf, lazy: true, middleware: false, method: "post" },
  { route: '/api/cron/expire-tiers', handler: _lazy_Vm9Su8, lazy: true, middleware: false, method: "get" },
  { route: '/api/faq', handler: _lazy_8aDUcy, lazy: true, middleware: false, method: "get" },
  { route: '/api/file/:filename', handler: _lazy_jKsAZ1, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/analytics', handler: _lazy_S9aRdL, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/auth', handler: _lazy_r7cEKb, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/change-slug', handler: _lazy_iC_Af6, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/forgot-password', handler: _lazy_v9TTQK, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/links', handler: _lazy_kepksk, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/links', handler: _lazy_WduPi8, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/logout', handler: _lazy_FtVzTo, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/password', handler: _lazy_aZzrUF, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/payment/:ref', handler: _lazy_rmUBLv, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/payment/cancel', handler: _lazy_KI3QfQ, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/payment/create', handler: _lazy_NOMb64, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/payment/pending', handler: _lazy_JkaP5P, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/payments', handler: _lazy_Iq7r7I, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/products', handler: _lazy_58vo5K, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/referral', handler: _lazy_X943pm, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/register', handler: _lazy_SxEuyN, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/resend-verification', handler: _lazy_E7pILT, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/reset-password', handler: _lazy_01uZvH, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/store', handler: _lazy_FL6bOC, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/store', handler: _lazy_ER3dEz, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/upgrade-request', handler: _lazy_EG4jUI, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/upgrade-status', handler: _lazy_p9LC1x, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/upload', handler: _lazy_P3K6_o, lazy: true, middleware: false, method: "post" },
  { route: '/api/member/validate-reset-token', handler: _lazy_E1yFNN, lazy: true, middleware: false, method: "get" },
  { route: '/api/member/verify-email', handler: _lazy_3dkuHo, lazy: true, middleware: false, method: "get" },
  { route: '/api/newsletter', handler: _lazy_4Fntu7, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/analytics/account', handler: _lazy_Wj5dEg, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/analytics', handler: _lazy_BnBnS9, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/analytics/metric', handler: _lazy_c09Z7c, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/assets/:id', handler: _lazy_c9aW5g, lazy: true, middleware: false, method: "delete" },
  { route: '/api/portal/assets', handler: _lazy_X13jbf, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/assets', handler: _lazy_0wNFT6, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/attendance', handler: _lazy_d3fglL, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/attendance', handler: _lazy_N59YrD, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/auth/login', handler: _lazy_6zQdm1, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/auth/logout', handler: _lazy_ILK8DP, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/auth/me', handler: _lazy_IRRi0L, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/briefs/:id', handler: _lazy_XupbWq, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/briefs', handler: _lazy_kfSsaA, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/briefs', handler: _lazy_bqs40l, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/chat', handler: _lazy_kEPpRM, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/chat', handler: _lazy_rZT2xk, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/chat/threads', handler: _lazy_QQzwFu, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/clients', handler: _lazy_fqEENw, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/clients', handler: _lazy_ezPtGN, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/contents/:id', handler: _lazy_VO37My, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/contents/:id/review', handler: _lazy_ZNBrud, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/contents', handler: _lazy_7Kh2MG, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/contents', handler: _lazy_D7mPjc, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/contracts/:id', handler: _lazy_HvtX7p, lazy: true, middleware: false, method: "delete" },
  { route: '/api/portal/contracts', handler: _lazy_6vlZn2, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/contracts', handler: _lazy_NtWfOY, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/daily-reports', handler: _lazy_D9a2p_, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/daily-reports', handler: _lazy_3DC1Ga, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/dashboard', handler: _lazy_1yVzC3, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/folders', handler: _lazy_gMxDTY, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/invoices/:id', handler: _lazy_wtEkbF, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/invoices/:id/status', handler: _lazy_GBr3o7, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/invoices/generate-recurring', handler: _lazy_ukg3WO, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/invoices', handler: _lazy_m71T2o, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/invoices', handler: _lazy_A5Ybjm, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/kb/:id', handler: _lazy_wJcfno, lazy: true, middleware: false, method: "delete" },
  { route: '/api/portal/kb', handler: _lazy_pUvJUi, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/kb', handler: _lazy_JRoKz6, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/notes/:id', handler: _lazy_kPLfkj, lazy: true, middleware: false, method: "delete" },
  { route: '/api/portal/notes', handler: _lazy_k9iu5j, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/notes', handler: _lazy_bqHRlo, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/notifications', handler: _lazy_zpow4q, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/notifications/read', handler: _lazy_ZIwATP, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/packages', handler: _lazy_7D8v83, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/payouts/:id/status', handler: _lazy_vCXz1r, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/payouts', handler: _lazy_q8NU6Y, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/payouts', handler: _lazy_IVgmuQ, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/payouts/suggest', handler: _lazy_tvGdP4, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/profile', handler: _lazy_oNU6dA, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/profile', handler: _lazy_CfmTMc, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/reports/:id', handler: _lazy_0Y2HfA, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/reports', handler: _lazy_a8kzLk, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/reports', handler: _lazy_yjFi4F, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tasks/:id', handler: _lazy_usCNa6, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/tasks/:id/message', handler: _lazy_VVsqYT, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tasks/:id/submit', handler: _lazy_IPP4j5, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tasks', handler: _lazy_KMH4uT, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/tasks', handler: _lazy_epQEQ9, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/team', handler: _lazy__eUL2V, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/team', handler: _lazy_Sbznvx, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tickets/:id', handler: _lazy_B2z62u, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/tickets/:id/reply', handler: _lazy_3FYRHx, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tickets/:id/status', handler: _lazy_uQs8AW, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/tickets', handler: _lazy_WxbjuN, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/tickets', handler: _lazy_Dqdqc2, lazy: true, middleware: false, method: "post" },
  { route: '/api/portal/users', handler: _lazy_NKQPpu, lazy: true, middleware: false, method: "get" },
  { route: '/api/portal/users', handler: _lazy_eaTlGf, lazy: true, middleware: false, method: "post" },
  { route: '/api/portfolio', handler: _lazy_vQgKsb, lazy: true, middleware: false, method: "get" },
  { route: '/api/portfolio', handler: _lazy_NbYM7M, lazy: true, middleware: false, method: "post" },
  { route: '/api/public/delete-account-request', handler: _lazy_bKJQ_N, lazy: true, middleware: false, method: "post" },
  { route: '/api/public/record-click', handler: _lazy_i7zHMa, lazy: true, middleware: false, method: "post" },
  { route: '/api/public/record-view', handler: _lazy_5rlZ10, lazy: true, middleware: false, method: "post" },
  { route: '/api/public/showcase', handler: _lazy_QpzzSG, lazy: true, middleware: false, method: "get" },
  { route: '/api/seo', handler: _lazy_WddPkH, lazy: true, middleware: false, method: "get" },
  { route: '/api/seo', handler: _lazy_lsYfsu, lazy: true, middleware: false, method: "post" },
  { route: '/api/settings', handler: _lazy_9e_hU2, lazy: true, middleware: false, method: "get" },
  { route: '/api/stores', handler: _lazy_9PeXks, lazy: true, middleware: false, method: "get" },
  { route: '/api/terms', handler: _lazy_ibneqp, lazy: true, middleware: false, method: "get" },
  { route: '/api/testimoni', handler: _lazy_H0VJmB, lazy: true, middleware: false, method: "get" },
  { route: '/api/tripay/callback', handler: _lazy_tGxw7l, lazy: true, middleware: false, method: "post" },
  { route: '/robots.txt', handler: _lazy_68EROv, lazy: true, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _lazy_JRGGJY, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_gpcpv4, lazy: true, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _Bdr9mw, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_gpcpv4, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp = createNitroApp();
function useNitroApp() {
  return nitroApp;
}
runNitroPlugins(nitroApp);

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

export { readRawBody as $, resetAttempts as A, recordFailedAttempt as B, getDataDir as C, setHeader as D, getMemberStore as E, safeMemberStore as F, sendEmail as G, deleteOrphanUploads as H, getRouterParam as I, createTripayTransaction as J, sendVerificationEmail as K, requirePortalUser as L, scopedClientId as M, genId as N, requireAdmin as O, logActivity as P, assertClientOwnership as Q, createPortalSession as R, destroyPortalSession as S, TRIPAY_CHANNELS as T, withTransaction as U, getClientRevisionLimit as V, notify as W, getClientUserIds as X, getAdminUserIds as Y, requireSuperAdmin as Z, writeJson as _, trapUnhandledNodeErrors as a, verifyCallbackSignature as a0, setResponseStatus as a1, buildAssetsURL as a2, publicAssetsURL as a3, getResponseStatusText as a4, getResponseStatus as a5, encodePath as a6, defineRenderHandler as a7, getRouteRules as a8, joinURL as a9, serialize$1 as aa, defuFn as ab, defu as ac, hasProtocol as ad, isScriptProtocol as ae, parseQuery as af, klona as ag, createDefu as ah, withQuery as ai, sanitizeStatusCode as aj, parseURL as ak, decodePath as al, getContext as am, withTrailingSlash as an, withoutTrailingSlash as ao, $fetch$1 as ap, baseURL as aq, isEqual as ar, createHooks as as, executeAsync as at, hash$1 as au, getRequestHeader as av, getCookie as aw, upperFirst as ax, useNitroApp as b, defineEventHandler as c, destr as d, checkAuth as e, createError$1 as f, readBody as g, setCookie as h, queryOne as i, execute as j, deleteCookie as k, hashPassword as l, slugify as m, readJsonObj as n, getDb as o, parseStore as p, query as q, readJson as r, setupGracefulShutdown as s, toNodeListener as t, useRuntimeConfig as u, readMultipartFormData as v, cleanupUnusedUploads as w, getQuery as x, getHeader as y, checkRateLimit as z };
//# sourceMappingURL=nitro.mjs.map
