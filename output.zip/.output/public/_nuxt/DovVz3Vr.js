import"./DkUMpoHM.js";const s=globalThis.setInterval;export{s};
